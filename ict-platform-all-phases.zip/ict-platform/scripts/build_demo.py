"""Build the static demo (frontend/dist-demo/index.html) with pre-computed engine output.

    python scripts/build_demo.py [--limit 1000] [--provider synthetic]

Runs the real ICT engine for every timeframe and embeds the JSON in a single
HTML file that works without a server (settings are read-only there).
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from backend.ict_engine import ICTSettings  # noqa: E402
from backend.market_data.timeframes import TIMEFRAMES, TIMEFRAME_LABELS  # noqa: E402
from backend.market_data import MarketDataService  # noqa: E402
from backend.services.analysis_service import DISCLAIMER, AnalysisService  # noqa: E402


def _round(o):
    if isinstance(o, float):
        return round(o, 4)
    if isinstance(o, dict):
        return {k: _round(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_round(v) for v in o]
    return o


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=1000)
    ap.add_argument("--provider", default=None)
    args = ap.parse_args()
    data = MarketDataService.from_env()
    svc = AnalysisService(data)
    prov = data.provider(args.provider, "XAUUSD")
    xau = prov.get_symbol_info("XAUUSD").to_dict()
    meta = {
        "default_provider": prov.id,
        "default_symbol": "XAUUSD",
        "providers": [prov.info().to_dict()],
        "instruments": [{**xau, "default_provider": prov.id, "providers": [prov.id]}],
        "symbols": [xau],
        "live": False,
        "timeframes": [{"id": k, "label": TIMEFRAME_LABELS[k], "seconds": v} for k, v in TIMEFRAMES.items()],
        "default_settings": ICTSettings().model_dump(),
        "disclaimer": DISCLAIMER,
        "auto_trading": False,
    }
    analyses = {}
    for tf in TIMEFRAMES:
        out = svc.analyze("XAUUSD", tf, args.limit, prov.id)
        out["forming"] = None
        analyses[tf] = _round(out)
        print(f"{tf}: {len(out['candles'])} candles, {len(out['analysis']['setups'])} setups")
    snap = {"meta": meta, "analyses": analyses, "created_at": analyses["1m"]["generated_at"]}
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        json.dump(snap, f, separators=(",", ":"), allow_nan=False)
        path = f.name
    subprocess.run(["node", "build.mjs", "--snapshot", path], cwd=os.path.join(ROOT, "frontend"), check=True)
    os.unlink(path)


if __name__ == "__main__":
    main()
