"""Start ICT Lab:  python run.py   ->  http://127.0.0.1:8000

API keys and options are read from the environment or from a local .env file
(see .env.example). Analysis only: no broker connection, no order execution.
"""
import os
import sys

if sys.version_info < (3, 10):
    sys.exit("Python 3.10 or newer is required.")


def load_dotenv(path: str = ".env") -> None:
    if not os.path.isfile(path):
        return
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.split(" #")[0].strip().strip('"').strip("'")
        if value and key not in os.environ:
            os.environ[key] = value


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    load_dotenv()
    try:
        import uvicorn
        import fastapi  # noqa: F401
    except ImportError:
        sys.exit("Missing dependencies. Run:  pip install -r requirements.txt")
    try:
        import websockets  # noqa: F401
    except ImportError:
        print("NOTE: 'websockets' is not installed - the browser will fall back to Server-Sent Events, "
              "and Pyth/Twelve Data streaming will not work. pip install websockets")

    from backend.market_data import MarketDataService

    svc = MarketDataService.from_env()
    print("Instruments:")
    for inst in svc.instruments():
        p = svc.provider(symbol=inst["symbol"]).info()
        flag = "SIMULATED - not real prices" if p.is_synthetic else ("real-time" if p.realtime else "historical")
        print(f"  {inst['symbol']:7s} {inst['market']:13s} -> {p.name} ({flag})")
    for p in svc.provider_infos():
        if not p.configured and p.setup_hint:
            print(f"  [{p.id}] not configured: {p.setup_hint}")

    host = os.environ.get("ICT_HOST", "127.0.0.1")
    port = int(os.environ.get("ICT_PORT", "8000"))
    print(f"ICT Lab -> http://{host}:{port}   (analysis only - no order execution)")
    uvicorn.run("backend.main:app", host=host, port=port)
