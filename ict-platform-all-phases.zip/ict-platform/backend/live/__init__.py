"""Real-time layer: tick aggregation, feed status, connection hub (analysis only)."""
