"""LiveHub: one upstream connection per (provider, instrument), fanned out to
any number of browser clients.

    Provider stream (WebSocket / polling) --ticks--> CandleAggregator (every TF)
        -> forming-candle updates      -> clients ("candle", throttled to 4/s)
        -> candle CLOSED               -> MarketDataService.append_live()
                                       -> ICT analysis recomputed on CLOSED candles
                                       -> clients ("candle_closed", "analysis")
    Connection loss -> status "reconnecting" -> exponential back-off ->
    history reloaded (fills the gap) -> aggregators re-seeded -> streaming resumes.

Analysis-only: nothing in here can place, modify or manage orders.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

from backend.ict_engine import ICTSettings
from backend.market_data.base import AuthError, MarketDataProvider, RateLimitError, Tick
from backend.market_data.service import MarketDataService
from backend.market_data.timeframes import TIMEFRAMES
from backend.services.analysis_service import AnalysisService

from .aggregator import CandleAggregator
from .status import FeedStatus, classify

log = logging.getLogger("ict.live")
SendFn = Callable[[dict], Awaitable[None]]


def normalised(c: Optional[dict], symbol: str, timeframe: str) -> Optional[dict]:
    """Common candle format sent to clients."""
    if c is None:
        return None
    return {"timestamp": int(c["time"]), "open": c["open"], "high": c["high"], "low": c["low"],
            "close": c["close"], "volume": c.get("volume", 0.0), "symbol": symbol, "timeframe": timeframe}


class Client:
    """One browser connection (WebSocket or SSE). Messages go through a bounded
    queue so a slow client can never block the feed."""

    def __init__(self, send: SendFn, name: str = "client", maxsize: int = 400):
        self._send = send
        self.name = name
        self.queue: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self.sub: Optional["Subscription"] = None
        self.closed = False
        self.dropped = 0

    def put(self, msg: dict) -> None:
        if self.closed:
            return
        try:
            self.queue.put_nowait(msg)
        except asyncio.QueueFull:
            # drop the oldest message (usually a stale forming-candle update)
            try:
                self.queue.get_nowait()
            except asyncio.QueueEmpty:  # pragma: no cover
                pass
            self.dropped += 1
            self.queue.put_nowait(msg)

    async def writer(self) -> None:
        try:
            while True:
                msg = await self.queue.get()
                await self._send(msg)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - client went away
            log.info("client %s writer stopped: %s", self.name, exc)
            self.closed = True


@dataclass(eq=False)
class Subscription:
    client: Client
    symbol: str
    timeframe: str
    provider_id: str
    limit: int
    settings: ICTSettings
    settings_key: str = ""

    def __post_init__(self) -> None:
        self.settings_key = hashlib.sha1(json.dumps(self.settings.model_dump(), sort_keys=True).encode()).hexdigest()[:12]


@dataclass(eq=False)
class Feed:
    provider: MarketDataProvider
    symbol: str
    aggs: dict[str, CandleAggregator] = field(default_factory=dict)
    subs: set = field(default_factory=set)
    task: Optional[asyncio.Task] = None
    connected: bool = False
    last_source_ts: Optional[float] = None
    last_receive: Optional[float] = None
    last_tick: Optional[dict] = None
    error: Optional[str] = None
    fatal: bool = False
    retry_at: Optional[float] = None
    attempt: int = 0
    dirty: set = field(default_factory=set)
    pending: set = field(default_factory=set)
    pending_due: float = 0.0
    recompute_task: Optional[asyncio.Task] = None
    last_status: Optional[dict] = None
    last_status_sent: float = 0.0
    empty_since: Optional[float] = None
    reconnects: int = 0

    def __post_init__(self) -> None:
        self.aggs = {tf: CandleAggregator(self.symbol, tf) for tf in TIMEFRAMES}

    @property
    def key(self) -> tuple[str, str]:
        return (self.provider.id, self.symbol)


class LiveHub:
    def __init__(self, data: MarketDataService, analysis: AnalysisService, flush_interval: float = 0.25,
                 idle_timeout: float = 30.0, recompute_delay: float = 0.3, backoff_cap: float = 30.0):
        self.data = data
        self.analysis = analysis
        self.flush_interval = flush_interval
        self.idle_timeout = idle_timeout
        self.recompute_delay = recompute_delay
        self.backoff_cap = backoff_cap
        self.feeds: dict[tuple[str, str], Feed] = {}
        self._clock: Optional[asyncio.Task] = None
        self._last_flush = 0.0

    # ----------------------------------------------------------- lifecycle
    def ensure_started(self) -> None:
        if self._clock is None or self._clock.done():
            self._clock = asyncio.get_running_loop().create_task(self._clock_loop())

    async def shutdown(self) -> None:
        tasks = [t for t in [self._clock] + [f.task for f in self.feeds.values()] if t]
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.feeds.clear()

    # -------------------------------------------------------- subscriptions
    async def subscribe(self, client: Client, symbol: str, timeframe: str, provider_id: Optional[str] = None,
                        limit: int = 1500, settings: Optional[ICTSettings] = None) -> Subscription:
        self.ensure_started()
        self.unsubscribe(client)
        provider = self.data.provider(provider_id, symbol)
        provider.get_symbol_info(symbol)
        if timeframe not in TIMEFRAMES:
            raise ValueError(f"Unsupported timeframe {timeframe}")
        sub = Subscription(client, symbol, timeframe, provider.id, limit, settings or ICTSettings())
        feed = self.feeds.get((provider.id, symbol))
        if feed is None:
            feed = Feed(provider, symbol)
            self.feeds[feed.key] = feed
        feed.subs.add(sub)
        feed.empty_since = None
        client.sub = sub
        if provider.supports_streaming and (feed.task is None or feed.task.done()):
            feed.task = asyncio.get_running_loop().create_task(self._run_feed(feed))
        client.put({"type": "status", "status": self.status(feed).to_dict()})
        payload = await asyncio.to_thread(self.analysis.analyze, symbol, timeframe, limit, provider.id, sub.settings)
        if client.sub is sub:  # still subscribed to the same thing
            client.put({"type": "snapshot", "payload": self._with_forming(payload, feed, timeframe),
                        "status": self.status(feed).to_dict()})
        return sub

    def unsubscribe(self, client: Client) -> None:
        sub = client.sub
        client.sub = None
        if sub is None:
            return
        feed = self.feeds.get((sub.provider_id, sub.symbol))
        if feed is not None:
            feed.subs.discard(sub)
            if not feed.subs:
                feed.empty_since = time.time()

    # ------------------------------------------------------------- status
    def status(self, feed: Feed, now: Optional[float] = None) -> FeedStatus:
        p = feed.provider
        info = p.info()
        si = p.get_symbol_info(feed.symbol)
        return classify(symbol=feed.symbol, market=si.market, provider_id=p.id, provider_name=info.name,
                        transport=info.transport, realtime=p.is_realtime(feed.symbol), streaming=p.supports_streaming,
                        connected=feed.connected, last_source_ts=feed.last_source_ts, last_receive=feed.last_receive,
                        error=feed.error, retry_at=feed.retry_at, fatal=feed.fatal,
                        poll_seconds=float(getattr(p, "poll_seconds", 0.0) if info.transport == "polling" else 0.0), now=now,
                        asset_class=si.asset_class)

    def _broadcast(self, feed: Feed, msg: dict, timeframe: Optional[str] = None) -> None:
        for sub in list(feed.subs):
            if timeframe is None or sub.timeframe == timeframe:
                sub.client.put(msg)

    def _push_status(self, feed: Feed, force: bool = False) -> None:
        st = self.status(feed).to_dict()
        key = {k: st[k] for k in ("state", "message", "connected")}
        now = time.time()
        if force or key != feed.last_status or now - feed.last_status_sent > 5:
            feed.last_status = key
            feed.last_status_sent = now
            self._broadcast(feed, {"type": "status", "status": st})

    # --------------------------------------------------------- upstream feed
    async def _resync(self, feed: Feed) -> None:
        """(Re)load history and seed every aggregator with the provider's forming candle."""
        if feed.attempt > 0 or feed.reconnects > 0:
            self.data.invalidate_history(feed.provider.id, feed.symbol)
        for tf, agg in feed.aggs.items():
            try:
                cs = await asyncio.to_thread(self.data.get_candles, feed.symbol, tf, feed.provider.id)
            except LookupError:
                continue
            last_closed = int(cs.df["time"].iloc[-1]) if len(cs.df) else -1
            agg.seed(cs.forming, last_closed)
        feed.pending.update(sub.timeframe for sub in feed.subs)
        feed.pending_due = time.time()

    def _on_event(self, feed: Feed, kind: str, details: dict) -> None:
        if kind == "connected":
            feed.connected = True
            feed.error = None
            feed.fatal = False
            feed.retry_at = None
            self._push_status(feed, force=True)

    def _on_tick(self, feed: Feed, tick: Tick) -> None:
        now = time.time()
        feed.last_receive = now
        if feed.last_source_ts is None or tick.ts >= feed.last_source_ts:
            feed.last_source_ts = tick.ts
        feed.last_tick = {"price": tick.price, "bid": tick.bid, "ask": tick.ask, "ts": tick.ts}
        feed.attempt = 0
        for tf, agg in feed.aggs.items():
            for c in agg.update(tick.ts, tick.price, tick.size, tick.bar):
                self._on_closed(feed, tf, c)
            feed.dirty.add(tf)

    def _on_closed(self, feed: Feed, tf: str, candle: dict) -> None:
        if tf in feed.provider.native_timeframes(feed.symbol):
            self.data.append_live(feed.provider.id, feed.symbol, tf, candle)
        self._broadcast(feed, {"type": "candle_closed", "candle": normalised(candle, feed.symbol, tf)}, tf)
        if any(sub.timeframe == tf for sub in feed.subs):
            feed.pending.add(tf)
            feed.pending_due = time.time() + self.recompute_delay

    async def _run_feed(self, feed: Feed) -> None:
        p = feed.provider
        while True:
            try:
                feed.connected = False
                await self._resync(feed)
                self._push_status(feed, force=True)
                await p.subscribe_realtime(feed.symbol, lambda t: self._on_tick(feed, t),
                                           lambda k, d: self._on_event(feed, k, d), attempt=feed.reconnects)
                raise ConnectionError("stream ended")
            except asyncio.CancelledError:
                feed.connected = False
                raise
            except AuthError as exc:
                feed.fatal, delay = True, 60.0
                feed.error = str(exc)
            except RateLimitError as exc:
                feed.fatal, delay = False, max(5.0, exc.retry_after)
                feed.error = f"rate limited: {exc}"
            except Exception as exc:  # noqa: BLE001 - any network / protocol problem
                feed.fatal = False
                feed.error = str(exc) or exc.__class__.__name__
                delay = min(self.backoff_cap, 2 ** min(feed.attempt, 5)) * (0.75 + random.random() * 0.5)
            feed.connected = False
            feed.attempt += 1
            feed.reconnects += 1
            feed.retry_at = time.time() + delay
            log.warning("feed %s/%s down (%s); retry in %.1fs", p.id, feed.symbol, feed.error, delay)
            self._push_status(feed, force=True)
            await asyncio.sleep(delay)

    # ------------------------------------------------------------- clock
    async def _clock_loop(self) -> None:
        while True:
            await asyncio.sleep(0.25)
            try:
                self._tick_clock(time.time())
            except Exception:  # noqa: BLE001
                log.exception("live clock error")

    def _tick_clock(self, now: float) -> None:
        flush = now - self._last_flush >= self.flush_interval
        if flush:
            self._last_flush = now
        for key, feed in list(self.feeds.items()):
            for tf, agg in feed.aggs.items():
                c = agg.close_due(now)
                if c is not None:
                    self._on_closed(feed, tf, c)
            if flush and feed.dirty:
                for sub in list(feed.subs):
                    if sub.timeframe in feed.dirty:
                        sub.client.put({"type": "candle", "candle": normalised(feed.aggs[sub.timeframe].forming, feed.symbol, sub.timeframe),
                                        "tick": feed.last_tick})
                feed.dirty.clear()
            self._push_status(feed)
            if feed.pending and now >= feed.pending_due and (feed.recompute_task is None or feed.recompute_task.done()):
                tfs, feed.pending = set(feed.pending), set()
                feed.recompute_task = asyncio.get_running_loop().create_task(self._recompute(feed, tfs))
            if not feed.subs and feed.empty_since and now - feed.empty_since > self.idle_timeout:
                if feed.task:
                    feed.task.cancel()
                del self.feeds[key]

    async def _recompute(self, feed: Feed, tfs: set) -> None:
        groups: dict[tuple, list[Subscription]] = {}
        for sub in list(feed.subs):
            if sub.timeframe in tfs:
                groups.setdefault((sub.timeframe, sub.settings_key, sub.limit), []).append(sub)
        for (tf, _, limit), subs in groups.items():
            try:
                payload = await asyncio.to_thread(self.analysis.analyze, feed.symbol, tf, limit, feed.provider.id, subs[0].settings)
            except Exception as exc:  # noqa: BLE001
                for sub in subs:
                    sub.client.put({"type": "error", "message": f"Analysis failed: {exc}"})
                continue
            msg = {"type": "analysis", "payload": self._with_forming(payload, feed, tf)}
            for sub in subs:
                if sub in feed.subs:
                    sub.client.put(msg)

    def _with_forming(self, payload: dict, feed: Feed, tf: str) -> dict:
        forming = feed.aggs[tf].forming or payload.get("forming")
        last_closed = payload["candles"][-1][0] if payload.get("candles") else -1
        if forming is not None and int(forming["time"]) <= last_closed:
            forming = None
        return {**payload, "forming": forming}

    # -------------------------------------------------------------- info
    def debug(self) -> list[dict[str, Any]]:
        return [{"provider": f.provider.id, "symbol": f.symbol, "subscribers": len(f.subs), "connected": f.connected,
                 "reconnects": f.reconnects, "status": self.status(f).state,
                 "aggregators": {tf: vars(a.stats) for tf, a in f.aggs.items()}} for f in self.feeds.values()]
