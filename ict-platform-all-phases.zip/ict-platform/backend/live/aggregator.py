"""Build OHLC candles from a stream of ticks (or 1-minute bar updates).

Rules
-----
* Bucket = candle open time for the timeframe, using the SAME alignment as the
  historical resampler (UTC multiples up to 1h; 17:00 New York anchors for 4h/1d).
* A tick inside the current bucket updates high / low / close (+ volume).
* A tick in a LATER bucket closes the current candle and opens a new one. Empty
  buckets (no ticks) produce no candle, matching how historical data is stored.
* ``close_due(now)`` closes the current candle once its time is over (plus a
  small grace period for late ticks), even if no new tick arrives.
* Late / out-of-order ticks:
    - older than the current bucket  -> rejected (the closed candle is final;
      changing it would repaint the analysis)
    - older than the last tick but inside the bucket -> may extend high/low,
      never overwrites the close
* Exact duplicates (same timestamp and price as the previous tick) are ignored.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from backend.market_data.resample import bucket_start
from backend.market_data.timeframes import TIMEFRAMES


@dataclass
class AggStats:
    ticks: int = 0
    duplicates: int = 0
    late_rejected: int = 0
    out_of_order: int = 0
    closed: int = 0


@dataclass
class CandleAggregator:
    symbol: str
    timeframe: str
    grace_seconds: float = 2.0
    forming: Optional[dict] = None
    last_tick_ts: float = 0.0
    last_tick_price: Optional[float] = None
    last_closed_time: int = -1  # candles at or before this time are final
    stats: AggStats = field(default_factory=AggStats)
    _minute_volume: dict = field(default_factory=dict)

    @property
    def tf_seconds(self) -> int:
        return TIMEFRAMES[self.timeframe]

    def bucket(self, ts: float) -> int:
        return int(bucket_start(np.array([int(ts)]), self.timeframe)[0])

    def seed(self, candle: Optional[dict], last_closed_time: int = -1) -> None:
        """Start from the provider's still-forming candle (e.g. after (re)connect)."""
        self.forming = dict(candle) if candle else None
        self._minute_volume = {}
        self.last_closed_time = last_closed_time

    def _new(self, b: int, o: float, h: float, l: float, c: float, v: float) -> dict:
        return {"time": b, "open": o, "high": h, "low": l, "close": c, "volume": v}

    def update(self, ts: float, price: float, size: float = 0.0, bar: Optional[dict] = None) -> list[dict]:
        """Apply one update. Returns the list of candles that CLOSED because of it."""
        closed: list[dict] = []
        if bar is not None:
            o, h, l, c, v = bar["open"], bar["high"], bar["low"], bar["close"], float(bar.get("volume") or 0)
            ts = max(ts, float(bar["time"]))
            bar_key = int(bar["time"])
        else:
            if ts == self.last_tick_ts and price == self.last_tick_price:
                self.stats.duplicates += 1
                return closed
            o = h = l = c = price
            v = float(size or 0)
            bar_key = None
        self.stats.ticks += 1
        b = self.bucket(bar_key if bar_key is not None else ts)
        f = self.forming

        if b <= self.last_closed_time or (f is not None and b < f["time"]):
            self.stats.late_rejected += 1
            return closed
        if f is not None and b > f["time"]:
            closed.append(f)
            self.stats.closed += 1
            self.last_closed_time = f["time"]
            f = None
        if f is None:
            self.forming = self._new(b, o, h, l, c, v)
            self._minute_volume = {bar_key: v} if bar_key is not None else {}
        else:
            f["high"] = max(f["high"], h)
            f["low"] = min(f["low"], l)
            in_order = ts >= self.last_tick_ts or bar_key is not None
            if in_order:
                f["close"] = c
            else:
                self.stats.out_of_order += 1
            if bar_key is not None:
                # bar updates repeat the same minute: count each minute's latest volume once
                self._minute_volume[bar_key] = v
                f["volume"] = float(sum(self._minute_volume.values()))
            else:
                f["volume"] += v
        if ts >= self.last_tick_ts:
            self.last_tick_ts, self.last_tick_price = ts, c
        return closed

    def close_due(self, now: float) -> Optional[dict]:
        f = self.forming
        if f is not None and now >= f["time"] + self.tf_seconds + self.grace_seconds:
            self.forming = None
            self._minute_volume = {}
            self.stats.closed += 1
            self.last_closed_time = f["time"]
            return f
        return None
