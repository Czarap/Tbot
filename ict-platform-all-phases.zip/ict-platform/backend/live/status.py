"""Feed status classification. Delayed data is never labelled LIVE.

States
------
live           connected, provider is real-time, last update fresh and close to source time
delayed        connected but updates are old / lagging / provider is not real-time
connecting     (re)connecting, nothing received yet
reconnecting   connection lost, waiting to retry (shows "Connection lost - reconnecting")
disconnected   not connected and not retrying soon (e.g. missing API key / auth error)
market_closed  connected, gold market is closed and no updates are arriving
simulated      offline simulated feed (never LIVE)
historical     provider has no real-time feed (e.g. CSV files)
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass
from typing import Optional

import numpy as np

from backend.market_data.market_hours import is_market_closed

LABELS = {
    "live": "LIVE",
    "delayed": "DELAYED",
    "connecting": "CONNECTING",
    "reconnecting": "DISCONNECTED",
    "disconnected": "DISCONNECTED",
    "market_closed": "MARKET CLOSED",
    "simulated": "SIMULATED",
    "historical": "HISTORICAL",
}


@dataclass
class FeedStatus:
    state: str
    label: str
    symbol: str
    market: str
    provider_id: str
    provider_name: str
    transport: str
    connected: bool
    last_update: Optional[float]  # source timestamp of the newest update
    last_receive: Optional[float]  # when we received it
    lag_seconds: Optional[float]
    message: Optional[str]
    retry_in: Optional[float]
    server_time: float

    def to_dict(self) -> dict:
        return asdict(self)


def classify(*, symbol: str, market: str, provider_id: str, provider_name: str, transport: str, realtime: bool,
             streaming: bool, connected: bool, last_source_ts: Optional[float], last_receive: Optional[float],
             error: Optional[str], retry_at: Optional[float], fatal: bool, poll_seconds: float = 0.0,
             max_live_lag: float = 10.0, stale_after: float = 60.0, now: Optional[float] = None,
             asset_class: str = 'metal') -> FeedStatus:
    now = time.time() if now is None else now
    lag = (now - last_source_ts) if last_source_ts else None
    age = (now - last_receive) if last_receive else None
    retry_in = max(0.0, retry_at - now) if retry_at else None
    msg: Optional[str] = None

    if not streaming:
        state, msg = "historical", "This data source has no real-time feed."
    elif not connected:
        if fatal:
            state, msg = "disconnected", error or "Not connected."
        elif retry_in is not None and error:
            state, msg = "reconnecting", f"Connection lost ({error}). Reconnecting…"
        else:
            state, msg = "connecting", "Connecting to the data provider…"
    elif transport == "simulated":
        state, msg = "simulated", "Simulated ticks for offline testing — not real prices."
        if is_market_closed(np.array([int(now)]), asset_class=asset_class)[0] and (age is None or age > 5):
            state, msg = "market_closed", "Market is closed (simulated feed paused)."
    else:
        live_lag = max_live_lag if transport != "polling" else poll_seconds + 75.0
        stale = stale_after if transport != "polling" else max(stale_after, 3 * poll_seconds)
        closed = bool(is_market_closed(np.array([int(now)]), asset_class=asset_class)[0])
        if closed and (age is None or age > stale):
            state, msg = "market_closed", ("Market is closed (weekend)." if asset_class == "forex" else "Market is closed (reopens Sunday 18:00 New York; daily break 17:00–18:00).")
        elif last_receive is None:
            state, msg = "connecting", "Connected — waiting for the first update…"
        elif age is not None and age > stale:
            state, msg = "delayed", f"No updates for {age:.0f}s."
        elif lag is not None and lag > live_lag:
            state, msg = "delayed", f"Data is {lag:.0f}s behind real time."
        elif not realtime:
            state, msg = "delayed", "Provider does not deliver real-time data."
        else:
            state = "live"
            msg = f"Polling every {poll_seconds:g}s" if transport == "polling" else None
    return FeedStatus(state, LABELS[state], symbol, market, provider_id, provider_name, transport, connected,
                      last_source_ts, last_receive, round(lag, 3) if lag is not None else None, msg,
                      round(retry_in, 1) if retry_in is not None else None, now)
