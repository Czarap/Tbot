"""Backtest runner: market data -> streaming ICT engine -> setups -> trade simulation -> statistics.

The ICT engine is the same streaming engine used by the live chart, fed one
CLOSED candle at a time, so the backtest inherits its no-look-ahead guarantee.
"""
from __future__ import annotations

import time
from typing import Callable, Optional

import pandas as pd

from backend.ict_engine import ICTEngine
from backend.market_data.timeframes import TIMEFRAMES
from backend.services.analysis_service import DISCLAIMER, AnalysisService

from .config import BacktestConfig
from .prop import evaluate_prop
from .simulator import NewsIndex, simulate
from .stats import compute_stats

Progress = Callable[[float, str], None]


def _day_start(s: Optional[str]) -> Optional[int]:
    return int(pd.Timestamp(s, tz="UTC").timestamp()) if s else None


def prepare(analysis: AnalysisService, cfg: BacktestConfig, news: Optional[NewsIndex] = None):
    """Candles + engine context for a config (shared by backtests and the optimizer)."""
    data = analysis.data
    prov = data.provider(cfg.provider, cfg.symbol)
    info = prov.get_symbol_info(cfg.symbol)
    df = data.get_candles(cfg.symbol, cfg.timeframe, prov.id).df
    if df.empty:
        raise LookupError(f"No candles for {cfg.symbol} {cfg.timeframe} from {prov.id}")
    start_t = _day_start(cfg.start) or int(df["time"].iloc[0])
    end_t = (_day_start(cfg.end) + 86400 - 1) if cfg.end else int(df["time"].iloc[-1])
    df = df[df["time"] <= end_t]
    first = int((df["time"] >= start_t).to_numpy().argmax()) if (df["time"] >= start_t).any() else len(df)
    if first >= len(df):
        raise LookupError("No candles inside the selected date range")
    warm = max(0, first - cfg.warmup_candles)
    work = df.iloc[warm:].reset_index(drop=True)
    settings = cfg.settings.model_copy(deep=True)
    settings.setups.min_rr = cfg.min_rr
    ctx = analysis.build_context(cfg.symbol, cfg.timeframe, settings, int(work["time"].iloc[0]), prov.id)
    ctx.extra.pop("news", None)
    if news is not None:
        ctx.extra["news"] = news
    return prov, info, work, first - warm, start_t, end_t, settings, ctx


def generate_setups(work: pd.DataFrame, settings, ctx, symbol: str, timeframe: str, precision: int,
                    progress: Optional[Progress] = None, p0: float = 0.0, p1: float = 1.0) -> list[dict]:
    eng = ICTEngine(settings, symbol, timeframe, TIMEFRAMES[timeframe], ctx, precision=precision)
    rows = work[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None)
    n = len(work)
    for k, (t, o, h, l, c, v) in enumerate(rows):
        eng.update(t, o, h, l, c, v)
        if progress and k % 1000 == 0:
            progress(p0 + (p1 - p0) * k / max(1, n), f"Analysing candle {k:,}/{n:,}")
    index = {int(t): i for i, t in enumerate(work["time"])}
    out = []
    for s in eng.setup_engine.setups:
        d = s.to_dict()
        d["_i"] = index[int(s.time)]
        out.append(d)
    return out


def run_backtest(analysis: AnalysisService, cfg: BacktestConfig, news: Optional[NewsIndex] = None,
                 progress: Optional[Progress] = None) -> dict:
    t0 = time.perf_counter()
    if progress:
        progress(0.02, "Loading candles")
    if news is None and cfg.news.enabled:
        data_df = analysis.data.get_candles(cfg.symbol, cfg.timeframe, analysis.data.provider(cfg.provider, cfg.symbol).id).df
        if len(data_df):
            s0 = _day_start(cfg.start) or int(data_df["time"].iloc[0])
            e0 = (_day_start(cfg.end) + 86400) if cfg.end else int(data_df["time"].iloc[-1])
            news = analysis.news_index(s0 - 86400, e0 + 86400, cfg.news.currencies, cfg.news.min_importance)
    prov, info, work, first, start_t, end_t, settings, ctx = prepare(analysis, cfg, news)
    setups = generate_setups(work, settings, ctx, cfg.symbol, cfg.timeframe, info.price_precision, progress, 0.05, 0.85)
    if progress:
        progress(0.9, "Simulating trades")
    bal = cfg.prop.starting_balance if cfg.prop.enabled else cfg.starting_balance
    arr = {k: work[k].to_numpy() for k in ("time", "open", "high", "low", "close")}
    sim = simulate(arr["time"], arr["open"], arr["high"], arr["low"], arr["close"], setups, cfg, info, news,
                   start_time=start_t, end_time=end_t, starting_balance=bal)
    trades = sim["trades"]
    shown = work.iloc[first:]
    period = (int(shown["time"].iloc[0]), int(shown["time"].iloc[-1]))
    report = compute_stats(trades, sim["equity"], bal, period)
    warnings = []
    n = report["stats"]["total_trades"]
    if n < 30:
        warnings.append(f"Only {n} trades — too few for reliable statistics. Use a longer date range or more data.")
    if len(shown) < 2000:
        warnings.append(f"Only {len(shown):,} candles in the test period (provider history may be short; import a CSV for longer tests).")
    if news is None and cfg.news.enabled:
        warnings.append("News filter is on but no economic-calendar data was available for this period.")
    candles = [[int(r[0]), r[1], r[2], r[3], r[4], r[5]] for r in shown[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None)]
    if progress:
        progress(1.0, "Done")
    return {
        "config": cfg.model_dump(),
        "symbol_info": info.to_dict(),
        "provider": prov.info().to_dict(),
        "period": {"start": period[0], "end": period[1], "candles": len(shown), "warmup_candles": first},
        "candles": candles,
        "trades": [t.to_dict() for t in trades],
        "equity": sim["equity"],
        "skipped": sim["skipped"],
        "setups_found": sum(1 for s in setups if start_t <= s["time"] <= end_t),
        "starting_balance": bal,
        "final_balance": sim["final_balance"],
        **report,
        "prop": evaluate_prop(trades, cfg.prop) if cfg.prop.enabled else None,
        "warnings": warnings,
        "compute_ms": round((time.perf_counter() - t0) * 1000),
        "disclaimer": DISCLAIMER,
    }
