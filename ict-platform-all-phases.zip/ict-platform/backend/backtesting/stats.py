"""Backtest statistics."""
from __future__ import annotations

from collections import defaultdict
from typing import Iterable

import numpy as np
import pandas as pd

from backend.market_data.market_hours import trading_date

from .simulator import Trade


def _streaks(results: list[str]) -> tuple[int, int]:
    best_w = best_l = cur_w = cur_l = 0
    for r in results:
        if r == "WIN":
            cur_w, cur_l = cur_w + 1, 0
        elif r == "LOSS":
            cur_l, cur_w = cur_l + 1, 0
        else:
            cur_w = cur_l = 0
        best_w, best_l = max(best_w, cur_w), max(best_l, cur_l)
    return best_w, best_l


def _group(trades: Iterable[Trade], key) -> list[dict]:
    g: dict = defaultdict(list)
    for tr in trades:
        g[key(tr)].append(tr)
    out = []
    for k, ts in g.items():
        wins = sum(1 for x in ts if x.result == "WIN")
        out.append({"key": k, "trades": len(ts), "wins": wins, "win_rate": round(wins / len(ts) * 100, 1),
                    "net_r": round(sum(x.r_multiple for x in ts), 2), "net_pnl": round(sum(x.pnl for x in ts), 2),
                    "avg_r": round(float(np.mean([x.r_multiple for x in ts])), 3)})
    return out


def drawdown_curve(equity: list[dict]) -> list[dict]:
    peak = -float("inf")
    out = []
    for p in equity:
        peak = max(peak, p["balance"])
        dd = p["balance"] - peak
        out.append({"time": p["time"], "drawdown": round(dd, 2), "drawdown_pct": round(dd / peak * 100, 3) if peak > 0 else 0.0})
    return out


def compute_stats(trades: list[Trade], equity: list[dict], starting_balance: float, period: tuple[int, int] | None = None) -> dict:
    closed = [t for t in trades if t.exit_time is not None]
    n = len(closed)
    wins = [t for t in closed if t.result == "WIN"]
    losses = [t for t in closed if t.result == "LOSS"]
    gross_win = sum(t.pnl for t in wins)
    gross_loss = -sum(t.pnl for t in losses)
    rs = [t.r_multiple for t in closed]
    dd = drawdown_curve(equity)
    max_dd = min((p["drawdown"] for p in dd), default=0.0)
    max_dd_pct = min((p["drawdown_pct"] for p in dd), default=0.0)
    best_w, best_l = _streaks([t.result for t in closed])
    days = trading_date(np.array([t.entry_time for t in closed], dtype="int64")) if n else []
    ny = lambda ts: pd.Timestamp(ts, unit="s", tz="UTC").tz_convert("America/New_York")  # noqa: E731
    monthly = _group(closed, lambda t: ny(t.exit_time).strftime("%Y-%m"))
    monthly.sort(key=lambda x: x["key"])
    stats = {
        "total_trades": n,
        "winning_trades": len(wins),
        "losing_trades": len(losses),
        "breakeven_trades": n - len(wins) - len(losses),
        "win_rate": round(len(wins) / n * 100, 2) if n else 0.0,
        "average_r": round(float(np.mean(rs)), 3) if n else 0.0,
        "net_r": round(float(np.sum(rs)), 2) if n else 0.0,
        "net_profit": round(sum(t.pnl for t in closed), 2),
        "return_pct": round(sum(t.pnl for t in closed) / starting_balance * 100, 2),
        "profit_factor": round(gross_win / gross_loss, 3) if gross_loss > 0 else (None if gross_win == 0 else float("inf")),
        "expectancy_r": round(float(np.mean(rs)), 3) if n else 0.0,
        "expectancy_money": round(sum(t.pnl for t in closed) / n, 2) if n else 0.0,
        "max_drawdown": round(max_dd, 2),
        "max_drawdown_pct": round(max_dd_pct, 3),
        "max_consecutive_wins": best_w,
        "max_consecutive_losses": best_l,
        "largest_win": round(max((t.pnl for t in closed), default=0.0), 2),
        "largest_loss": round(min((t.pnl for t in closed), default=0.0), 2),
        "average_trade_duration_seconds": int(np.mean([t.duration_seconds for t in closed])) if n else 0,
        "total_trading_days": int(len(set(days))) if n else 0,
        "commission_paid": round(sum(t.commission for t in closed), 2),
    }
    if stats["profit_factor"] == float("inf"):
        stats["profit_factor"] = None  # JSON-safe; UI shows "∞ (no losses)"
        stats["profit_factor_note"] = "no losing trades"
    if period:
        stats["period_start"], stats["period_end"] = int(period[0]), int(period[1])
    return {
        "stats": stats,
        "monthly": monthly,
        "by_session": sorted(_group(closed, lambda t: t.session or "Outside sessions"), key=lambda x: -x["trades"]),
        "by_setup_type": sorted(_group(closed, lambda t: t.setup_type), key=lambda x: -x["trades"]),
        "by_direction": _group(closed, lambda t: "Long" if t.direction == "bullish" else "Short"),
        "by_score": sorted(_group(closed, lambda t: f"{t.score}/{t.max_score}"), key=lambda x: x["key"]),
        "drawdown": dd,
    }
