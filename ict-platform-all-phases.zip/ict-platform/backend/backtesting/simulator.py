"""Chronological trade simulation from ICT setups.

ORDER OF EVENTS FOR CANDLE i (no look-ahead)
--------------------------------------------
1. A setup signalled at the CLOSE of candle i-1 is filled at the OPEN of candle i
   (market order: + half spread + slippage against you). The trade is skipped
   if the open has already gapped through the stop or the target.
2. Open trades are checked against candle i's high/low:
     long : low <= SL -> stop,  high >= TP -> target
     short: high >= SL -> stop, low <= TP -> target
   If both are inside the same candle the order is unknown from OHLC data; by
   default the STOP is assumed first (conservative, ``same_bar="sl_first"``).
   A candle that OPENS beyond a level exits at the open (gap fill).
3. New setups at the close of candle i are filtered (date range, direction,
   session, max trades per day, news window, R:R after costs, one trade at a
   time) and queued for the open of candle i+1.

Prices are treated as mid prices; ``costs.spread`` adds half the spread to
each side. P&L = price move x lots x contract size (- commission).
"""
from __future__ import annotations

import math
from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Optional

import numpy as np

from backend.market_data.base import SymbolInfo
from backend.market_data.calendar import NewsIndex  # noqa: F401 - re-exported
from backend.market_data.market_hours import trading_date

from .config import BacktestConfig


@dataclass
class Trade:
    id: str
    setup_id: str
    symbol: str
    timeframe: str
    direction: str
    signal_time: int
    entry_time: int
    entry: float
    stop_loss: float
    take_profit: float
    lots: float
    risk_amount: float
    planned_reward: float
    rr: float
    score: int
    max_score: int
    session: Optional[str]
    htf_bias: Optional[str]
    liquidity_event: Optional[str]
    fvg: Optional[str]
    order_block: Optional[str]
    displacement: Optional[str]
    setup_type: str
    exit_time: Optional[int] = None
    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None  # TP | SL | END
    result: str = "OPEN"  # WIN | LOSS | BREAKEVEN | OPEN
    pnl: float = 0.0
    commission: float = 0.0
    r_multiple: float = 0.0
    duration_seconds: int = 0
    balance_after: Optional[float] = None
    notes: str = ""
    factors: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def _factor(setup: dict, key: str) -> Optional[dict]:
    return next((f for f in setup.get("factors", []) if f["key"] == key), None)


def setup_type(setup: dict) -> str:
    parts = []
    for key, label in (("liquidity_sweep", "Liquidity Sweep"), ("order_block", "Order Block"), ("fvg", "FVG")):
        f = _factor(setup, key)
        if f and f.get("passed"):
            parts.append(label)
    return " + ".join(parts) if parts else "FVG"


def _passed_detail(setup: dict, key: str) -> Optional[str]:
    f = _factor(setup, key)
    return f["detail"] if f and f.get("passed") else None


def position_size(cfg: BacktestConfig, balance: float, stop_distance: float, contract: float, fx: float) -> tuple[float, float, list[str]]:
    """Returns (lots, risk_amount, notes). ``fx`` converts quote-currency P&L to account currency."""
    notes: list[str] = []
    r = cfg.risk
    per_lot = stop_distance * contract * fx  # money lost per 1.00 lot at the stop
    if per_lot <= 0:
        return 0.0, 0.0, ["zero stop distance"]
    if r.mode == "fixed_lots":
        lots = r.lots
    else:
        risk = balance * r.risk_percent / 100 if r.mode == "fixed_percent" else r.risk_dollar
        lots = risk / per_lot
    lots = math.floor(lots / r.lot_step + 1e-9) * r.lot_step
    if lots < r.min_lots:
        notes.append(f"position raised to minimum {r.min_lots} lots")
        lots = r.min_lots
    if lots > r.max_lots:
        notes.append(f"position capped at maximum {r.max_lots} lots")
        lots = r.max_lots
    lots = round(lots, 6)
    return lots, round(lots * per_lot, 2), notes


def simulate(t: np.ndarray, o: np.ndarray, h: np.ndarray, l: np.ndarray, c: np.ndarray, setups: list[dict],
             cfg: BacktestConfig, info: SymbolInfo, news: Optional[NewsIndex] = None,
             start_time: Optional[int] = None, end_time: Optional[int] = None,
             starting_balance: Optional[float] = None) -> dict:
    t = np.asarray(t, dtype="int64")
    o, h, l, c = (np.asarray(x, dtype=float).tolist() for x in (o, h, l, c))
    n = len(t)
    balance = float(starting_balance if starting_balance is not None else cfg.starting_balance)
    half = cfg.costs.spread / 2
    slip = cfg.costs.slippage
    contract = info.contract_size
    by_index: dict[int, list[dict]] = {}
    for s in setups:
        by_index.setdefault(int(s["_i"]), []).append(s)
    tdays = trading_date(t) if n else []
    entries_per_day: Counter = Counter()
    skipped: Counter = Counter()
    trades: list[Trade] = []
    open_t: Optional[Trade] = None
    pending: Optional[dict] = None
    equity = [{"time": int(start_time if start_time is not None else (t[0] if n else 0)), "balance": balance}]
    sess_ok = set(cfg.sessions)

    def fx_at(price: float) -> float:
        return 1.0 / price if info.quote_currency == "JPY" else 1.0

    def close(tr: Trade, i: int, price: float, reason: str) -> None:
        nonlocal balance, open_t
        d = 1 if tr.direction == "bullish" else -1
        exit_px = price - d * half
        gross = (exit_px - tr.entry) * d * tr.lots * contract * fx_at(exit_px)
        tr.commission = round(cfg.costs.commission_per_lot * tr.lots, 2)
        tr.pnl = round(gross - tr.commission, 2)
        tr.exit_time, tr.exit_price, tr.exit_reason = int(t[i]), round(exit_px, info.price_precision + 1), reason
        tr.r_multiple = round(tr.pnl / tr.risk_amount, 3) if tr.risk_amount else 0.0
        tr.result = "WIN" if tr.pnl > 0 else "LOSS" if tr.pnl < 0 else "BREAKEVEN"
        tr.duration_seconds = int(t[i] - tr.entry_time)
        balance = round(balance + tr.pnl, 2)
        tr.balance_after = balance
        equity.append({"time": int(t[i]), "balance": balance})
        open_t = None

    for i in range(n):
        # 1) fill a queued signal at this candle's open
        if pending is not None:
            s = pending
            pending = None
            d = 1 if s["direction"] == "bullish" else -1
            fill = o[i] + d * (half + slip)
            sl, tp = float(s["stop_loss"]), float(s["take_profit"])
            if (d == 1 and o[i] <= sl) or (d == -1 and o[i] >= sl):
                skipped["gapped through stop before entry"] += 1
            elif (d == 1 and o[i] >= tp) or (d == -1 and o[i] <= tp):
                skipped["target reached before entry"] += 1
            else:
                dist = abs(fill - sl)
                rr = abs(tp - fill) / dist if dist > 0 else 0
                if rr + 1e-9 < cfg.min_rr:
                    skipped["R:R below minimum after costs"] += 1
                else:
                    lots, risk_amt, _ = position_size(cfg, balance, dist, contract, fx_at(fill))
                    if lots <= 0:
                        skipped["position size zero"] += 1
                    else:
                        entries_per_day[tdays[i]] += 1
                        open_t = Trade(
                            id=f"T{len(trades) + 1:05d}", setup_id=s["id"], symbol=s["symbol"], timeframe=s["timeframe"],
                            direction=s["direction"], signal_time=int(s["time"]), entry_time=int(t[i]),
                            entry=round(fill, info.price_precision + 1), stop_loss=sl, take_profit=tp, lots=lots,
                            risk_amount=risk_amt, planned_reward=round(risk_amt * rr, 2), rr=round(rr, 2),
                            score=s["score"], max_score=s["max_score"], session=s.get("session"), htf_bias=s.get("htf_bias"),
                            liquidity_event=_passed_detail(s, "liquidity_sweep"), fvg=_passed_detail(s, "fvg"),
                            order_block=_passed_detail(s, "order_block"), displacement=_passed_detail(s, "displacement"),
                            setup_type=setup_type(s), factors=[{k: f[k] for k in ("key", "label", "mode", "passed", "points")} for f in s["factors"]],
                        )
                        trades.append(open_t)

        # 2) manage the open trade with this candle
        if open_t is not None and open_t.entry_time <= t[i]:
            tr = open_t
            d = 1 if tr.direction == "bullish" else -1
            sl, tp = tr.stop_loss, tr.take_profit
            if d == 1:
                gap_sl, gap_tp = o[i] <= sl, o[i] >= tp
                hit_sl, hit_tp = l[i] <= sl, h[i] >= tp
            else:
                gap_sl, gap_tp = o[i] >= sl, o[i] <= tp
                hit_sl, hit_tp = h[i] >= sl, l[i] <= tp
            if tr.entry_time < t[i] and gap_sl:
                close(tr, i, o[i] - d * slip, "SL")
            elif tr.entry_time < t[i] and gap_tp:
                close(tr, i, o[i], "TP")
            elif hit_sl and hit_tp:
                if cfg.same_bar == "tp_first":
                    close(tr, i, tp, "TP")
                else:
                    close(tr, i, sl - d * slip, "SL")
            elif hit_sl:
                close(tr, i, sl - d * slip, "SL")
            elif hit_tp:
                close(tr, i, tp, "TP")

        # 3) new signals at this candle's close
        for s in by_index.get(i, []):
            st = int(s["time"])
            if (start_time is not None and st < start_time) or (end_time is not None and st > end_time):
                continue
            if i + 1 >= n:
                skipped["signal on the last candle"] += 1
                continue
            if s["direction"] not in cfg.directions:
                skipped["direction filtered"] += 1
            elif sess_ok and info and TF_INTRADAY(s["timeframe"]) and (s.get("session") not in sess_ok):
                skipped["outside selected sessions"] += 1
            elif open_t is not None or pending is not None:
                skipped["already in a trade"] += 1
            elif entries_per_day[tdays[i + 1]] >= cfg.max_trades_per_day:
                skipped["max trades per day reached"] += 1
            elif cfg.news.enabled and news is not None and news.covers(int(t[i + 1])) and \
                    news.blocking(int(t[i + 1]), cfg.news.minutes_before * 60, cfg.news.minutes_after * 60):
                skipped["news filter"] += 1
            else:
                pending = s

    if open_t is not None and n:
        close(open_t, n - 1, c[n - 1], "END")
    return {"trades": trades, "equity": equity, "skipped": dict(skipped), "final_balance": balance}


def TF_INTRADAY(tf: str) -> bool:  # noqa: N802 - sessions only make sense up to 1h
    return tf in ("1m", "5m", "15m", "30m", "1h")
