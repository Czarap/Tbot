"""Backtesting engine - Phase 3 (not implemented yet).

The MVP is built so the backtester can reuse the analysis engine unchanged:

    engine = ICTEngine(settings, symbol, timeframe, tf_seconds, context)
    for candle in candles:                       # strictly chronological
        events = engine.update(*candle)          # only data up to this candle
        for ev in events:
            if ev["kind"] == "setup":
                open_simulated_trade(ev["data"])  # entry = close of this candle
        manage_open_trades(candle)                # SL/TP checked on LATER candles only

Because the engine is streaming and append-only, the backtest inherits its
no-look-ahead guarantee (see tests/test_no_lookahead.py).
"""
