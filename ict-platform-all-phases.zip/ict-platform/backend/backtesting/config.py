"""Backtest / prop-firm configuration (validated, also used as API schema)."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator

from backend.ict_engine.settings import ICTSettings

Timeframe = Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


class RiskSettings(BaseModel):
    mode: Literal["fixed_percent", "fixed_dollar", "fixed_lots"] = "fixed_percent"
    risk_percent: float = Field(0.5, gt=0, le=10, description="% of current balance risked per trade")
    risk_dollar: float = Field(250.0, gt=0)
    lots: float = Field(1.0, gt=0)
    min_lots: float = Field(0.01, gt=0)
    max_lots: float = Field(50.0, gt=0)
    lot_step: float = Field(0.01, gt=0)

    @model_validator(mode="after")
    def _check(self):
        if self.min_lots > self.max_lots:
            raise ValueError("min_lots must be <= max_lots")
        return self


class CostSettings(BaseModel):
    spread: float = Field(0.20, ge=0, description="Full spread in price units, paid on entry/exit (half each side)")
    slippage: float = Field(0.05, ge=0, description="Adverse slippage on market fills (entry and stop) in price units")
    commission_per_lot: float = Field(7.0, ge=0, description="Round-trip commission per 1.00 lot, account currency")


class NewsFilter(BaseModel):
    enabled: bool = True
    minutes_before: int = Field(15, ge=0, le=1440)
    minutes_after: int = Field(15, ge=0, le=1440)
    min_importance: Literal["medium", "high"] = "high"
    currencies: list[str] = Field(default_factory=lambda: ["USD"])


class PropFirmRules(BaseModel):
    enabled: bool = False
    starting_balance: float = Field(50_000, gt=0)
    daily_loss_limit: float = Field(2_500, gt=0)
    max_drawdown: float = Field(5_000, gt=0)
    drawdown_mode: Literal["static", "trailing"] = "static"
    profit_target: float = Field(3_000, gt=0)
    max_trades_per_day: Optional[int] = Field(None, ge=1, le=100)
    min_trading_days: int = Field(0, ge=0, le=100)


class BacktestConfig(BaseModel):
    symbol: str = Field("XAUUSD", pattern=r"^[A-Z0-9]{2,12}$")
    timeframe: Timeframe = "15m"
    provider: Optional[str] = Field(None, pattern=r"^[a-z_]{2,32}$")
    start: Optional[str] = Field(None, description="YYYY-MM-DD (UTC). Empty = from the first available candle")
    end: Optional[str] = Field(None, description="YYYY-MM-DD (UTC, inclusive). Empty = up to the last closed candle")
    starting_balance: float = Field(50_000, gt=0)
    risk: RiskSettings = Field(default_factory=RiskSettings)
    costs: CostSettings = Field(default_factory=CostSettings)
    min_rr: float = Field(2.0, ge=0.1, le=20)
    max_trades_per_day: int = Field(2, ge=1, le=100)
    sessions: list[str] = Field(default_factory=lambda: ["London", "New York"], description="Empty = any time")
    directions: list[Literal["bullish", "bearish"]] = Field(default_factory=lambda: ["bullish", "bearish"])
    news: NewsFilter = Field(default_factory=NewsFilter)
    entry: Literal["next_open"] = "next_open"
    same_bar: Literal["sl_first", "tp_first"] = Field("sl_first", description="If SL and TP are both inside one candle")
    prop: PropFirmRules = Field(default_factory=PropFirmRules)
    settings: ICTSettings = Field(default_factory=ICTSettings)
    warmup_candles: int = Field(500, ge=50, le=5000)
