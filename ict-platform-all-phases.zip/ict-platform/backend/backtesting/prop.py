"""Prop-firm rule simulation on a sequence of closed trades.

Rules (all configurable, because every firm differs):
* Daily loss limit  : closed P&L of one trading day (17:00 New York rollover)
                      may not fall below -daily_loss_limit.
* Max drawdown      : static  -> balance may not fall below start - max_drawdown
                      trailing -> balance may not fall below (highest balance - max_drawdown),
                                  the floor never rises above the starting balance
* Profit target     : balance >= start + profit_target (and min_trading_days met) -> PASSED
* Max trades per day: optional; extra trades count as a rule violation.

Evaluated on CLOSED trades (floating P&L is not available from candle data), so
real intraday breaches can happen earlier than reported here.
"""
from __future__ import annotations

from collections import defaultdict

import numpy as np

from backend.market_data.market_hours import trading_date

from .config import PropFirmRules
from .simulator import Trade


def evaluate_prop(trades: list[Trade], rules: PropFirmRules) -> dict:
    start = rules.starting_balance
    balance = start
    peak = start
    floor = start - rules.max_drawdown
    closed = sorted([t for t in trades if t.exit_time is not None], key=lambda t: t.exit_time)
    days = trading_date(np.array([t.exit_time for t in closed], dtype="int64")) if closed else []
    daily: dict = defaultdict(float)
    count: dict = defaultdict(int)
    status, reason, when = "ACTIVE", None, None
    max_dd = 0.0
    worst_day = 0.0
    passed_at = None
    for tr, day in zip(closed, days):
        key = str(day.date())
        balance += tr.pnl
        daily[key] += tr.pnl
        count[key] += 1
        peak = max(peak, balance)
        if rules.drawdown_mode == "trailing":
            floor = min(start, max(floor, peak - rules.max_drawdown))
        max_dd = max(max_dd, (peak if rules.drawdown_mode == "trailing" else start) - balance)
        worst_day = min(worst_day, daily[key])
        if status != "ACTIVE":
            continue
        if daily[key] <= -rules.daily_loss_limit:
            status, reason, when = "BREACHED", f"Daily loss limit: {daily[key]:,.2f} on {key}", tr.exit_time
        elif balance <= floor:
            status, reason, when = "BREACHED", f"Max drawdown: balance {balance:,.2f} <= floor {floor:,.2f}", tr.exit_time
        elif rules.max_trades_per_day and count[key] > rules.max_trades_per_day:
            status, reason, when = "BREACHED", f"More than {rules.max_trades_per_day} trades on {key}", tr.exit_time
        elif balance >= start + rules.profit_target and len(daily) >= rules.min_trading_days:
            status, passed_at = "PASSED", tr.exit_time
    return {
        "status": status,
        "breached": status == "BREACHED",
        "reason": reason,
        "breach_time": when,
        "passed_time": passed_at,
        "starting_balance": start,
        "current_balance": round(balance, 2),
        "profit": round(balance - start, 2),
        "profit_target": rules.profit_target,
        "target_progress_pct": round(max(0.0, (balance - start) / rules.profit_target * 100), 1),
        "max_drawdown_reached": round(max_dd, 2),
        "max_drawdown_limit": rules.max_drawdown,
        "worst_daily_loss": round(worst_day, 2),
        "daily_loss_limit": rules.daily_loss_limit,
        "drawdown_floor": round(floor, 2),
        "trading_days": len(daily),
        "daily": [{"day": k, "pnl": round(v, 2), "trades": count[k]} for k, v in sorted(daily.items())],
        "note": "Evaluated on closed trades only; intraday floating losses are not modelled.",
    }
