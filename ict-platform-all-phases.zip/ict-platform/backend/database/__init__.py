"""SQLite storage for strategy profiles, backtest runs and the trade journal."""
