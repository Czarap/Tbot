"""SQLite store (stdlib sqlite3). File: data/ict.db (override with ICT_DB_PATH).

Tables
  profiles   named strategy profiles (ICT settings + backtest parameters)
  runs       saved backtest runs (config + statistics)
  journal    every simulated trade of a run, with user notes
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Any, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  settings TEXT NOT NULL,
  backtest TEXT,
  created REAL NOT NULL,
  updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY,
  created REAL NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  name TEXT,
  config TEXT NOT NULL,
  stats TEXT NOT NULL,
  extra TEXT
);
CREATE TABLE IF NOT EXISTS journal (
  run_id TEXT NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  trade_id TEXT NOT NULL,
  entry_time INTEGER NOT NULL,
  data TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (run_id, trade_id)
);
CREATE INDEX IF NOT EXISTS journal_time ON journal(run_id, entry_time);
"""


class Store:
    def __init__(self, path: str):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    @classmethod
    def from_env(cls) -> "Store":
        default = os.path.join(os.path.dirname(__file__), "..", "..", "data", "ict.db")
        return cls(os.path.abspath(os.environ.get("ICT_DB_PATH", default)))

    def _q(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            cur = self._conn.execute(sql, args)
            rows = cur.fetchall()
            self._conn.commit()
            return rows

    # ------------------------------------------------------------- profiles
    def list_profiles(self) -> list[dict]:
        return [{"id": r["id"], "name": r["name"], "settings": json.loads(r["settings"]),
                 "backtest": json.loads(r["backtest"]) if r["backtest"] else None, "updated": r["updated"]}
                for r in self._q("SELECT * FROM profiles ORDER BY name")]

    def save_profile(self, name: str, settings: dict, backtest: Optional[dict] = None) -> dict:
        now = time.time()
        self._q("""INSERT INTO profiles(name, settings, backtest, created, updated) VALUES (?,?,?,?,?)
                   ON CONFLICT(name) DO UPDATE SET settings=excluded.settings, backtest=excluded.backtest, updated=excluded.updated""",
                (name, json.dumps(settings), json.dumps(backtest) if backtest is not None else None, now, now))
        return next(p for p in self.list_profiles() if p["name"] == name)

    def delete_profile(self, profile_id: int) -> bool:
        self._q("DELETE FROM profiles WHERE id=?", (profile_id,))
        return True

    # ---------------------------------------------------------------- runs
    def save_run(self, run_id: str, result: dict, name: Optional[str] = None) -> None:
        cfg = result["config"]
        extra = {k: result.get(k) for k in ("monthly", "by_session", "by_setup_type", "equity", "prop", "skipped", "period", "warnings")}
        with self._lock:
            self._conn.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?,?,?)",
                               (run_id, time.time(), cfg["symbol"], cfg["timeframe"], name, json.dumps(cfg),
                                json.dumps(result["stats"]), json.dumps(extra)))
            self._conn.executemany("INSERT OR REPLACE INTO journal(run_id, trade_id, entry_time, data, notes) VALUES (?,?,?,?,?)",
                                   [(run_id, t["id"], t["entry_time"], json.dumps(t), t.get("notes", "")) for t in result["trades"]])
            self._conn.commit()

    def list_runs(self) -> list[dict]:
        rows = self._q("SELECT id, created, symbol, timeframe, name, stats, config FROM runs ORDER BY created DESC LIMIT 200")
        out = []
        for r in rows:
            st, cfg = json.loads(r["stats"]), json.loads(r["config"])
            out.append({"id": r["id"], "created": r["created"], "symbol": r["symbol"], "timeframe": r["timeframe"], "name": r["name"],
                        "start": cfg.get("start"), "end": cfg.get("end"), "provider": cfg.get("provider"),
                        "stats": {k: st.get(k) for k in ("total_trades", "win_rate", "net_r", "profit_factor", "max_drawdown_pct", "return_pct")}})
        return out

    def get_run(self, run_id: str) -> Optional[dict]:
        rows = self._q("SELECT * FROM runs WHERE id=?", (run_id,))
        if not rows:
            return None
        r = rows[0]
        trades = []
        for j in self._q("SELECT data, notes FROM journal WHERE run_id=? ORDER BY entry_time", (run_id,)):
            t = json.loads(j["data"])
            t["notes"] = j["notes"]
            trades.append(t)
        return {"id": r["id"], "created": r["created"], "name": r["name"], "config": json.loads(r["config"]),
                "stats": json.loads(r["stats"]), **(json.loads(r["extra"]) if r["extra"] else {}), "trades": trades}

    def delete_run(self, run_id: str) -> None:
        self._q("DELETE FROM runs WHERE id=?", (run_id,))

    def set_note(self, run_id: str, trade_id: str, notes: str) -> bool:
        with self._lock:
            cur = self._conn.execute("UPDATE journal SET notes=? WHERE run_id=? AND trade_id=?", (notes, run_id, trade_id))
            self._conn.commit()
            return cur.rowcount > 0

    def notes_for(self, run_id: str) -> dict[str, str]:
        return {r["trade_id"]: r["notes"] for r in self._q("SELECT trade_id, notes FROM journal WHERE run_id=?", (run_id,))}

    def raw(self, sql: str, args: tuple = ()) -> list[dict[str, Any]]:  # for tests
        return [dict(r) for r in self._q(sql, args)]
