from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

from backend.ict_engine.settings import ICTSettings

TimeframeLit = Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


class AnalysisRequest(BaseModel):
    symbol: str = Field("XAUUSD", pattern=r"^[A-Z0-9]{3,12}$")
    timeframe: TimeframeLit = "15m"
    limit: int = Field(1000, ge=100, le=5000)
    provider: Optional[str] = Field(None, pattern=r"^[a-z_]{2,32}$")
    settings: ICTSettings = Field(default_factory=ICTSettings)
