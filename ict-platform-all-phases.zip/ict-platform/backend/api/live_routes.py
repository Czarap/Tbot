"""Real-time endpoints.

* ``/ws/live``           WebSocket (primary). Client messages:
      {"action": "subscribe", "symbol": "XAUUSD", "timeframe": "15m",
       "provider": null, "limit": 1500, "settings": {...}}
      {"action": "unsubscribe"}   {"action": "ping"}
* ``/api/live/stream``   Server-Sent Events fallback (same server messages),
                         for networks/proxies that block WebSockets.
* ``/api/live/status``   feed diagnostics.

Server messages: hello, status, snapshot, candle (forming), candle_closed,
analysis, error, pong. Candles use the normalised format
{timestamp, open, high, low, close, volume, symbol, timeframe}.
"""
from __future__ import annotations

import asyncio
import json
import time
from typing import Literal, Optional

from fastapi import APIRouter, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, ValidationError

from backend.ict_engine.settings import ICTSettings
from backend.live.hub import Client, LiveHub

HELLO = {"type": "hello", "analysis_only": True, "auto_trading": False}


class LiveSubscribe(BaseModel):
    action: Literal["subscribe"]
    symbol: str = Field("XAUUSD", pattern=r"^[A-Z0-9]{2,12}$")
    timeframe: Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"] = "15m"
    provider: Optional[str] = Field(None, pattern=r"^[a-z_]{2,32}$")
    limit: int = Field(1500, ge=100, le=5000)
    settings: ICTSettings = Field(default_factory=ICTSettings)


def _err(msg: str) -> dict:
    return {"type": "error", "message": msg}


def build_live_router(hub: LiveHub) -> APIRouter:
    router = APIRouter()

    async def _subscribe(client: Client, req: LiveSubscribe) -> None:
        try:
            await hub.subscribe(client, req.symbol, req.timeframe, req.provider, req.limit, req.settings)
        except KeyError as exc:
            client.put(_err(str(exc).strip("'\"")))
        except (LookupError, ValueError) as exc:
            client.put(_err(str(exc)))
        except Exception as exc:  # noqa: BLE001 - provider/network problems
            client.put(_err(f"Could not load data: {exc}"))

    @router.websocket("/ws/live")
    async def ws_live(websocket: WebSocket) -> None:
        await websocket.accept()
        client = Client(lambda m: websocket.send_text(json.dumps(m)), "ws")
        writer = asyncio.create_task(client.writer())
        client.put({**HELLO, "server_time": time.time(), "transport": "websocket"})
        window: list[float] = []
        try:
            while True:
                raw = await websocket.receive_text()
                now = time.time()
                window = [t for t in window if now - t < 10] + [now]
                if len(window) > 30:  # basic client rate limit
                    client.put(_err("Too many messages; slow down."))
                    continue
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    client.put(_err("Invalid JSON"))
                    continue
                action = msg.get("action")
                if action == "ping":
                    client.put({"type": "pong", "server_time": now})
                elif action == "unsubscribe":
                    hub.unsubscribe(client)
                elif action == "subscribe":
                    try:
                        req = LiveSubscribe.model_validate(msg)
                    except ValidationError as exc:
                        client.put(_err(f"Invalid subscription: {exc.errors(include_url=False)[:3]}"))
                        continue
                    asyncio.create_task(_subscribe(client, req))
                else:
                    client.put(_err(f"Unknown action {action!r}"))
        except WebSocketDisconnect:
            pass
        finally:
            hub.unsubscribe(client)
            client.closed = True
            writer.cancel()

    @router.get("/api/live/stream")
    async def sse_live(
        request: Request,
        symbol: str = Query("XAUUSD", pattern=r"^[A-Z0-9]{2,12}$"),
        timeframe: Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"] = Query("15m"),
        provider: Optional[str] = Query(None, pattern=r"^[a-z_]{2,32}$"),
        limit: int = Query(1500, ge=100, le=5000),
        settings: Optional[str] = Query(None, max_length=20000),
    ):
        queue: asyncio.Queue = asyncio.Queue()

        async def send(m: dict) -> None:
            await queue.put(m)

        try:
            parsed = ICTSettings.model_validate_json(settings) if settings else ICTSettings()
        except ValidationError as exc:
            parsed = None
            bad = str(exc)[:300]
        req = LiveSubscribe(action="subscribe", symbol=symbol, timeframe=timeframe, provider=provider, limit=limit,
                            settings=parsed or ICTSettings())

        async def gen():
            client = Client(send, "sse")
            writer = asyncio.create_task(client.writer())
            try:
                yield "retry: 3000\n\n"
                client.put({**HELLO, "server_time": time.time(), "transport": "sse"})
                if parsed is None:
                    client.put(_err(f"Invalid settings: {bad}"))
                asyncio.create_task(_subscribe(client, req))
                while True:
                    try:
                        msg = await asyncio.wait_for(queue.get(), timeout=15)
                        yield f"data: {json.dumps(msg)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keep-alive\n\n"
                    if await request.is_disconnected():
                        break
            finally:
                hub.unsubscribe(client)
                client.closed = True
                writer.cancel()

        return StreamingResponse(gen(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"})

    @router.get("/api/live/status")
    def live_status() -> dict:
        return {"feeds": hub.debug(), "server_time": time.time()}

    return router
