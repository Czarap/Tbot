from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from backend.ict_engine.settings import ICTSettings
from backend.market_data import TIMEFRAMES
from backend.market_data.base import AuthError, ProviderError, RateLimitError
from backend.market_data.timeframes import TIMEFRAME_LABELS
from backend.services.analysis_service import DISCLAIMER, AnalysisService

from .schemas import AnalysisRequest, TimeframeLit


def _default_backtest() -> dict:
    from backend.backtesting.config import BacktestConfig

    return BacktestConfig().model_dump()


def _default_grid() -> dict:
    from backend.optimization.optimizer import OptimizeGrid

    return OptimizeGrid().model_dump()


def build_router(service: AnalysisService) -> APIRouter:
    router = APIRouter(prefix="/api")

    def _guard(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except RateLimitError as exc:
            raise HTTPException(status_code=429, detail=f"Data provider rate limit: {exc}")
        except AuthError as exc:
            raise HTTPException(status_code=503, detail=f"Data provider not authorised: {exc}")
        except ProviderError as exc:
            raise HTTPException(status_code=502, detail=f"Data provider error: {exc}")
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc).strip("'\""))
        except (LookupError, FileNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
        except OSError as exc:  # network errors from remote providers
            raise HTTPException(status_code=502, detail=f"Data provider error: {exc}")

    @router.get("/health")
    def health() -> dict:
        return {"status": "ok"}

    @router.get("/meta")
    def meta() -> dict:
        data = service.data
        instruments = data.instruments()
        return {
            "default_provider": data.symbol_defaults.get("XAUUSD", data.default),
            "default_symbol": instruments[0]["symbol"] if instruments else "XAUUSD",
            "providers": [p.to_dict() for p in data.provider_infos()],
            "instruments": instruments,
            "symbols": [{k: v for k, v in i.items() if k not in ("providers", "default_provider")} for i in instruments],
            "live": True,
            "timeframes": [{"id": k, "label": TIMEFRAME_LABELS[k], "seconds": v} for k, v in TIMEFRAMES.items()],
            "default_settings": ICTSettings().model_dump(),
            "default_backtest": _default_backtest(),
            "default_grid": _default_grid(),
            "settings_schema": ICTSettings.model_json_schema(),
            "disclaimer": DISCLAIMER,
            "auto_trading": False,
        }

    @router.get("/candles")
    def candles(
        symbol: str = Query("XAUUSD", pattern=r"^[A-Z0-9]{3,12}$"),
        timeframe: TimeframeLit = Query("15m"),
        limit: int = Query(1000, ge=10, le=20000),
        provider: Optional[str] = Query(None, pattern=r"^[a-z_]{2,32}$"),
    ) -> dict:
        return _guard(service.candles, symbol, timeframe, limit, provider)

    @router.post("/analysis")
    def analysis(req: AnalysisRequest) -> dict:
        return _guard(service.analyze, req.symbol, req.timeframe, req.limit, req.provider, req.settings)

    @router.get("/analysis")
    def analysis_default(
        symbol: str = Query("XAUUSD", pattern=r"^[A-Z0-9]{3,12}$"),
        timeframe: TimeframeLit = Query("15m"),
        limit: int = Query(1000, ge=100, le=5000),
        provider: Optional[str] = Query(None, pattern=r"^[a-z_]{2,32}$"),
    ) -> dict:
        return _guard(service.analyze, symbol, timeframe, limit, provider, None)

    return router
