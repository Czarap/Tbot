"""Endpoints for Phases 2-5: MTF, backtests, optimizer, jobs, journal, profiles, replay, calendar, data import."""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from backend.backtesting.config import BacktestConfig
from backend.backtesting.runner import run_backtest
from backend.database.store import Store
from backend.ict_engine.settings import ICTSettings
from backend.market_data.calendar import CalendarService
from backend.market_data.cleaning import clean_candles
from backend.market_data.csv_provider import parse_candle_csv
from backend.market_data.timeframes import TIMEFRAMES
from backend.optimization.optimizer import OptimizeRequest, optimize
from backend.services.analysis_service import AnalysisService
from backend.services.jobs import JobManager
from backend.services.mtf import mtf_overview
from backend.services.replay import ReplayManager

TF = Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


class MTFRequest(BaseModel):
    symbol: str = Field("XAUUSD", pattern=r"^[A-Z0-9]{2,12}$")
    provider: Optional[str] = Field(None, pattern=r"^[a-z_]{2,32}$")
    settings: ICTSettings = Field(default_factory=ICTSettings)


class ReplayStart(BaseModel):
    symbol: str = Field("XAUUSD", pattern=r"^[A-Z0-9]{2,12}$")
    timeframe: TF = "15m"
    provider: Optional[str] = Field(None, pattern=r"^[a-z_]{2,32}$")
    start: str = Field(..., description="ISO date/time (UTC) or epoch seconds")
    limit: int = Field(600, ge=100, le=3000)
    settings: ICTSettings = Field(default_factory=ICTSettings)


class Step(BaseModel):
    n: int = Field(1, ge=1, le=5000)


class Seek(BaseModel):
    time: int


class NoteIn(BaseModel):
    notes: str = Field("", max_length=5000)


class ProfileIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    settings: ICTSettings
    backtest: Optional[dict] = None


def build_phase_router(analysis: AnalysisService, jobs: JobManager, store: Store, replay: ReplayManager,
                       calendar: Optional[CalendarService], data_dir: str) -> APIRouter:
    r = APIRouter(prefix="/api")

    def guard(fn, *a, **k):
        try:
            return fn(*a, **k)
        except KeyError as exc:
            raise HTTPException(404, str(exc).strip("'\""))
        except (LookupError, ValueError) as exc:
            raise HTTPException(422, str(exc))

    # ------------------------------------------------------------- calendar
    @r.get("/calendar")
    def get_calendar(start: Optional[int] = Query(None), end: Optional[int] = Query(None),
                     currencies: str = Query("USD", max_length=60), importance: Literal["low", "medium", "high"] = Query("high")) -> dict:
        if calendar is None:
            return {"events": [], "coverage": None, "sources": [], "error": "calendar disabled"}
        now = int(time.time())
        s, e = start or now - 7 * 86400, end or now + 7 * 86400
        if e - s > 400 * 86400:
            raise HTTPException(422, "Range too long (max 400 days)")
        cur = [c.strip().upper() for c in currencies.split(",") if c.strip()] or None
        return calendar.events(s, e, cur, importance)

    # ------------------------------------------------------------------ MTF
    @r.post("/mtf")
    def mtf(req: MTFRequest) -> dict:
        return guard(mtf_overview, analysis, req.symbol, req.provider, req.settings)

    # ------------------------------------------------------------ backtests
    @r.post("/backtest")
    def start_backtest(cfg: BacktestConfig) -> dict:
        guard(analysis.data.provider, cfg.provider, cfg.symbol)

        def done(job):
            job.result["run_id"] = job.id
            try:
                store.save_run(job.id, job.result)
            except Exception as exc:  # noqa: BLE001 - results stay available in memory
                job.result.setdefault("warnings", []).append(f"Could not save to the journal: {exc}")

        job = jobs.submit("backtest", lambda p: run_backtest(analysis, cfg, progress=p),
                          meta={"symbol": cfg.symbol, "timeframe": cfg.timeframe}, on_done=done)
        return job.public()

    @r.post("/optimize")
    def start_optimize(req: OptimizeRequest) -> dict:
        guard(analysis.data.provider, req.base.provider, req.base.symbol)
        sig, total = req.grid.size()
        job = jobs.submit("optimize", lambda p: optimize(analysis, req, progress=p),
                          meta={"symbol": req.base.symbol, "combinations": total, "signal_runs": sig})
        return job.public()

    @r.get("/jobs")
    def list_jobs() -> dict:
        return {"jobs": jobs.list()}

    @r.get("/jobs/{job_id}")
    def get_job(job_id: str, result: bool = Query(False)) -> dict:
        job = jobs.get(job_id)
        if job is None:
            raise HTTPException(404, "Job not found (results are kept in memory for the last 30 jobs)")
        return job.public(with_result=result and job.state == "done")

    @r.delete("/jobs/{job_id}")
    def cancel_job(job_id: str) -> dict:
        return {"cancelled": jobs.cancel(job_id)}

    # ------------------------------------------------------- runs & journal
    @r.get("/runs")
    def runs() -> dict:
        return {"runs": store.list_runs()}

    @r.get("/runs/{run_id}")
    def run(run_id: str) -> dict:
        res = store.get_run(run_id)
        if res is None:
            raise HTTPException(404, "Run not found")
        return res

    @r.delete("/runs/{run_id}")
    def del_run(run_id: str) -> dict:
        store.delete_run(run_id)
        return {"deleted": run_id}

    @r.patch("/journal/{run_id}/{trade_id}")
    def note(run_id: str, trade_id: str, body: NoteIn) -> dict:
        if not store.set_note(run_id, trade_id, body.notes):
            raise HTTPException(404, "Trade not found")
        job = jobs.get(run_id)
        if job and job.result:
            for t in job.result["trades"]:
                if t["id"] == trade_id:
                    t["notes"] = body.notes
        return {"run_id": run_id, "trade_id": trade_id, "notes": body.notes}

    # ------------------------------------------------------------- profiles
    @r.get("/profiles")
    def profiles() -> dict:
        return {"profiles": store.list_profiles()}

    @r.post("/profiles")
    def save_profile(p: ProfileIn) -> dict:
        return store.save_profile(p.name.strip(), p.settings.model_dump(), p.backtest)

    @r.delete("/profiles/{profile_id}")
    def delete_profile(profile_id: int) -> dict:
        store.delete_profile(profile_id)
        return {"deleted": profile_id}

    # --------------------------------------------------------------- replay
    @r.post("/replay/start")
    def replay_start(req: ReplayStart) -> dict:
        s = guard(replay.start, req.symbol, req.timeframe, req.provider, req.settings, req.start, req.limit)
        return s.state()

    @r.post("/replay/{sid}/step")
    def replay_step(sid: str, body: Step) -> dict:
        s = guard(replay.get, sid)
        s.step(body.n)
        return s.state()

    @r.post("/replay/{sid}/back")
    def replay_back(sid: str, body: Step) -> dict:
        s = guard(replay.get, sid)
        s.back(body.n)
        return s.state()

    @r.post("/replay/{sid}/seek")
    def replay_seek(sid: str, body: Seek) -> dict:
        s = guard(replay.get, sid)
        s.seek(body.time)
        return s.state()

    @r.delete("/replay/{sid}")
    def replay_stop(sid: str) -> dict:
        replay.stop(sid)
        return {"stopped": sid}

    # ---------------------------------------------------------- data import
    @r.post("/data/upload")
    async def upload(request: Request, symbol: str = Query(..., pattern=r"^[A-Z0-9]{2,12}$"),
                     timeframe: TF = Query("1m"), tz: str = Query("UTC", max_length=40)) -> dict:
        body = await request.body()
        if len(body) > 200 * 1024 * 1024:
            raise HTTPException(413, "File too large (max 200 MB)")
        try:
            text = body.decode("utf-8-sig")
            df = parse_candle_csv(text, tz)
            clean, rep = clean_candles(df, TIMEFRAMES[timeframe])
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(422, f"Could not parse the CSV: {exc}")
        if clean.empty:
            raise HTTPException(422, "No valid candles found in the file")
        path = Path(data_dir) / f"{symbol}_{timeframe}.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        clean.to_csv(path, index=False)
        analysis.data.invalidate_history("csv", symbol)
        return {"saved": path.name, "rows": len(clean), "first": int(clean["time"].iloc[0]), "last": int(clean["time"].iloc[-1]),
                "quality": rep.to_dict(), "hint": "Select the 'CSV files' provider to use this data."}

    @r.get("/data/files")
    def files() -> dict:
        out = []
        for p in sorted(Path(data_dir).glob("*.csv")):
            if re.match(r"^[A-Z0-9]+_(1m|5m|15m|30m|1h|4h|1d)\.csv$", p.name):
                out.append({"name": p.name, "bytes": p.stat().st_size, "modified": p.stat().st_mtime})
        return {"files": out, "directory": os.path.abspath(data_dir)}

    return r
