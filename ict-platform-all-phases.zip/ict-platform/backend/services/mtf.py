"""Multi-timeframe (MTF) panel (Phase 2).

    Bias      (default 4H)  -> overall direction
    Structure (default 1H)  -> market structure
    Setup     (default 15M) -> liquidity / setup timeframe
    Entry     (default 5M)  -> entry confirmation

Each row reports that timeframe's structure trend (from CLOSED candles) and
whether it agrees with the bias timeframe:
    aligned    same direction as the bias            (✅)
    conflict   opposite direction                    (⚠️)
    waiting    no trend yet / no recent setup         (⏳)
The entry row says SETUP when a possible setup in the bias direction appeared
within its last `recent_candles` candles.
"""
from __future__ import annotations

from typing import Optional

from backend.ict_engine import ICTSettings

ROLES = ("bias", "structure", "setup", "entry")


def mtf_overview(analysis, symbol: str, provider: Optional[str], settings: ICTSettings, recent_candles: int = 3) -> dict:
    roles = settings.mtf.model_dump()
    rows = []
    bias_dir = None
    for role in ROLES:
        tf = roles[role]
        try:
            res = analysis.analyze(symbol, tf, 500, provider, settings)
        except Exception as exc:  # noqa: BLE001
            rows.append({"role": role, "timeframe": tf, "trend": None, "status": "error", "detail": str(exc)})
            continue
        s = res["analysis"]["summary"]
        trend = s["trend"]
        if role == "bias":
            bias_dir = trend
        candles = res["candles"]
        recent_t = candles[-recent_candles][0] if len(candles) >= recent_candles else 0
        recent = [x for x in res["analysis"]["setups"] if x["time"] >= recent_t and (bias_dir is None or x["direction"] == bias_dir)]
        ev = s["last_structure_event"]
        if role == "bias":
            status = "aligned" if trend else "waiting"
        elif role == "entry":
            status = "setup" if recent else ("conflict" if trend and bias_dir and trend != bias_dir else "waiting")
        elif trend is None or bias_dir is None:
            status = "waiting"
        else:
            status = "aligned" if trend == bias_dir else "conflict"
        rows.append({
            "role": role, "timeframe": tf, "trend": trend, "status": status, "zone": s["zone"],
            "last_event": {"type": ev["type"], "direction": ev["direction"], "time": ev["time"]} if ev else None,
            "recent_setup": recent[-1]["label"] if recent else None, "price": s["price"],
        })
    aligned = [r for r in rows if r["status"] in ("aligned", "setup")]
    overall = "aligned" if bias_dir and len(aligned) == len(rows) else "mixed" if bias_dir else "waiting"
    return {"symbol": symbol, "bias": bias_dir, "overall": overall, "rows": rows, "roles": roles}
