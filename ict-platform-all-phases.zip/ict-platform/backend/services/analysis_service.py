"""Glue between market data and the ICT engine (used by the API and scripts)."""
from __future__ import annotations

import hashlib
import json
import time
from collections import OrderedDict
from typing import Any, Optional

import pandas as pd

from backend.ict_engine import EngineContext, HTFBias, ICTEngine, ICTSettings
from backend.market_data import DEFAULT_HTF, TIMEFRAMES, MarketDataService

DISCLAIMER = (
    "This platform is an educational and analytical tool. Backtested results do not guarantee future performance. "
    "Historical simulations may differ from real-world execution due to spreads, slippage, liquidity, commissions, and data quality."
)

WARMUP_CANDLES = 500
HTF_WARMUP_CANDLES = 300


class AnalysisService:
    def __init__(self, data: MarketDataService, cache_size: int = 32, calendar=None):
        self.data = data
        self.calendar = calendar
        self._cache: OrderedDict[str, dict] = OrderedDict()
        self._cache_size = cache_size

    def resolve_htf(self, timeframe: str, settings: ICTSettings) -> Optional[str]:
        htf = settings.setups.htf_timeframe or DEFAULT_HTF.get(timeframe)
        if htf and TIMEFRAMES[htf] <= TIMEFRAMES[timeframe]:
            return None  # an "HTF" must be higher than the chart timeframe
        return htf

    def news_index(self, start: int, end: int, currencies: Optional[list] = None, min_importance: str = "high"):
        if self.calendar is None:
            return None
        from backend.market_data.calendar import NewsIndex

        return NewsIndex.from_result(self.calendar.events(start, end, currencies or ["USD"], min_importance))

    def build_context(self, symbol: str, timeframe: str, settings: ICTSettings, first_time: int, provider: Optional[str]) -> EngineContext:
        ctx = self.data.get_context(symbol, provider)
        htf_tf = self.resolve_htf(timeframe, settings)
        htf = None
        if htf_tf:
            hdf = self.data.get_candles(symbol, htf_tf, provider).df
            start = first_time - HTF_WARMUP_CANDLES * TIMEFRAMES[htf_tf]
            hdf = hdf[hdf["time"] >= start]
            if len(hdf):
                htf = HTFBias.from_candles(hdf, htf_tf, TIMEFRAMES[htf_tf], settings.structure.swing_length, settings.structure.break_confirmation)
        out = EngineContext(EngineContext.frame_to_ref(ctx["1d"]), EngineContext.frame_to_ref(ctx["1w"]), htf)
        news = self.news_index(first_time - 86400, int(time.time()) + 3 * 86400)
        if news is not None:
            out.extra["news"] = news
        return out

    def analyze(self, symbol: str, timeframe: str, limit: int = 1000, provider: Optional[str] = None,
                settings: Optional[ICTSettings] = None) -> dict[str, Any]:
        settings = settings or ICTSettings()
        prov = self.data.provider(provider, symbol)
        version = self.data.data_version(prov.id, symbol)
        # minute bucket: the forming/closed split moves with the clock even without new data
        key = hashlib.sha1(json.dumps([prov.id, symbol, timeframe, limit, settings.model_dump(), version, int(time.time() // 60)],
                                      sort_keys=True).encode()).hexdigest()
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]

        t0 = time.perf_counter()
        cs = self.data.get_candles(symbol, timeframe, prov.id)
        df = cs.df
        if df.empty:
            raise LookupError(f"No candles available for {symbol} {timeframe}")
        work = df.tail(limit + WARMUP_CANDLES).reset_index(drop=True)
        shown = work.tail(limit).reset_index(drop=True)
        first_shown = int(shown["time"].iloc[0])

        ctx = self.build_context(symbol, timeframe, settings, int(work["time"].iloc[0]), prov.id)
        info = prov.symbol_info(symbol)
        engine = ICTEngine(settings, symbol, timeframe, TIMEFRAMES[timeframe], ctx, precision=info.price_precision)
        engine.run(work)
        analysis = engine.result(from_time=first_shown)

        candles = [[int(r[0]), r[1], r[2], r[3], r[4], r[5]] for r in shown[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None)]
        out = {
            "symbol": symbol,
            "timeframe": timeframe,
            "symbol_info": info.to_dict(),
            "provider": prov.info().to_dict(),
            "source_timeframe": cs.source_timeframe,
            "data_quality": cs.quality.to_dict(),
            "settings": settings.model_dump(),
            "candles": candles,
            "forming": cs.forming,
            "analysis": analysis,
            "warmup_candles": len(work) - len(shown),
            "compute_ms": round((time.perf_counter() - t0) * 1000, 1),
            "generated_at": int(time.time()),
            "disclaimer": DISCLAIMER,
        }
        self._cache[key] = out
        if len(self._cache) > self._cache_size:
            self._cache.popitem(last=False)
        return out

    def candles(self, symbol: str, timeframe: str, limit: int, provider: Optional[str] = None) -> dict[str, Any]:
        prov = self.data.provider(provider, symbol)
        cs = self.data.get_candles(symbol, timeframe, prov.id)
        df: pd.DataFrame = cs.df.tail(limit)
        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "provider": prov.info().to_dict(),
            "forming": cs.forming,
            "data_quality": cs.quality.to_dict(),
            "candles": [[int(r[0]), r[1], r[2], r[3], r[4], r[5]] for r in df[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None)],
        }
