"""Market replay (Phase 4).

A replay session holds the closed candles and a streaming ICT engine. The
engine has seen exactly the candles up to the replay cursor — nothing after it
exists for it — so detections are the ones you would have seen at that moment.
Stepping forward feeds one more candle; stepping back rebuilds the engine up to
the earlier cursor (the engine is append-only by design).
"""
from __future__ import annotations

import threading
import time
import uuid
from typing import Optional

import pandas as pd

from backend.ict_engine import ICTEngine, ICTSettings
from backend.market_data.timeframes import TIMEFRAMES

from .analysis_service import WARMUP_CANDLES, AnalysisService


class ReplaySession:
    def __init__(self, analysis: AnalysisService, symbol: str, timeframe: str, provider: Optional[str],
                 settings: ICTSettings, start_time: int, limit: int = 600):
        self.id = uuid.uuid4().hex[:12]
        self.symbol, self.timeframe, self.limit = symbol, timeframe, limit
        self.settings = settings
        prov = analysis.data.provider(provider, symbol)
        self.provider = prov
        self.info = prov.get_symbol_info(symbol)
        df = analysis.data.get_candles(symbol, timeframe, prov.id).df
        if len(df) < 50:
            raise LookupError("Not enough history for replay")
        self.df = df.reset_index(drop=True)
        self.rows = list(self.df[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None))
        start_idx = int((self.df["time"] >= start_time).to_numpy().argmax()) if (self.df["time"] >= start_time).any() else len(self.df) - 1
        start_idx = max(start_idx, 20)
        self.base = max(0, start_idx - WARMUP_CANDLES)
        self.ctx = analysis.build_context(symbol, timeframe, settings, int(self.df["time"].iloc[self.base]), prov.id)
        self.start_idx = start_idx
        self.pos = -1
        self.engine: Optional[ICTEngine] = None
        self.touched = time.time()
        self.lock = threading.Lock()
        self._rebuild(start_idx)

    def _rebuild(self, pos: int) -> None:
        self.engine = ICTEngine(self.settings, self.symbol, self.timeframe, TIMEFRAMES[self.timeframe], self.ctx,
                                precision=self.info.price_precision)
        for r in self.rows[self.base: pos + 1]:
            self.engine.update(*r)
        self.pos = pos

    def step(self, n: int = 1) -> None:
        with self.lock:
            self.touched = time.time()
            target = min(len(self.rows) - 1, self.pos + max(1, n))
            for r in self.rows[self.pos + 1: target + 1]:
                self.engine.update(*r)
            self.pos = target

    def back(self, n: int = 1) -> None:
        with self.lock:
            self.touched = time.time()
            self._rebuild(max(self.base + 20, self.pos - max(1, n)))

    def seek(self, t: int) -> None:
        idx = int((self.df["time"] >= t).to_numpy().argmax()) if (self.df["time"] >= t).any() else len(self.rows) - 1
        with self.lock:
            self.touched = time.time()
            if idx >= self.pos:
                for r in self.rows[self.pos + 1: idx + 1]:
                    self.engine.update(*r)
                self.pos = idx
            else:
                self._rebuild(max(self.base + 20, idx))

    def state(self) -> dict:
        with self.lock:
            lo = max(self.base, self.pos - self.limit + 1)
            shown = self.rows[lo: self.pos + 1]
            analysis = self.engine.result(from_time=int(shown[0][0]))
            new_setups = [s for s in analysis["setups"] if s["time"] == int(shown[-1][0])]
            return {
                "symbol": self.symbol, "timeframe": self.timeframe, "symbol_info": self.info.to_dict(),
                "provider": self.provider.info().to_dict(), "candles": [[int(r[0]), *r[1:]] for r in shown], "forming": None,
                "analysis": analysis, "settings": self.settings.model_dump(),
                "replay": {"id": self.id, "time": int(shown[-1][0]), "index": self.pos - self.base,
                           "remaining": len(self.rows) - 1 - self.pos, "at_end": self.pos >= len(self.rows) - 1,
                           "first_time": int(self.rows[self.base + 20][0]), "last_time": int(self.rows[-1][0]),
                           "new_setups": new_setups},
                "data_quality": {}, "source_timeframe": self.timeframe, "warmup_candles": 0, "compute_ms": 0,
                "generated_at": int(time.time()), "disclaimer": "", "symbol_market": self.info.market,
            }


class ReplayManager:
    def __init__(self, analysis: AnalysisService, ttl: float = 1800):
        self.analysis = analysis
        self.sessions: dict[str, ReplaySession] = {}
        self.ttl = ttl

    def start(self, symbol: str, timeframe: str, provider: Optional[str], settings: ICTSettings, start: str | int,
              limit: int = 600) -> ReplaySession:
        self._gc()
        t = int(start) if isinstance(start, (int, float)) or str(start).isdigit() else int(pd.Timestamp(start, tz="UTC").timestamp()) \
            if pd.Timestamp(start).tzinfo is None else int(pd.Timestamp(start).timestamp())
        s = ReplaySession(self.analysis, symbol, timeframe, provider, settings, t, limit)
        self.sessions[s.id] = s
        return s

    def get(self, sid: str) -> ReplaySession:
        s = self.sessions.get(sid)
        if s is None:
            raise KeyError(f"Replay session {sid} not found (expired?)")
        return s

    def stop(self, sid: str) -> None:
        self.sessions.pop(sid, None)

    def _gc(self) -> None:
        now = time.time()
        for k in [k for k, s in self.sessions.items() if now - s.touched > self.ttl]:
            del self.sessions[k]
