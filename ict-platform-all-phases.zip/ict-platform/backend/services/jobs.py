"""Background jobs (backtests, optimizations) with progress reporting."""
from __future__ import annotations

import threading
import time
import traceback
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class Job:
    id: str
    kind: str
    state: str = "queued"  # queued | running | done | error | cancelled
    progress: float = 0.0
    message: str = "Queued"
    created: float = field(default_factory=time.time)
    finished: Optional[float] = None
    result: Any = None
    error: Optional[str] = None
    meta: dict = field(default_factory=dict)

    def public(self, with_result: bool = False) -> dict:
        d = {k: getattr(self, k) for k in ("id", "kind", "state", "progress", "message", "created", "finished", "error", "meta")}
        if with_result:
            d["result"] = self.result
        return d


class JobManager:
    def __init__(self, workers: int = 2, keep: int = 30):
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ict-job")
        self._jobs: OrderedDict[str, Job] = OrderedDict()
        self._keep = keep
        self._lock = threading.Lock()

    def submit(self, kind: str, fn: Callable[[Callable[[float, str], None]], Any], meta: Optional[dict] = None,
               on_done: Optional[Callable[[Job], None]] = None) -> Job:
        job = Job(uuid.uuid4().hex[:12], kind, meta=meta or {})
        with self._lock:
            self._jobs[job.id] = job
            while len(self._jobs) > self._keep:
                self._jobs.popitem(last=False)

        def progress(p: float, msg: str) -> None:
            if job.state == "cancelled":
                raise InterruptedError("cancelled")
            job.progress, job.message = round(min(1.0, max(0.0, p)), 4), msg

        def run() -> None:
            job.state, job.message = "running", "Starting"
            try:
                job.result = fn(progress)
                # on_done (e.g. saving to the journal) runs BEFORE the job is reported as done, so
                # a client polling the job never sees a finished result without its run_id.
                if on_done:
                    on_done(job)
                job.state, job.progress, job.message = "done", 1.0, "Done"
            except InterruptedError:
                job.state, job.message = "cancelled", "Cancelled"
            except Exception as exc:  # noqa: BLE001
                job.state, job.error = "error", f"{exc.__class__.__name__}: {exc}"
                job.message = "Failed"
                job.meta["traceback"] = traceback.format_exc(limit=5)
            finally:
                job.finished = time.time()

        self._pool.submit(run)
        return job

    def get(self, job_id: str) -> Optional[Job]:
        return self._jobs.get(job_id)

    def cancel(self, job_id: str) -> bool:
        job = self._jobs.get(job_id)
        if job and job.state in ("queued", "running"):
            job.state = "cancelled"
            return True
        return False

    def list(self) -> list[dict]:
        return [j.public() for j in reversed(self._jobs.values())]
