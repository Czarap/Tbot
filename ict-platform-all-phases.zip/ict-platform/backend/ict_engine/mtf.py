"""Higher-timeframe (HTF) bias without look-ahead.

The HTF candles are analysed with the same swing/structure rules. For a
lower-timeframe candle that CLOSES at time T, the HTF bias is the structure
trend after the most recent HTF candle whose close time is <= T. A partially
formed HTF candle is therefore never used.
"""
from __future__ import annotations

import bisect
from types import SimpleNamespace
from typing import Optional

import pandas as pd

from .structure import StructureTracker, SwingDetector


class HTFBias:
    def __init__(self, timeframe: str, tf_seconds: int, open_times: list[int], trend_after: list[Optional[str]]):
        self.timeframe = timeframe
        self.tf_seconds = tf_seconds
        self.open_times = open_times
        self.close_times = [t + tf_seconds for t in open_times]
        self.trend_after = trend_after

    @classmethod
    def from_candles(cls, df: pd.DataFrame, timeframe: str, tf_seconds: int, swing_length: int, confirmation: str) -> "HTFBias":
        host = SimpleNamespace(t=[], o=[], h=[], l=[], c=[])
        sw = SwingDetector(host, swing_length)  # type: ignore[arg-type]
        st = StructureTracker(host, confirmation)  # type: ignore[arg-type]
        for n, row in enumerate(df[["time", "open", "high", "low", "close"]].itertuples(index=False)):
            host.t.append(int(row.time)); host.o.append(float(row.open)); host.h.append(float(row.high))
            host.l.append(float(row.low)); host.c.append(float(row.close))
            st.update(n, sw.update(n))
        return cls(timeframe, tf_seconds, host.t, st.trend_history)

    def at(self, t_close: int) -> tuple[Optional[str], Optional[int]]:
        """Bias known at time t_close (UTC seconds) and the HTF candle it came from."""
        i = bisect.bisect_right(self.close_times, t_close) - 1
        if i < 0:
            return None, None
        return self.trend_after[i], self.open_times[i]
