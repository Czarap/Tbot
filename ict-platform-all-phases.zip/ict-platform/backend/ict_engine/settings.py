"""Every tunable rule of the ICT engine, validated with pydantic.

These models double as the API schema for the settings page, so the frontend
can render / edit them and the backend rejects invalid values.
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator

RuleMode = Literal["required", "scored", "off"]
Timeframe = Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


class StructureSettings(BaseModel):
    swing_length: int = Field(3, ge=1, le=20, description="Candles on EACH side a swing high/low must exceed (fractal length). A swing is only confirmed after this many later candles have closed.")
    break_confirmation: Literal["close", "wick"] = Field("close", description="BOS/CHoCH requires a candle CLOSE beyond the swing (default) or just a wick.")


class LiquiditySettings(BaseModel):
    include_swing_levels: bool = True
    include_equal_levels: bool = True
    include_previous_day: bool = True
    include_previous_week: bool = True
    include_session_levels: bool = True
    equal_tolerance_atr: float = Field(0.10, ge=0, le=2, description="Two swing highs/lows are 'equal' if within this many ATRs.")
    equal_lookback_swings: int = Field(8, ge=1, le=50)
    level_max_age_bars: int = Field(500, ge=20, le=10000, description="Swing-based levels older than this stop being tracked.")


class FVGSettings(BaseModel):
    min_size: float = Field(0.0, ge=0, description="Minimum gap size in price units (e.g. 0.50 = 50 cents on gold).")
    min_size_atr: float = Field(0.25, ge=0, le=5, description="Minimum gap size as a multiple of ATR. The larger of the two minimums applies.")
    max_age_bars: int = Field(2000, ge=10, le=100000)


class DisplacementSettings(BaseModel):
    range_atr_mult: float = Field(1.5, ge=0.5, le=10, description="Single candle range must be >= this x ATR(previous candle).")
    body_ratio: float = Field(0.6, ge=0.1, le=1.0, description="Candle body must be >= this fraction of its range.")
    multi_candle_enabled: bool = True
    multi_candle_count: int = Field(3, ge=2, le=10)
    multi_candle_atr_mult: float = Field(2.5, ge=0.5, le=20, description="Combined body of N same-direction candles >= this x ATR.")
    require_structure_break: bool = False


class OrderBlockSettings(BaseModel):
    enabled: bool = True
    zone: Literal["wick", "body"] = Field("wick", description="Use the OB candle's full range or only its body.")
    lookback_bars: int = Field(20, ge=2, le=200, description="How far back from the structure break to look for the OB candle.")
    max_age_bars: int = Field(1000, ge=10, le=100000)


class DealingRangeSettings(BaseModel):
    source: Literal["swings", "previous_day"] = "swings"


class SessionDef(BaseModel):
    name: str
    start: str = Field(..., pattern=r"^\d{2}:\d{2}$")
    end: str = Field(..., pattern=r"^\d{2}:\d{2}$")
    enabled: bool = True
    color: str = "#64748b"

    def minutes(self) -> tuple[int, int]:
        sh, sm = map(int, self.start.split(":"))
        eh, em = map(int, self.end.split(":"))
        s, e = sh * 60 + sm, eh * 60 + em
        return s, (e if e > s else e + 1440)


class SessionSettings(BaseModel):
    timezone: str = "America/New_York"
    sessions: list[SessionDef] = Field(
        default_factory=lambda: [
            SessionDef(name="Asia", start="20:00", end="00:00", color="#a78bfa"),
            SessionDef(name="London", start="02:00", end="05:00", color="#38bdf8"),
            SessionDef(name="New York", start="07:00", end="10:00", color="#f59e0b"),
        ]
    )


class SetupRules(BaseModel):
    """'required' = setup is rejected if the rule fails; 'scored' = adds +1
    to confluence when it passes; 'off' = ignored entirely."""

    htf_bias: RuleMode = "scored"
    liquidity_sweep: RuleMode = "required"
    order_block: RuleMode = "scored"
    structure_shift: RuleMode = "scored"
    displacement: RuleMode = "scored"
    premium_discount: RuleMode = "scored"
    session: RuleMode = "scored"
    liquidity_target: RuleMode = "scored"
    news: RuleMode = "scored"


class SetupSettings(BaseModel):
    enabled: bool = True
    rules: SetupRules = Field(default_factory=SetupRules)
    min_score: int = Field(5, ge=0, le=10)
    min_rr: float = Field(2.0, ge=0.5, le=20)
    sweep_lookback_bars: int = Field(20, ge=1, le=200, description="A sweep counts if it happened at most this many candles before the FVG formed.")
    max_retrace_bars: int = Field(20, ge=1, le=500, description="FVG must be revisited within this many candles after forming.")
    confirmation: Literal["hold", "rejection"] = Field("rejection", description="hold = candle touching the FVG closes beyond its far edge; rejection = same, AND the candle closes in the trade direction.")
    sl_buffer_atr: float = Field(0.10, ge=0, le=5)
    min_risk_atr: float = Field(0.20, ge=0, le=5, description="Skip setups whose stop distance is smaller than this x ATR (unrealistically tight).")
    one_setup_per_sweep: bool = True
    setup_sessions: list[str] = Field(default_factory=lambda: ["London", "New York"])
    htf_timeframe: Optional[Timeframe] = Field(None, description="Timeframe used for HTF bias. None = automatic (e.g. 15m -> 4h).")
    news_minutes_before: int = Field(15, ge=0, le=1440, description="No setups this many minutes before a high-impact USD release")
    news_minutes_after: int = Field(15, ge=0, le=1440)


class MTFSettings(BaseModel):
    """Which timeframe plays which role in the multi-timeframe panel."""

    bias: Timeframe = "4h"
    structure: Timeframe = "1h"
    setup: Timeframe = "15m"
    entry: Timeframe = "5m"


class ICTSettings(BaseModel):
    atr_period: int = Field(14, ge=2, le=200)
    structure: StructureSettings = Field(default_factory=StructureSettings)
    liquidity: LiquiditySettings = Field(default_factory=LiquiditySettings)
    fvg: FVGSettings = Field(default_factory=FVGSettings)
    displacement: DisplacementSettings = Field(default_factory=DisplacementSettings)
    order_blocks: OrderBlockSettings = Field(default_factory=OrderBlockSettings)
    dealing_range: DealingRangeSettings = Field(default_factory=DealingRangeSettings)
    sessions: SessionSettings = Field(default_factory=SessionSettings)
    setups: SetupSettings = Field(default_factory=SetupSettings)
    mtf: MTFSettings = Field(default_factory=MTFSettings)

    @field_validator("sessions")
    @classmethod
    def _tz_valid(cls, v: SessionSettings) -> SessionSettings:
        from zoneinfo import ZoneInfo

        ZoneInfo(v.timezone)  # raises if unknown
        return v
