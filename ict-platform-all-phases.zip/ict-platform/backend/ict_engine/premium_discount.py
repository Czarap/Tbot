"""Premium / discount relative to a dealing range.

source = "swings"        : range between the most recent CONFIRMED swing high
                           and swing low (the current trading leg).
source = "previous_day"  : previous trading day's high and low.
Equilibrium = 50% of the range. Above = premium (favour shorts), below =
discount (favour longs). Recomputed every candle from information available
at that candle only.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .types import DealingRange

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine


class PremiumDiscount:
    def __init__(self, eng: "ICTEngine", source: str):
        self.eng = eng
        self.source = source
        self.current: Optional[DealingRange] = None

    def update(self, n: int) -> Optional[DealingRange]:
        e = self.eng
        if self.source == "previous_day":
            pdh = next((lv for lv in reversed(e.liquidity.levels) if lv.kind == "pdh"), None)
            pdl = next((lv for lv in reversed(e.liquidity.levels) if lv.kind == "pdl"), None)
            if pdh and pdl and pdh.price > pdl.price:
                self.current = DealingRange(pdh.price, pdl.price, (pdh.price + pdl.price) / 2, pdh.start_time, pdl.start_time, "previous_day", e.t[n])
            return self.current
        sh, sl = e.swings.last_high, e.swings.last_low
        if sh and sl and sh.price > sl.price:
            cur = self.current
            if cur is None or cur.high != sh.price or cur.low != sl.price or cur.high_time != sh.time or cur.low_time != sl.time:
                self.current = DealingRange(sh.price, sl.price, round((sh.price + sl.price) / 2, 5), sh.time, sl.time, "swings", e.t[n])
        return self.current
