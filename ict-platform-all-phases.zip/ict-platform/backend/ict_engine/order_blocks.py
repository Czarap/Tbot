"""Order blocks.

RULES
-----
Created when a BOS/CHoCH happens on candle N (so it is known at N's close):
    Bullish OB : the LAST down-close candle (close < open) before the up-move
                 that broke structure, searched backwards from N-1 for at most
                 `lookback_bars` candles, and not earlier than the swing that
                 started the move (the lowest low between the broken swing and N).
    Bearish OB : mirror image (last up-close candle before the down-move).
Zone: the candle's full range (zone="wick") or its body (zone="body").

Status (updated by later candles M > N):
    MITIGATED   price traded back into the zone
    INVALIDATED a candle CLOSED beyond the far side (below a bullish OB's
                bottom / above a bearish OB's top) - the block failed
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import TYPE_CHECKING, Optional

from .types import StructureEvent

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine
    from .settings import OrderBlockSettings


@dataclass
class OrderBlock:
    id: str
    direction: str
    index: int  # the OB candle
    time: int
    created_index: int  # the structure-break candle
    created_time: int
    top: float
    bottom: float
    structure_event_id: str
    explanation: list
    status: str = "UNMITIGATED"
    mitigated_index: Optional[int] = None
    mitigated_time: Optional[int] = None
    invalidated_index: Optional[int] = None
    invalidated_time: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)


class OrderBlockDetector:
    def __init__(self, eng: "ICTEngine", cfg: "OrderBlockSettings"):
        self.eng = eng
        self.cfg = cfg
        self.blocks: list[OrderBlock] = []
        self.active: list[OrderBlock] = []
        self._used: set[int] = set()

    def update(self, n: int, events: list[StructureEvent]) -> list[OrderBlock]:
        e, cfg = self.eng, self.cfg
        if not cfg.enabled:
            return []
        # 1) status of existing blocks using candle n
        keep = []
        for ob in self.active:
            if n - ob.created_index > cfg.max_age_bars:
                continue
            bull = ob.direction == "bullish"
            if (bull and e.c[n] < ob.bottom) or (not bull and e.c[n] > ob.top):
                ob.status, ob.invalidated_index, ob.invalidated_time = "INVALIDATED", n, e.t[n]
                continue
            touched = e.l[n] <= ob.top if bull else e.h[n] >= ob.bottom
            if touched and ob.mitigated_index is None:
                ob.status, ob.mitigated_index, ob.mitigated_time = "MITIGATED", n, e.t[n]
            keep.append(ob)
        self.active = keep

        # 2) new blocks from structure breaks on candle n
        new: list[OrderBlock] = []
        for ev in events:
            bull = ev.direction == "bullish"
            lo = max(0, n - cfg.lookback_bars, ev.swing_index)
            # the extreme that started the move (lowest low for bullish)
            rng = range(lo, n)
            if not rng:
                continue
            start = min(rng, key=lambda j: e.l[j]) if bull else max(rng, key=lambda j: e.h[j])
            ob_idx = None
            for j in range(n - 1, max(start, lo) - 1, -1):
                if (bull and e.c[j] < e.o[j]) or (not bull and e.c[j] > e.o[j]):
                    ob_idx = j
                    break
            if ob_idx is None or ob_idx in self._used:
                continue
            self._used.add(ob_idx)
            if cfg.zone == "body":
                top, bottom = max(e.o[ob_idx], e.c[ob_idx]), min(e.o[ob_idx], e.c[ob_idx])
            else:
                top, bottom = e.h[ob_idx], e.l[ob_idx]
            word = "down-close" if bull else "up-close"
            ob = OrderBlock(
                id=f"ob-{ev.direction[:4]}-{e.t[ob_idx]}", direction=ev.direction, index=ob_idx, time=e.t[ob_idx],
                created_index=n, created_time=e.t[n], top=round(top, 5), bottom=round(bottom, 5),
                structure_event_id=ev.id,
                explanation=[
                    f"{'Bullish' if bull else 'Bearish'} order block",
                    f"Last {word} candle before the move that caused the {ev.type} at {ev.break_price:,.2f}",
                    f"Zone ({cfg.zone}): {bottom:,.2f} – {top:,.2f}",
                    f"Invalidated if a candle closes {'below' if bull else 'above'} {bottom if bull else top:,.2f}",
                ],
            )
            new.append(ob)
        self.blocks.extend(new)
        self.active.extend(new)
        return new
