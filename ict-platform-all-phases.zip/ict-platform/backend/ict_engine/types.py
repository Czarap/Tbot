"""Data records produced by the ICT engine.

Two kinds of fields exist and the distinction matters for anti-repainting:

* **Decision fields** (creation index/time, price levels, direction, the
  setup itself) are written ONCE, at the candle where the information became
  available, and never modified afterwards.
* **Status fields** (FVG mitigation, liquidity level swept/broken) describe
  what happened LATER. They change as new candles arrive, which is honest
  history-keeping, not repainting: they never alter the original decision.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional

Direction = str  # "bullish" | "bearish"


def _d(obj) -> dict:
    return asdict(obj)


@dataclass
class Swing:
    id: str
    kind: str  # "high" | "low"
    index: int
    time: int
    price: float
    confirmed_index: int
    confirmed_time: int
    label: str  # HH / LH / HL / LL / H / L (first swing has no reference)
    to_dict = _d


@dataclass
class StructureEvent:
    id: str
    type: str  # "BOS" | "CHoCH"
    direction: Direction
    index: int
    time: int
    break_price: float  # close (or wick extreme) that broke the level
    level: float  # swing price that was broken
    swing_id: str
    swing_time: int
    swing_index: int
    trend_before: Optional[str]
    trend_after: str
    explanation: list[str]
    to_dict = _d


@dataclass
class LiquidityLevel:
    id: str
    kind: str  # swing_high, swing_low, equal_highs, equal_lows, pdh, pdl, pwh, pwl, session_high, session_low
    side: str  # "buy" (resting above price) | "sell" (resting below price)
    label: str
    price: float
    start_time: int  # where to start drawing
    created_index: int  # candle at which the level became known
    created_time: int
    active_from_index: int  # first candle allowed to sweep it
    # --- status (evolves) ---
    status: str = "active"  # active | swept | broken | expired | merged
    end_index: Optional[int] = None
    end_time: Optional[int] = None
    sweep_id: Optional[str] = None
    meta: dict = field(default_factory=dict)
    to_dict = _d


@dataclass
class SweepEvent:
    id: str
    side: str  # "buy" = buy-side liquidity swept (bearish implication), "sell" = sell-side swept
    implication: Direction
    level_id: str
    level_kind: str
    level_label: str
    level_price: float
    index: int
    time: int
    extreme: float  # wick high/low of the sweeping candle
    close: float
    explanation: list[str]
    to_dict = _d


@dataclass
class FVG:
    id: str
    direction: Direction
    index: int  # middle candle (the displacement candle)
    time: int  # middle candle time (draw start)
    first_index: int  # candle 1 of the 3-candle pattern
    created_index: int  # candle 3 - the gap is confirmed at its close
    created_time: int
    top: float
    bottom: float
    size: float
    size_atr: float
    ce: float  # consequent encroachment (50%)
    # --- status (evolves) ---
    status: str = "UNMITIGATED"  # UNMITIGATED | MITIGATED | FILLED | EXPIRED
    mitigated_index: Optional[int] = None
    mitigated_time: Optional[int] = None
    filled_index: Optional[int] = None
    filled_time: Optional[int] = None
    max_fill_pct: float = 0.0
    to_dict = _d


@dataclass
class Displacement:
    id: str
    direction: Direction
    index: int  # last candle of the move (when it was confirmed)
    time: int
    start_index: int
    start_time: int
    kind: str  # "single" | "multi"
    range: float
    body: float
    atr: float
    range_atr: float
    broke_structure: bool
    explanation: list[str]
    to_dict = _d


@dataclass
class DealingRange:
    high: float
    low: float
    equilibrium: float
    high_time: int
    low_time: int
    source: str
    as_of_time: int
    to_dict = _d

    def zone(self, price: float) -> str:
        if price > self.equilibrium:
            return "premium"
        if price < self.equilibrium:
            return "discount"
        return "equilibrium"


@dataclass
class SessionWindow:
    id: str
    name: str
    color: str
    start_time: int
    end_time: Optional[int]  # time of first candle AFTER the session (None while running)
    high: float
    low: float
    high_time: int
    low_time: int
    complete: bool
    to_dict = _d


@dataclass
class SetupFactor:
    key: str
    label: str
    mode: str  # required | scored | off | pending
    passed: Optional[bool]
    points: int
    detail: str
    to_dict = _d


@dataclass
class Setup:
    id: str
    direction: Direction
    label: str  # "POSSIBLE LONG SETUP" / "POSSIBLE SHORT SETUP"
    symbol: str
    timeframe: str
    index: int
    time: int
    entry: float
    stop_loss: float
    take_profit: float
    risk: float
    reward: float
    rr: float
    score: int
    max_score: int
    factors: list[SetupFactor]
    fvg_id: str
    sweep_id: Optional[str]
    target_level_id: Optional[str]
    target_description: str
    htf_timeframe: Optional[str]
    htf_bias: Optional[str]
    session: Optional[str]
    reasoning: list[str]
    to_dict = _d
