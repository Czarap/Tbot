"""Trading sessions (Asia / London / New York kill zones by default).

Session times are wall-clock times in ``settings.sessions.timezone`` (New York
by default) so they follow daylight-saving changes automatically. A candle
belongs to a session if its OPEN time falls inside [start, end).

Session high/low become liquidity levels only once the session has ENDED
(i.e. at the first candle after it), because before that the final high/low is
not known.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING, Optional
from zoneinfo import ZoneInfo

from .types import SessionWindow

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine
    from .settings import SessionSettings


class LocalClock:
    """Fast UTC -> local wall clock conversion (offset cached per UTC hour)."""

    def __init__(self, tz: str):
        self.tz = ZoneInfo(tz)
        self._cache: dict[int, int] = {}

    def offset(self, t: int) -> int:
        key = t // 3600
        off = self._cache.get(key)
        if off is None:
            off = int(datetime.fromtimestamp(key * 3600, timezone.utc).astimezone(self.tz).utcoffset().total_seconds())
            self._cache[key] = off
        return off

    def minute_of_day(self, t: int) -> int:
        return ((t + self.offset(t)) % 86400) // 60

    def local_day(self, t: int) -> int:
        return (t + self.offset(t)) // 86400


class SessionTracker:
    def __init__(self, eng: "ICTEngine", cfg: "SessionSettings", enabled: bool):
        self.eng = eng
        self.enabled = enabled
        self.clock = LocalClock(cfg.timezone)
        self.defs = [s for s in cfg.sessions if s.enabled]
        self.windows: list[SessionWindow] = []
        self._open: dict[str, SessionWindow] = {}
        self._open_day: dict[str, int] = {}

    def session_at(self, t: int) -> Optional[str]:
        """Name of the (enabled) session containing time t, if any."""
        m = self.clock.minute_of_day(t)
        for s in self.defs:
            a, b = s.minutes()
            if a <= m < b or a <= m + 1440 < b:
                return s.name
        return None

    def update(self, n: int) -> list[SessionWindow]:
        """Returns sessions that COMPLETED at candle n (known from candle n on)."""
        if not self.enabled:
            return []
        e = self.eng
        t = e.t[n]
        m = self.clock.minute_of_day(t)
        day = self.clock.local_day(t)
        closed: list[SessionWindow] = []
        for s in self.defs:
            a, b = s.minutes()
            inside = a <= m < b or a <= m + 1440 < b
            # session "day" = local day of its start (handles sessions crossing midnight)
            sday = day if a <= m else day - 1
            w = self._open.get(s.name)
            if w is not None and (not inside or self._open_day[s.name] != sday):
                w.complete = True
                w.end_time = t
                closed.append(w)
                del self._open[s.name]
                w = None
            if inside:
                if w is None:
                    w = SessionWindow(f"sess-{s.name.lower().replace(' ', '')}-{t}", s.name, s.color, t, None,
                                      e.h[n], e.l[n], t, t, False)
                    self._open[s.name] = w
                    self._open_day[s.name] = sday
                    self.windows.append(w)
                else:
                    if e.h[n] > w.high:
                        w.high, w.high_time = e.h[n], t
                    if e.l[n] < w.low:
                        w.low, w.low_time = e.l[n], t
        return closed
