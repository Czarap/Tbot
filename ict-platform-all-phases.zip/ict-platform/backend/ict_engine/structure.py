"""Swing points and market structure (HH/HL/LH/LL, BOS, CHoCH).

RULES
-----
Swing high at candle c (swing_length = k):
    high[c] >  every high of the k candles BEFORE c   (strict, so the first of
                                                       two equal highs wins)
    high[c] >= every high of the k candles AFTER c
The swing is CONFIRMED only at candle c + k, because that is the first moment
the right-hand side is known. Nothing downstream may use the swing earlier.
(Swing low is the mirror image.)

Labels: a confirmed swing high is HH if above the previous swing high, else LH.
A swing low is HL if above the previous swing low, else LL.

Break of structure, evaluated on every candle N:
    bullish break  : close[N] > most recent unbroken swing high
                     (or high[N] > it when break_confirmation == "wick")
    bearish break  : close[N] < most recent unbroken swing low
    type           : CHoCH if the break is AGAINST the current trend
                     (bullish break while trend is bearish, or vice versa),
                     otherwise BOS. The very first break sets the trend and is
                     labelled BOS.
A broken swing cannot be broken again.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .types import StructureEvent, Swing

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine


def _fmt(p: float) -> str:
    return f"{p:,.2f}"


class SwingDetector:
    def __init__(self, eng: "ICTEngine", length: int):
        self.eng = eng
        self.k = length
        self.swings: list[Swing] = []
        self.last_high: Optional[Swing] = None
        self.last_low: Optional[Swing] = None

    def update(self, n: int) -> list[Swing]:
        k = self.k
        c = n - k
        if c - k < 0:
            return []
        e = self.eng
        H, L, T = e.h, e.l, e.t
        new: list[Swing] = []
        hc = H[c]
        if all(hc > H[j] for j in range(c - k, c)) and all(hc >= H[j] for j in range(c + 1, n + 1)):
            prev = self.last_high
            label = "H" if prev is None else ("HH" if hc > prev.price else "LH")
            s = Swing(f"sh-{T[c]}", "high", c, T[c], hc, n, T[n], label)
            self.last_high = s
            new.append(s)
        lc = L[c]
        if all(lc < L[j] for j in range(c - k, c)) and all(lc <= L[j] for j in range(c + 1, n + 1)):
            prev = self.last_low
            label = "L" if prev is None else ("HL" if lc > prev.price else "LL")
            s = Swing(f"sl-{T[c]}", "low", c, T[c], lc, n, T[n], label)
            self.last_low = s
            new.append(s)
        self.swings.extend(new)
        return new


class StructureTracker:
    def __init__(self, eng: "ICTEngine", confirmation: str = "close"):
        self.eng = eng
        self.confirmation = confirmation
        self.trend: Optional[str] = None
        self.events: list[StructureEvent] = []
        self.pending_high: Optional[Swing] = None  # most recent unbroken swing high
        self.pending_low: Optional[Swing] = None
        self.trend_history: list[Optional[str]] = []  # trend after each candle

    def update(self, n: int, new_swings: list[Swing]) -> list[StructureEvent]:
        for s in new_swings:
            if s.kind == "high":
                self.pending_high = s
            else:
                self.pending_low = s
        e = self.eng
        out: list[StructureEvent] = []
        close = e.c[n]
        up_px = e.h[n] if self.confirmation == "wick" else close
        dn_px = e.l[n] if self.confirmation == "wick" else close

        sh = self.pending_high
        if sh is not None and sh.confirmed_index <= n and up_px > sh.price:
            out.append(self._event(n, "bullish", sh, up_px))
            self.pending_high = None
        sl = self.pending_low
        if sl is not None and sl.confirmed_index <= n and dn_px < sl.price:
            out.append(self._event(n, "bearish", sl, dn_px))
            self.pending_low = None
        self.events.extend(out)
        self.trend_history.append(self.trend)
        return out

    def _event(self, n: int, direction: str, swing: Swing, px: float) -> StructureEvent:
        e = self.eng
        before = self.trend
        is_choch = before is not None and before != direction
        etype = "CHoCH" if is_choch else "BOS"
        self.trend = direction
        word = "above" if direction == "bullish" else "below"
        how = "Candle closed" if self.confirmation == "close" else "Wick traded"
        lines = [
            f"{etype} detected ({direction})",
            f"Previous swing {'high' if direction == 'bullish' else 'low'} ({swing.label}): {_fmt(swing.price)}",
            f"{'Close' if self.confirmation == 'close' else 'Wick'}: {_fmt(px)}",
            f"Confirmation: {how} {word} the previous swing {'high' if direction == 'bullish' else 'low'}.",
        ]
        if is_choch:
            lines.append(f"Trend changed from {before} to {direction} -> Change of Character.")
        elif before is None:
            lines.append("First structure break in the analysed window; sets the initial trend.")
        else:
            lines.append(f"Break in the direction of the existing {before} trend -> Break of Structure.")
        return StructureEvent(
            id=f"{etype.lower()}-{direction[:4]}-{e.t[n]}",
            type=etype,
            direction=direction,
            index=n,
            time=e.t[n],
            break_price=px,
            level=swing.price,
            swing_id=swing.id,
            swing_time=swing.time,
            swing_index=swing.index,
            trend_before=before,
            trend_after=direction,
            explanation=lines,
        )
