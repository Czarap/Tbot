"""Fair Value Gap detection.

RULES (3-candle pattern, candles A=N-2, B=N-1, C=N):
    Bullish FVG : low[C]  > high[A]   -> zone = [high[A], low[C]]
    Bearish FVG : high[C] < low[A]    -> zone = [high[C], low[A]]
    size        : top - bottom, must be >= max(min_size, min_size_atr * ATR)
The gap is only known when candle C has CLOSED, so it is created at index N.

Status (updated by every later candle M > N):
    MITIGATED : price traded back into the gap
                (bullish: low[M] <= top, bearish: high[M] >= bottom)
    FILLED    : price traded through the whole gap
                (bullish: low[M] <= bottom, bearish: high[M] >= top)
    EXPIRED   : no longer tracked after max_age_bars (status frozen)
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from .types import FVG

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine


class FVGDetector:
    def __init__(self, eng: "ICTEngine", min_size: float, min_size_atr: float, max_age_bars: int):
        self.eng = eng
        self.min_size = min_size
        self.min_size_atr = min_size_atr
        self.max_age = max_age_bars
        self.fvgs: list[FVG] = []
        self.active: list[FVG] = []

    def update(self, n: int) -> list[FVG]:
        e = self.eng
        # 1) status of existing gaps, using candle n only
        hi, lo, t = e.h[n], e.l[n], e.t[n]
        still: list[FVG] = []
        for g in self.active:
            if n - g.created_index > self.max_age:
                g.status = "EXPIRED"
                continue
            size = g.size or 1e-12
            if g.direction == "bullish":
                pen = (g.top - lo) / size
                touched, filled = lo <= g.top, lo <= g.bottom
            else:
                pen = (hi - g.bottom) / size
                touched, filled = hi >= g.bottom, hi >= g.top
            if touched:
                g.max_fill_pct = max(g.max_fill_pct, min(1.0, pen))
                if g.mitigated_index is None:
                    g.mitigated_index, g.mitigated_time = n, t
                    g.status = "MITIGATED"
            if filled:
                g.filled_index, g.filled_time = n, t
                g.status = "FILLED"
                g.max_fill_pct = 1.0
                continue
            still.append(g)
        self.active = still

        # 2) new gap confirmed by candle n
        if n < 2:
            return []
        a = n - 2
        atr = e.atr[n]
        min_sz = max(self.min_size, self.min_size_atr * atr)
        new: list[FVG] = []
        if e.l[n] > e.h[a]:
            top, bot = e.l[n], e.h[a]
            if top - bot >= min_sz and top - bot > 0:
                new.append(self._make("bullish", n, top, bot, atr))
        elif e.h[n] < e.l[a]:
            top, bot = e.l[a], e.h[n]
            if top - bot >= min_sz and top - bot > 0:
                new.append(self._make("bearish", n, top, bot, atr))
        self.fvgs.extend(new)
        self.active.extend(new)
        return new

    def _make(self, direction: str, n: int, top: float, bot: float, atr: float) -> FVG:
        e = self.eng
        size = top - bot
        return FVG(
            id=f"fvg-{direction[:4]}-{e.t[n - 1]}",
            direction=direction,
            index=n - 1,
            time=e.t[n - 1],
            first_index=n - 2,
            created_index=n,
            created_time=e.t[n],
            top=round(top, 5),
            bottom=round(bot, 5),
            size=round(size, 5),
            size_atr=round(size / atr, 3) if atr > 0 else 0.0,
            ce=round((top + bot) / 2, 5),
        )
