"""ICT setup engine: liquidity sweep -> displacement -> FVG -> retrace -> confirmation.

MODEL (bullish; bearish is the mirror image)
---------------------------------------------
Anchor: every bullish FVG is a *candidate*. Once it has formed, we wait up to
`max_retrace_bars` candles for price to come back into it.

On candle M (strictly after the FVG was confirmed):
  1. Retrace      : low[M] <= FVG top            (price is back in the gap)
  2. Invalidation : close[M] <= FVG bottom       -> candidate dropped (gap failed)
  3. Confirmation : "hold"      -> close stays above the FVG bottom
                    "rejection" -> AND close[M] > open[M] (bullish candle)
  If confirmed, the setup is evaluated ONCE at the close of M using only data
  up to and including M:

  Hypothetical entry : close[M]   (a decision can only be made after the close)
  Stop loss          : lowest low from the anchor (sweep candle, or the FVG's
                       first candle) through M, minus sl_buffer_atr * ATR
  Take profit        : nearest ACTIVE buy-side liquidity level above entry that
                       gives at least min_rr; otherwise entry + min_rr * risk

Confluence factors (each 'required', 'scored' (+1) or 'off'):
  htf_bias          HTF structure trend is bullish
  liquidity_sweep   sell-side liquidity swept within sweep_lookback_bars
                    before the FVG formed
  structure_shift   bullish BOS/CHoCH between the anchor and M
  displacement      bullish displacement between the anchor and the FVG
  fvg               the FVG itself (always required, +1)
  premium_discount  entry is in DISCOUNT of the current dealing range
  session           M is inside one of the selected sessions
  liquidity_target  a real buy-side liquidity target exists at >= min_rr
  news              no high-impact release inside the configured window
                    (shown as 'pending' and not scored when no calendar data covers the time)

A setup is emitted only if every required factor passed, score >= min_score
and R:R >= min_rr. Once emitted it is never modified (anti-repainting).
These are POSSIBLE setups for analysis, never trade instructions.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import pandas as pd

from .types import FVG, Setup, SetupFactor

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine
    from .mtf import HTFBias
    from .settings import SetupSettings

FACTOR_LABELS = {
    "htf_bias": "HTF Bias",
    "liquidity_sweep": "Liquidity Sweep",
    "structure_shift": "BOS / CHoCH",
    "displacement": "Displacement",
    "fvg": "Fair Value Gap",
    "order_block": "Order Block",
    "premium_discount": "Premium / Discount",
    "session": "Session Alignment",
    "liquidity_target": "Liquidity Target",
    "news": "News Filter",
}


def _p(x: float) -> str:
    return f"{x:,.2f}"


class SetupEngine:
    def __init__(self, eng: "ICTEngine", cfg: "SetupSettings", htf: Optional["HTFBias"]):
        self.eng = eng
        self.cfg = cfg
        self.htf = htf
        self.watch: list[FVG] = []
        self.setups: list[Setup] = []
        self.used_sweeps: set[str] = set()
        self.rejections: dict[str, int] = {}

    def _reject(self, reason: str) -> None:
        self.rejections[reason] = self.rejections.get(reason, 0) + 1

    def update(self, n: int, new_fvgs: list[FVG]) -> list[Setup]:
        if not self.cfg.enabled:
            return []
        e, cfg = self.eng, self.cfg
        out: list[Setup] = []
        keep: list[FVG] = []
        for g in self.watch:
            if n - g.created_index > cfg.max_retrace_bars:
                self._reject("FVG not revisited in time")
                continue
            long = g.direction == "bullish"
            touched = e.l[n] <= g.top if long else e.h[n] >= g.bottom
            if not touched:
                keep.append(g)
                continue
            if (long and e.c[n] <= g.bottom) or (not long and e.c[n] >= g.top):
                self._reject("Price closed through the FVG")
                continue
            if cfg.confirmation == "rejection" and not ((e.c[n] > e.o[n]) if long else (e.c[n] < e.o[n])):
                keep.append(g)  # touched but no rejection candle yet - keep waiting
                continue
            s = self._evaluate(n, g)
            if s is not None:
                out.append(s)
        self.watch = keep + list(new_fvgs)
        self.setups.extend(out)
        return out

    # ------------------------------------------------------------------
    def _evaluate(self, n: int, g: FVG) -> Optional[Setup]:
        e, cfg = self.eng, self.cfg
        rules = cfg.rules
        long = g.direction == "bullish"
        d = g.direction
        atr = e.atr[n]
        t = e.t[n]
        factors: list[SetupFactor] = []

        def add(key: str, mode: str, passed: Optional[bool], detail: str) -> None:
            pts = 1 if (passed and mode in ("required", "scored")) else 0
            factors.append(SetupFactor(key, FACTOR_LABELS[key], mode, passed, pts, detail))

        # --- liquidity sweep -------------------------------------------------
        lo_idx = g.first_index - cfg.sweep_lookback_bars
        sweep = None
        if rules.liquidity_sweep != "off":
            cands = []
            for s in reversed(e.liquidity.sweeps):
                if s.index < lo_idx:
                    break
                if s.implication == d and s.index <= g.created_index and not (cfg.one_setup_per_sweep and s.id in self.used_sweeps):
                    cands.append(s)
            if cands:
                sweep = min(cands, key=lambda s: s.extreme) if long else max(cands, key=lambda s: s.extreme)
            if sweep:
                add("liquidity_sweep", rules.liquidity_sweep, True,
                    f"{'Sell' if long else 'Buy'}-side liquidity swept: {sweep.level_label} {_p(sweep.level_price)} "
                    f"({'low' if long else 'high'} {_p(sweep.extreme)}, closed back at {_p(sweep.close)}) {g.created_index - sweep.index} candle(s) before the FVG formed.")
            else:
                add("liquidity_sweep", rules.liquidity_sweep, False,
                    f"No {'sell' if long else 'buy'}-side liquidity sweep within {cfg.sweep_lookback_bars} candles before the FVG.")
        else:
            add("liquidity_sweep", "off", None, "Rule disabled.")
        anchor = sweep.index if sweep else g.first_index

        # --- structure shift --------------------------------------------------
        if rules.structure_shift != "off":
            ev = next((x for x in reversed(e.structure.events) if x.direction == d and anchor <= x.index <= n), None)
            add("structure_shift", rules.structure_shift, ev is not None,
                f"{ev.type} {d} at {_p(ev.break_price)} broke swing {_p(ev.level)}." if ev else f"No {d} BOS/CHoCH since the anchor candle.")
        else:
            add("structure_shift", "off", None, "Rule disabled.")

        # --- displacement -----------------------------------------------------
        if rules.displacement != "off":
            dp = next((x for x in reversed(e.displacement.items) if x.direction == d and anchor <= x.index <= g.created_index), None)
            add("displacement", rules.displacement, dp is not None,
                f"{dp.kind.capitalize()}-candle {d} displacement, {dp.range_atr:.2f} x ATR." if dp else f"No {d} displacement between the anchor and the FVG.")
        else:
            add("displacement", "off", None, "Rule disabled.")

        # --- FVG (always required) -------------------------------------------
        add("fvg", "required", True,
            f"{d.capitalize()} FVG {_p(g.bottom)} - {_p(g.top)} (size {_p(g.size)}, {g.size_atr:.2f} x ATR) revisited {n - g.created_index} candle(s) after forming; candle held {'above' if long else 'below'} the gap.")

        # --- HTF bias ---------------------------------------------------------
        htf_tf = self.htf.timeframe if self.htf else None
        if self.htf is not None:
            bias, htf_open = self.htf.at(t + e.tf_seconds)
        else:
            bias, htf_open = e.structure.trend, None
        if rules.htf_bias != "off":
            src = f"{htf_tf} structure" if htf_tf else "same-timeframe structure (no higher TF configured)"
            add("htf_bias", rules.htf_bias, bias == d, f"Bias from {src}: {bias or 'undetermined'}.")
        else:
            add("htf_bias", "off", None, "Rule disabled.")

        # --- entry / stop -----------------------------------------------------
        entry = e.c[n]
        if long:
            extreme = min(e.l[anchor : n + 1])
            sl = extreme - cfg.sl_buffer_atr * atr
            risk = entry - sl
        else:
            extreme = max(e.h[anchor : n + 1])
            sl = extreme + cfg.sl_buffer_atr * atr
            risk = sl - entry
        if risk <= 0 or risk < cfg.min_risk_atr * atr:
            self._reject("Stop distance too small")
            return None

        # --- premium / discount ----------------------------------------------
        dr = e.pd.current
        if rules.premium_discount != "off":
            if dr is None:
                add("premium_discount", rules.premium_discount, False, "No dealing range yet.")
            else:
                zone = dr.zone(entry)
                want = "discount" if long else "premium"
                add("premium_discount", rules.premium_discount, zone == want,
                    f"Entry {_p(entry)} is in {zone.upper()} of range {_p(dr.low)} - {_p(dr.high)} (EQ {_p(dr.equilibrium)}).")
        else:
            add("premium_discount", "off", None, "Rule disabled.")

        # --- session ----------------------------------------------------------
        sess = e.sessions.session_at(t)
        if e.tf_seconds > 3600:
            add("session", "off", None, "Not applicable on 4H and higher timeframes.")
        elif rules.session != "off":
            ok = sess is not None and sess in cfg.setup_sessions
            add("session", rules.session, ok,
                f"Candle time is in {sess or 'no selected session'}; allowed: {', '.join(cfg.setup_sessions) or 'none'}.")
        else:
            add("session", "off", None, "Rule disabled.")

        # --- target -----------------------------------------------------------
        side = "buy" if long else "sell"
        levels = [lv for lv in e.liquidity.active if lv.status == "active" and lv.side == side and lv.active_from_index <= n
                  and ((lv.price > entry) if long else (lv.price < entry))]
        levels.sort(key=lambda lv: lv.price if long else -lv.price)
        target = next((lv for lv in levels if abs(lv.price - entry) / risk >= cfg.min_rr), None)
        if target is not None:
            tp = target.price
            tdesc = f"{target.label} at {_p(tp)}"
            tpass = True
            tdetail = f"Targeting {'buy' if long else 'sell'}-side liquidity: {tdesc} ({abs(tp - entry) / risk:.2f}R)."
        else:
            tp = entry + cfg.min_rr * risk if long else entry - cfg.min_rr * risk
            tdesc = f"Fixed {cfg.min_rr:g}R target at {_p(tp)} (no liquidity level >= {cfg.min_rr:g}R)"
            tpass = False
            tdetail = f"No active {'buy' if long else 'sell'}-side liquidity at >= {cfg.min_rr:g}R; using a fixed {cfg.min_rr:g}R target."
        if rules.liquidity_target != "off":
            add("liquidity_target", rules.liquidity_target, tpass, tdetail)
        else:
            add("liquidity_target", "off", None, "Rule disabled. " + tdetail)

        # --- order block -----------------------------------------------------
        if rules.order_block != "off":
            ob = next((b for b in reversed(e.order_blocks.blocks) if b.direction == d and anchor <= b.created_index <= n
                       and (b.invalidated_index is None or b.invalidated_index > n)), None)
            add("order_block", rules.order_block, ob is not None,
                f"{d.capitalize()} OB {_p(ob.bottom)} - {_p(ob.top)} formed by the same move (still valid)." if ob
                else f"No valid {d} order block created by this move.")
        else:
            add("order_block", "off", None, "Rule disabled.")

        # --- pending (later phases) ------------------------------------------
        news = e.context.extra.get("news")
        if rules.news == "off":
            add("news", "off", None, "Rule disabled.")
        elif news is None or not news.covers(t):
            factors.append(SetupFactor("news", FACTOR_LABELS["news"], "pending", None, 0,
                                       "No economic-calendar data for this time; not scored."))
        else:
            ev = news.blocking(t, cfg.news_minutes_before * 60, cfg.news_minutes_after * 60)
            add("news", rules.news, ev is None,
                f"Inside the window of {ev['name']} ({ev['currency']}, {ev['importance']}) at "
                f"{pd.Timestamp(ev['time'], unit='s', tz='UTC').strftime('%Y-%m-%d %H:%M')} UTC." if ev
                else f"No high-impact release within {cfg.news_minutes_before} min before / {cfg.news_minutes_after} min after.")

        order = list(FACTOR_LABELS)
        factors.sort(key=lambda f: order.index(f.key))

        # --- decision ---------------------------------------------------------
        failed_req = [f for f in factors if f.mode == "required" and not f.passed]
        if failed_req:
            self._reject("Required rule failed: " + ", ".join(f.label for f in failed_req))
            return None
        score = sum(f.points for f in factors)
        max_score = sum(1 for f in factors if f.mode in ("required", "scored"))
        if score < cfg.min_score:
            self._reject(f"Score below minimum ({cfg.min_score})")
            return None
        reward = abs(tp - entry)
        rr = reward / risk
        if rr + 1e-9 < cfg.min_rr:
            self._reject("R:R below minimum")
            return None

        if sweep is not None and cfg.one_setup_per_sweep:
            self.used_sweeps.add(sweep.id)
        side_word = "LONG" if long else "SHORT"
        status = {True: "Confirmed", False: "Not confirmed", None: "Not evaluated"}
        reasoning = [f"POSSIBLE {side_word} SETUP", f"{e.symbol}  {e.timeframe.upper()}"]
        for f in factors:
            if f.mode == "off":
                continue
            reasoning.append(f"{f.label}: {'Pending' if f.mode == 'pending' else status[f.passed]}")
        reasoning.append(f"Confluence: {score}/{max_score}")
        return Setup(
            id=f"setup-{d[:4]}-{t}-{g.id}",
            direction=d,
            label=f"POSSIBLE {side_word} SETUP",
            symbol=e.symbol,
            timeframe=e.timeframe,
            index=n,
            time=t,
            entry=round(entry, e.precision),
            stop_loss=round(sl, e.precision),
            take_profit=round(tp, e.precision),
            risk=round(risk, e.precision),
            reward=round(reward, e.precision),
            rr=round(rr, 2),
            score=score,
            max_score=max_score,
            factors=factors,
            fvg_id=g.id,
            sweep_id=sweep.id if sweep else None,
            target_level_id=target.id if target else None,
            target_description=tdesc,
            htf_timeframe=htf_tf,
            htf_bias=bias,
            session=sess,
            reasoning=reasoning,
        )
