"""Displacement (strong, decisive directional movement).

RULES
-----
ATR reference = ATR of the PREVIOUS candle (so the candle being judged does
not inflate its own yardstick).

Single-candle displacement at candle N:
    range[N] >= range_atr_mult * ATR[N-1]
    AND body[N] >= body_ratio * range[N]
    direction = bullish if close > open else bearish

Multi-candle displacement (optional) at candle N:
    the last `multi_candle_count` candles all close in the same direction
    AND their combined body >= multi_candle_atr_mult * ATR[N-count]
    (reported once per run, at the candle where it first qualifies)

If require_structure_break is on, a displacement only counts when a BOS/CHoCH
in the same direction happened on the same candle. The explanation always
says whether structure was broken.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from .types import Displacement, StructureEvent

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine
    from .settings import DisplacementSettings


class DisplacementDetector:
    def __init__(self, eng: "ICTEngine", cfg: "DisplacementSettings"):
        self.eng = eng
        self.cfg = cfg
        self.items: list[Displacement] = []
        self._multi_seen: dict[str, int] = {}

    def update(self, n: int, structure_events: list[StructureEvent]) -> list[Displacement]:
        e, cfg = self.eng, self.cfg
        if n < 1 or not e.atr_ready(n - 1):
            return []
        broke = {ev.direction: ev for ev in structure_events}
        o, h, l, c = e.o[n], e.h[n], e.l[n], e.c[n]
        rng, body = h - l, abs(c - o)
        atr_prev = e.atr[n - 1]
        out: list[Displacement] = []
        direction = "bullish" if c > o else "bearish" if c < o else None

        if direction and rng > 0 and rng >= cfg.range_atr_mult * atr_prev and body >= cfg.body_ratio * rng:
            ev = broke.get(direction)
            if ev is not None or not cfg.require_structure_break:
                lines = [
                    f"{direction.capitalize()} displacement detected (single candle)",
                    f"Candle range {rng:.2f} = {rng / atr_prev:.2f} x ATR ({atr_prev:.2f}) >= {cfg.range_atr_mult} x",
                    f"Body {body:.2f} = {body / rng:.0%} of range >= {cfg.body_ratio:.0%}",
                    f"Structure broken on this candle: {'YES - ' + ev.type if ev else 'no'}",
                ]
                out.append(Displacement(f"disp-{direction[:4]}-{e.t[n]}", direction, n, e.t[n], n, e.t[n], "single",
                                        round(rng, 5), round(body, 5), round(atr_prev, 5), round(rng / atr_prev, 3), ev is not None, lines))

        if cfg.multi_candle_enabled and not out:
            k = cfg.multi_candle_count
            if n - k >= 0 and e.atr_ready(n - k):
                dirs = {("bullish" if e.c[j] > e.o[j] else "bearish" if e.c[j] < e.o[j] else "flat") for j in range(n - k + 1, n + 1)}
                if len(dirs) == 1 and "flat" not in dirs:
                    d = dirs.pop()
                    total = sum(abs(e.c[j] - e.o[j]) for j in range(n - k + 1, n + 1))
                    ref = e.atr[n - k]
                    run_start = n - k + 1
                    if total >= cfg.multi_candle_atr_mult * ref:
                        continuing = self._multi_seen.get(d) == n - 1
                        self._multi_seen[d] = n  # report once per run of qualifying candles
                        ev = broke.get(d)
                        if not continuing and (ev is not None or not cfg.require_structure_break):
                            lines = [
                                f"{d.capitalize()} displacement detected ({k} consecutive candles)",
                                f"{k} candles all closed {d}; combined body {total:.2f} = {total / ref:.2f} x ATR ({ref:.2f}) >= {cfg.multi_candle_atr_mult} x",
                                f"Structure broken on the last candle: {'YES - ' + ev.type if ev else 'no'}",
                            ]
                            span_hi = max(e.h[j] for j in range(run_start, n + 1))
                            span_lo = min(e.l[j] for j in range(run_start, n + 1))
                            out.append(Displacement(f"disp-{d[:4]}-{e.t[n]}", d, n, e.t[n], run_start, e.t[run_start], "multi",
                                                    round(span_hi - span_lo, 5), round(total, 5), round(ref, 5), round(total / ref, 3), ev is not None, lines))
        self.items.extend(out)
        return out
