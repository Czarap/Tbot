"""Liquidity levels and liquidity sweeps.

LEVELS (buy-side = resting above highs, sell-side = resting below lows)
    swing_high / swing_low   every confirmed swing (known at swing confirmation)
    equal_highs / equal_lows two swings within equal_tolerance_atr * ATR of each
                             other while the older one is still untouched
    pdh / pdl                previous trading day high / low (17:00 NY rollover),
                             known from the first candle of the new day
    pwh / pwl                previous trading week high / low
    session_high / _low      completed Asia / London / New York session extremes

SWEEP vs BREAK, evaluated on each candle N for every active level:
    buy-side level  : high[N] > level AND close[N] < level  -> SWEEP (liquidity raid)
                      high[N] > level AND close[N] >= level -> BROKEN (taken by close)
    sell-side level : low[N]  < level AND close[N] > level  -> SWEEP
                      low[N]  < level AND close[N] <= level -> BROKEN
A level can only be swept by candles AFTER it became known (active_from_index).
"""
from __future__ import annotations

import bisect
from typing import TYPE_CHECKING, Optional

from .types import LiquidityLevel, SessionWindow, SweepEvent, Swing

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ICTEngine
    from .settings import LiquiditySettings

KIND_LABEL = {
    "swing_high": "Swing High",
    "swing_low": "Swing Low",
    "equal_highs": "EQH",
    "equal_lows": "EQL",
    "pdh": "PDH",
    "pdl": "PDL",
    "pwh": "PWH",
    "pwl": "PWL",
    "session_high": "High",
    "session_low": "Low",
}


class LiquidityTracker:
    def __init__(self, eng: "ICTEngine", cfg: "LiquiditySettings", context: Optional[dict] = None):
        self.eng = eng
        self.cfg = cfg
        self.levels: list[LiquidityLevel] = []
        self.active: list[LiquidityLevel] = []
        self.sweeps: list[SweepEvent] = []
        self._swing_level: dict[str, LiquidityLevel] = {}
        self._recent_highs: list[Swing] = []
        self._recent_lows: list[Swing] = []
        self._eq_for_swing: dict[str, LiquidityLevel] = {}
        ctx = context or {}
        self._daily = ctx.get("1d")  # dict with lists: time, high, low
        self._weekly = ctx.get("1w")
        self._day_idx: Optional[int] = None
        self._week_idx: Optional[int] = None

    # ----------------------------------------------------------------- helpers
    def _add(self, kind: str, side: str, price: float, start_time: int, n: int, active_from: int, label: Optional[str] = None, meta: Optional[dict] = None) -> LiquidityLevel:
        e = self.eng
        lv = LiquidityLevel(
            id=f"liq-{kind}-{start_time}-{e.t[n]}",
            kind=kind,
            side=side,
            label=label or KIND_LABEL[kind],
            price=price,
            start_time=start_time,
            created_index=n,
            created_time=e.t[n],
            active_from_index=active_from,
            meta=meta or {},
        )
        self.levels.append(lv)
        self.active.append(lv)
        return lv

    def _end(self, lv: LiquidityLevel, status: str, n: int) -> None:
        lv.status = status
        lv.end_index = n
        lv.end_time = self.eng.t[n]

    @staticmethod
    def _period_index(ref: Optional[dict], t: int) -> Optional[int]:
        if not ref or not ref["time"]:
            return None
        i = bisect.bisect_right(ref["time"], t) - 1
        return i if i >= 0 else None

    # ------------------------------------------------------------------ update
    def on_new_swings(self, n: int, swings: list[Swing]) -> None:
        e, cfg = self.eng, self.cfg
        tol = cfg.equal_tolerance_atr * e.atr[n]
        for s in swings:
            side = "buy" if s.kind == "high" else "sell"
            if cfg.include_swing_levels:
                lv = self._add("swing_high" if s.kind == "high" else "swing_low", side, s.price, s.time, n, n + 1,
                               label=f"{'BSL' if side == 'buy' else 'SSL'} ({s.label})", meta={"swing_id": s.id})
                self._swing_level[s.id] = lv
            if not cfg.include_equal_levels:
                continue
            recent = self._recent_highs if s.kind == "high" else self._recent_lows
            for prev in reversed(recent[-cfg.equal_lookback_swings:]):
                if abs(prev.price - s.price) > tol:
                    continue
                # the older swing must not have been taken out in between
                if s.kind == "high" and max(e.h[prev.index + 1 : s.index], default=-1e18) > max(prev.price, s.price):
                    continue
                if s.kind == "low" and min(e.l[prev.index + 1 : s.index], default=1e18) < min(prev.price, s.price):
                    continue
                kind = "equal_highs" if s.kind == "high" else "equal_lows"
                price = max(prev.price, s.price) if s.kind == "high" else min(prev.price, s.price)
                old = self._eq_for_swing.get(prev.id)
                ids = [prev.id, s.id]
                start = prev.time
                if old is not None and old.status == "active":
                    ids = old.meta["swing_ids"] + [s.id]
                    start = old.start_time
                    price = max(price, old.price) if s.kind == "high" else min(price, old.price)
                    self._end(old, "merged", n)
                eq = self._add(kind, side, price, start, n, n + 1,
                               label=f"{'EQH' if s.kind == 'high' else 'EQL'} x{len(ids)}",
                               meta={"swing_ids": ids, "tolerance": round(tol, 4)})
                for sid in ids:
                    self._eq_for_swing[sid] = eq
                break
            recent.append(s)
            if len(recent) > 50:
                del recent[:-50]

    def on_session_closed(self, n: int, windows: list[SessionWindow]) -> None:
        if not self.cfg.include_session_levels:
            return
        for w in windows:
            self._add("session_high", "buy", w.high, w.high_time, n, n, label=f"{w.name} High", meta={"session": w.name})
            self._add("session_low", "sell", w.low, w.low_time, n, n, label=f"{w.name} Low", meta={"session": w.name})

    def _periodic_levels(self, n: int) -> None:
        e, cfg = self.eng, self.cfg
        t = e.t[n]
        for ref, attr, kinds, enabled in (
            (self._daily, "_day_idx", ("pdh", "pdl"), cfg.include_previous_day),
            (self._weekly, "_week_idx", ("pwh", "pwl"), cfg.include_previous_week),
        ):
            if not enabled:
                continue
            i = self._period_index(ref, t)
            if i is None or i == getattr(self, attr):
                continue
            first_seen = getattr(self, attr) is None
            setattr(self, attr, i)
            # previous period's levels expire when a new period starts
            for lv in self.active:
                if lv.kind in kinds and lv.status == "active":
                    self._end(lv, "expired", n)
            if i - 1 < 0:
                continue
            # previous period is complete: its whole range is before ref.time[i] <= t
            ph, pl, pt = ref["high"][i - 1], ref["low"][i - 1], ref["time"][i - 1]
            start = ref["time"][i] if not first_seen else t
            self._add(kinds[0], "buy", ph, start, n, n, meta={"period_start": pt})
            self._add(kinds[1], "sell", pl, start, n, n, meta={"period_start": pt})

    def update(self, n: int) -> list[SweepEvent]:
        e, cfg = self.eng, self.cfg
        self._periodic_levels(n)
        hi, lo, cl, t = e.h[n], e.l[n], e.c[n], e.t[n]
        out: list[SweepEvent] = []
        still: list[LiquidityLevel] = []
        for lv in self.active:
            if lv.status != "active":
                continue
            if lv.active_from_index > n:
                still.append(lv)
                continue
            if lv.kind in ("swing_high", "swing_low", "equal_highs", "equal_lows", "session_high", "session_low") and n - lv.created_index > cfg.level_max_age_bars:
                self._end(lv, "expired", n)
                continue
            if lv.side == "buy" and hi > lv.price:
                if cl < lv.price:
                    out.append(self._sweep(n, lv, hi, cl))
                    self._end(lv, "swept", n)
                    lv.sweep_id = out[-1].id
                else:
                    self._end(lv, "broken", n)
                continue
            if lv.side == "sell" and lo < lv.price:
                if cl > lv.price:
                    out.append(self._sweep(n, lv, lo, cl))
                    self._end(lv, "swept", n)
                    lv.sweep_id = out[-1].id
                else:
                    self._end(lv, "broken", n)
                continue
            still.append(lv)
        self.active = still
        self.sweeps.extend(out)
        return out

    def _sweep(self, n: int, lv: LiquidityLevel, extreme: float, close: float) -> SweepEvent:
        e = self.eng
        buy = lv.side == "buy"
        lines = [
            f"{'BUY' if buy else 'SELL'}-SIDE LIQUIDITY SWEPT: {lv.label} at {lv.price:,.2f}",
            f"Price temporarily moved {'above' if buy else 'below'} the level ({'high' if buy else 'low'} {extreme:,.2f})",
            f"then closed back {'below' if buy else 'above'} it (close {close:,.2f}).",
            f"-> Potential liquidity sweep ({'bearish' if buy else 'bullish'} implication).",
        ]
        return SweepEvent(
            id=f"sweep-{lv.side}-{e.t[n]}-{lv.id}",
            side=lv.side,
            implication="bearish" if buy else "bullish",
            level_id=lv.id,
            level_kind=lv.kind,
            level_label=lv.label,
            level_price=lv.price,
            index=n,
            time=e.t[n],
            extreme=extreme,
            close=close,
            explanation=lines,
        )

    def active_levels(self, side: str) -> list[LiquidityLevel]:
        return [lv for lv in self.active if lv.side == side and lv.status == "active"]
