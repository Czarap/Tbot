"""Streaming ICT analysis engine.

==========================  ANTI-REPAINTING CONTRACT  ==========================
The engine is fed ONE candle at a time through ``update()``. It stores candles
in append-only lists, so while candle N is being processed the candles N+1,
N+2, ... do not exist anywhere inside the engine. Every detector reads only
from those lists. Consequences:

  * Only information available at candle N is used for decisions at candle N.
  * Running the engine on candles[0:N+1] and on candles[0:END] produces
    IDENTICAL decision records (swings, BOS/CHoCH, sweeps, FVG creation,
    displacement, setups) for every candle <= N. This is asserted by
    tests/test_no_lookahead.py.
  * The same engine instance is reused by the (Phase 3) backtester and the
    (Phase 4) replay mode: feed candles chronologically, read new events.

Lagging confirmations are explicit: e.g. a swing high at candle c is only
CONFIRMED at candle c + swing_length, and carries both indices.
External context (previous day/week ranges, HTF bias) is looked up only for
periods that had already CLOSED at the time of the candle being processed.
================================================================================
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import pandas as pd

from .displacement import DisplacementDetector
from .fvg import FVGDetector
from .liquidity import LiquidityTracker
from .mtf import HTFBias
from .order_blocks import OrderBlockDetector
from .premium_discount import PremiumDiscount
from .sessions import SessionTracker
from .settings import ICTSettings
from .setups import SetupEngine
from .structure import StructureTracker, SwingDetector


@dataclass
class EngineContext:
    """Closed-period reference data. Lists must be sorted by time."""

    daily: Optional[dict] = None  # {"time": [...], "high": [...], "low": [...]}
    weekly: Optional[dict] = None
    htf: Optional[HTFBias] = None
    extra: dict = field(default_factory=dict)

    @staticmethod
    def frame_to_ref(df: Optional[pd.DataFrame]) -> Optional[dict]:
        if df is None or df.empty:
            return None
        return {"time": [int(x) for x in df["time"]], "high": [float(x) for x in df["high"]], "low": [float(x) for x in df["low"]]}


class ICTEngine:
    def __init__(self, settings: ICTSettings | None = None, symbol: str = "XAUUSD", timeframe: str = "15m",
                 tf_seconds: int = 900, context: EngineContext | None = None, precision: int = 2):
        self.settings = s = settings or ICTSettings()
        self.symbol = symbol
        self.timeframe = timeframe
        self.tf_seconds = tf_seconds
        self.precision = precision
        self.context = context or EngineContext()
        # append-only candle storage (the ONLY price data the detectors can see)
        self.t: list[int] = []
        self.o: list[float] = []
        self.h: list[float] = []
        self.l: list[float] = []
        self.c: list[float] = []
        self.v: list[float] = []
        self.atr: list[float] = []
        self._tr: list[float] = []

        self.swings = SwingDetector(self, s.structure.swing_length)
        self.structure = StructureTracker(self, s.structure.break_confirmation)
        self.liquidity = LiquidityTracker(self, s.liquidity, {"1d": self.context.daily, "1w": self.context.weekly})
        self.sessions = SessionTracker(self, s.sessions, enabled=tf_seconds <= 3600)
        self.displacement = DisplacementDetector(self, s.displacement)
        self.order_blocks = OrderBlockDetector(self, s.order_blocks)
        self.fvg = FVGDetector(self, s.fvg.min_size, s.fvg.min_size_atr, s.fvg.max_age_bars)
        self.pd = PremiumDiscount(self, s.dealing_range.source)
        self.setup_engine = SetupEngine(self, s.setups, self.context.htf)

    # ----------------------------------------------------------------- basics
    def __len__(self) -> int:
        return len(self.t)

    def atr_ready(self, i: int) -> bool:
        return i >= self.settings.atr_period - 1

    def _update_atr(self, n: int) -> None:
        h, l = self.h[n], self.l[n]
        tr = h - l if n == 0 else max(h - l, abs(h - self.c[n - 1]), abs(l - self.c[n - 1]))
        self._tr.append(tr)
        p = self.settings.atr_period
        if n < p:
            self.atr.append(sum(self._tr) / len(self._tr))
        else:
            self.atr.append((self.atr[-1] * (p - 1) + tr) / p)

    # ----------------------------------------------------------------- update
    def update(self, t: int, o: float, h: float, l: float, c: float, v: float = 0.0) -> list[dict[str, Any]]:
        """Process the next CLOSED candle. Returns the new events it produced."""
        if self.t and t <= self.t[-1]:
            raise ValueError(f"Candles must be strictly chronological (got {t} after {self.t[-1]})")
        self.t.append(int(t)); self.o.append(float(o)); self.h.append(float(h))
        self.l.append(float(l)); self.c.append(float(c)); self.v.append(float(v))
        n = len(self.t) - 1
        self._update_atr(n)

        new_swings = self.swings.update(n)
        structure_events = self.structure.update(n, new_swings)
        self.liquidity.on_new_swings(n, new_swings)
        self.liquidity.on_session_closed(n, self.sessions.update(n))
        sweeps = self.liquidity.update(n)
        disps = self.displacement.update(n, structure_events)
        obs = self.order_blocks.update(n, structure_events)
        fvgs = self.fvg.update(n)
        self.pd.update(n)
        setups = self.setup_engine.update(n, fvgs)

        events: list[dict[str, Any]] = []
        for kind, items in (("swing", new_swings), ("structure", structure_events), ("sweep", sweeps),
                            ("displacement", disps), ("order_block", obs), ("fvg", fvgs), ("setup", setups)):
            events.extend({"kind": kind, "data": it.to_dict()} for it in items)
        return events

    def run(self, df: pd.DataFrame) -> "ICTEngine":
        cols = df[["time", "open", "high", "low", "close", "volume"]].itertuples(index=False, name=None)
        for t, o, h, l, c, v in cols:
            self.update(t, o, h, l, c, v)
        return self

    # ----------------------------------------------------------------- output
    def result(self, from_time: Optional[int] = None) -> dict[str, Any]:
        """Serialisable analysis. ``from_time`` trims objects that ended before
        the visible window (warm-up candles are analysed but not returned)."""
        ft = from_time if from_time is not None else (self.t[0] if self.t else 0)

        def alive(end: Optional[int]) -> bool:
            return end is None or end >= ft

        swings = [s.to_dict() for s in self.swings.swings if s.time >= ft]
        structure = [e.to_dict() for e in self.structure.events if e.time >= ft]
        levels = [lv.to_dict() for lv in self.liquidity.levels if lv.status in ("active", "swept") and alive(lv.end_time)]
        sweeps = [s.to_dict() for s in self.liquidity.sweeps if s.time >= ft]
        fvgs = [g.to_dict() for g in self.fvg.fvgs if g.status != "EXPIRED" and alive(g.filled_time)]
        disps = [d.to_dict() for d in self.displacement.items if d.time >= ft]
        obs = [b.to_dict() for b in self.order_blocks.blocks if alive(b.invalidated_time) and (b.invalidated_time is not None or b in self.order_blocks.active)]
        sessions = [w.to_dict() for w in self.sessions.windows if alive(w.end_time)]
        setups = [s.to_dict() for s in self.setup_engine.setups if s.time >= ft]

        dr = self.pd.current
        last = len(self.t) - 1
        htf = self.context.htf
        htf_bias, htf_time = (htf.at(self.t[last] + self.tf_seconds) if (htf and last >= 0) else (self.structure.trend, None))
        price = self.c[last] if last >= 0 else None
        above = sorted((lv for lv in self.liquidity.active if lv.status == "active" and price is not None and lv.price > price), key=lambda x: x.price)[:3]
        below = sorted((lv for lv in self.liquidity.active if lv.status == "active" and price is not None and lv.price < price), key=lambda x: -x.price)[:3]
        last_struct = self.structure.events[-1].to_dict() if self.structure.events else None
        return {
            "swings": swings,
            "structure_events": structure,
            "liquidity_levels": levels,
            "sweeps": sweeps,
            "fvgs": fvgs,
            "displacements": disps,
            "order_blocks": obs,
            "sessions": sessions,
            "dealing_range": dr.to_dict() if dr else None,
            "setups": setups,
            "summary": {
                "trend": self.structure.trend,
                "htf_timeframe": htf.timeframe if htf else None,
                "htf_bias": htf_bias,
                "htf_candle_time": htf_time,
                "last_structure_event": last_struct,
                "price": price,
                "atr": round(self.atr[last], 4) if last >= 0 else None,
                "zone": dr.zone(price) if (dr and price is not None) else None,
                "nearest_buy_side": [lv.to_dict() for lv in above],
                "nearest_sell_side": [lv.to_dict() for lv in below],
                "active_order_blocks": len(self.order_blocks.active),
                "active_fvgs": sum(1 for g in self.fvg.active if g.status in ("UNMITIGATED", "MITIGATED")),
                "setup_rejections": dict(self.setup_engine.rejections),
                "candles_analysed": len(self.t),
            },
        }
