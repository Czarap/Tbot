"""Strategy optimizer with train / validation / out-of-sample (test) splits and walk-forward.

OVERFITTING WARNING
-------------------
Testing many parameter combinations on the same history will always find some
that looked great by chance. This module therefore:
* ranks on the VALIDATION period only (never on the test period, never on profit alone),
* penalises combinations whose validation results fall away from training,
  combinations with few trades and combinations with deep drawdowns,
* reports the untouched TEST period only for the top-ranked combinations,
* offers walk-forward testing: pick the best combination on one window, measure
  it on the NEXT window, repeat — the honest estimate is the combined out-of-sample result.

Speed: setups only depend on the signal parameters (timeframe, minimum R:R and
rule modes), and the streaming engine makes a setup's existence independent of
later data. Setups are therefore generated ONCE per signal combination over the
whole period and re-used for every risk / session variant and every split.
"""
from __future__ import annotations

import itertools
import math
from typing import Callable, Literal, Optional

from pydantic import BaseModel, Field, model_validator

from backend.backtesting.config import BacktestConfig
from backend.backtesting.runner import generate_setups, prepare
from backend.backtesting.simulator import simulate
from backend.backtesting.stats import compute_stats

Mode = Literal["required", "scored"]


class OptimizeGrid(BaseModel):
    risk_percent: list[float] = Field(default_factory=lambda: [0.25, 0.5, 1.0])
    min_rr: list[float] = Field(default_factory=lambda: [1.0, 2.0, 3.0])
    timeframes: list[Literal["1m", "5m", "15m", "30m", "1h"]] = Field(default_factory=lambda: ["5m", "15m"])
    sessions: list[list[str]] = Field(default_factory=lambda: [["London"], ["New York"], ["London", "New York"]])
    liquidity_sweep: list[Mode] = Field(default_factory=lambda: ["required", "scored"])
    order_block: list[Mode] = Field(default_factory=lambda: ["required", "scored"])
    displacement: list[Mode] = Field(default_factory=lambda: ["scored"])

    def size(self) -> tuple[int, int]:
        signal = len(self.min_rr) * len(self.timeframes) * len(self.liquidity_sweep) * len(self.order_block) * len(self.displacement)
        return signal, signal * len(self.risk_percent) * len(self.sessions)


class OptimizeRequest(BaseModel):
    base: BacktestConfig = Field(default_factory=BacktestConfig)
    grid: OptimizeGrid = Field(default_factory=OptimizeGrid)
    train: float = Field(0.6, gt=0.1, lt=0.9)
    validation: float = Field(0.2, gt=0.05, lt=0.5)
    min_trades: int = Field(15, ge=1, le=1000, description="Minimum validation trades to be ranked")
    walk_forward_folds: int = Field(4, ge=0, le=12)
    top_n: int = Field(10, ge=1, le=50)

    @model_validator(mode="after")
    def _check(self):
        if self.train + self.validation >= 0.95:
            raise ValueError("train + validation must leave at least 5% for the test period")
        sig, total = self.grid.size()
        if total > 2000 or sig > 120:
            raise ValueError(f"Grid too large ({total} combinations, {sig} signal runs); limit is 2000 / 120")
        return self


def _metrics(trades, equity, start_balance) -> dict:
    s = compute_stats(trades, equity, start_balance)["stats"]
    return {k: s[k] for k in ("total_trades", "win_rate", "expectancy_r", "net_r", "profit_factor", "max_drawdown_pct", "return_pct")}


def robust_score(train: dict, val: dict, min_trades: int) -> Optional[float]:
    """Ranking score on VALIDATION results. None = not eligible (too few trades)."""
    n = val["total_trades"]
    if n < min_trades:
        return None
    exp = val["expectancy_r"]
    confidence = min(1.0, math.sqrt(n / 50))            # few trades -> shrink toward zero
    degradation = max(0.0, train["expectancy_r"] - exp)   # good in train, worse in validation
    dd_penalty = abs(val["max_drawdown_pct"]) / 20.0      # 20% drawdown costs 1R of expectancy
    return round(exp * confidence - 0.5 * degradation - dd_penalty, 4)


def optimize(analysis, req: OptimizeRequest, progress: Optional[Callable[[float, str], None]] = None) -> dict:
    g = req.grid
    signal_combos = list(itertools.product(g.timeframes, g.min_rr, g.liquidity_sweep, g.order_block, g.displacement))
    variants = list(itertools.product(g.risk_percent, [tuple(s) for s in g.sessions]))
    news = None  # economic-calendar index, fetched once for the whole period
    rows: list[dict] = []
    cache: dict = {}
    span = None
    for k, (tf, rr, sweep, ob, disp) in enumerate(signal_combos):
        if progress:
            progress(0.02 + 0.8 * k / len(signal_combos), f"Signals {k + 1}/{len(signal_combos)}: {tf}, R:R {rr}, sweep {sweep}, OB {ob}")
        cfg = req.base.model_copy(deep=True)
        cfg.timeframe, cfg.min_rr = tf, rr
        cfg.settings.setups.rules.liquidity_sweep = sweep
        cfg.settings.setups.rules.order_block = ob
        cfg.settings.setups.rules.displacement = disp
        prov, info, work, first, start_t, end_t, settings, ctx = prepare(analysis, cfg)
        if cfg.news.enabled and k == 0:
            news = analysis.news_index(start_t - 86400, end_t + 86400, cfg.news.currencies, cfg.news.min_importance)
        if news is not None:
            ctx.extra["news"] = news
        setups = generate_setups(work, settings, ctx, cfg.symbol, tf, info.price_precision)
        arr = [work[c].to_numpy() for c in ("time", "open", "high", "low", "close")]
        if span is None:
            span = (start_t, end_t)
        cache[(tf, rr, sweep, ob, disp)] = (cfg, info, arr, setups)

    s0, s1 = span
    a = s0 + int((s1 - s0) * req.train)
    b = a + int((s1 - s0) * req.validation)
    splits = {"train": (s0, a - 1), "validation": (a, b - 1), "test": (b, s1)}

    def run(sig, risk, sessions, seg) -> dict:
        cfg, info, arr, setups = cache[sig]
        c = cfg.model_copy(deep=True)
        c.risk.risk_percent = risk
        c.sessions = list(sessions)
        sim = simulate(*arr, setups, c, info, news, start_time=seg[0], end_time=seg[1], starting_balance=c.starting_balance)
        return _metrics(sim["trades"], sim["equity"], c.starting_balance)

    total = len(cache) * len(variants)
    done = 0
    for sig in cache:
        for risk, sessions in variants:
            tr, va = run(sig, risk, sessions, splits["train"]), run(sig, risk, sessions, splits["validation"])
            score = robust_score(tr, va, req.min_trades)
            tf, rr, sweep, ob, disp = sig
            rows.append({"params": {"timeframe": tf, "min_rr": rr, "liquidity_sweep": sweep, "order_block": ob,
                                    "displacement": disp, "risk_percent": risk, "sessions": list(sessions)},
                         "train": tr, "validation": va, "score": score, "_sig": sig})
            done += 1
            if progress and done % 10 == 0:
                progress(0.82 + 0.1 * done / total, f"Evaluated {done}/{total} combinations")

    ranked = sorted(rows, key=lambda r: (r["score"] is None, -(r["score"] or 0)))
    for r in ranked[: req.top_n]:
        p = r["params"]
        r["test"] = run(r["_sig"], p["risk_percent"], tuple(p["sessions"]), splits["test"])

    wf = walk_forward(cache, variants, run, s0, s1, req) if req.walk_forward_folds else None
    if progress:
        progress(1.0, "Done")

    warnings = [
        f"{total} combinations were tested on the same history. The best ones are partly lucky; "
        "trust the validation/test and walk-forward columns, not the training column.",
        "Ranking uses validation expectancy (R) adjusted for trade count, train→validation decay and drawdown — not total profit.",
    ]
    best = next((r for r in ranked if r["score"] is not None), None)
    if best is None:
        warnings.append(f"No combination reached {req.min_trades} validation trades. Use more data or lower 'min trades'.")
    elif "test" in best:
        bt, bv = best["test"], best["validation"]
        if bt["total_trades"] == 0 or bt["expectancy_r"] <= 0:
            warnings.append("The top combination did NOT make money in the untouched test period — likely overfit.")
        elif bt["expectancy_r"] < 0.5 * bv["expectancy_r"]:
            warnings.append("The top combination's test-period expectancy is less than half its validation expectancy — results decay out of sample.")
    for r in ranked:
        r.pop("_sig", None)
    return {"splits": {k: {"start": v[0], "end": v[1]} for k, v in splits.items()}, "combinations": total,
            "signal_runs": len(cache), "results": ranked, "walk_forward": wf, "warnings": warnings,
            "symbol": req.base.symbol}


def walk_forward(cache, variants, run, s0: int, s1: int, req: OptimizeRequest) -> dict:
    k = req.walk_forward_folds
    edges = [s0 + int((s1 - s0) * i / (k + 1)) for i in range(k + 2)]
    folds = []
    oos_trades = oos_r = oos_wins = 0
    for j in range(k):
        ins, oos = (edges[j], edges[j + 1] - 1), (edges[j + 1], edges[j + 2] - 1)
        best, best_score = None, None
        for sig in cache:
            for risk, sessions in variants:
                m = run(sig, risk, sessions, ins)
                sc = robust_score(m, m, max(1, req.min_trades // 2))
                if sc is not None and (best_score is None or sc > best_score):
                    best, best_score = (sig, risk, sessions, m), sc
        if best is None:
            folds.append({"fold": j + 1, "in_sample": {"start": ins[0], "end": ins[1]}, "out_of_sample": {"start": oos[0], "end": oos[1]},
                          "chosen": None, "in_sample_metrics": None, "out_of_sample_metrics": None})
            continue
        sig, risk, sessions, ins_m = best
        oos_m = run(sig, risk, sessions, oos)
        oos_trades += oos_m["total_trades"]
        oos_r += oos_m["net_r"]
        oos_wins += round(oos_m["win_rate"] * oos_m["total_trades"] / 100)
        tf, rr, sweep, ob, disp = sig
        folds.append({"fold": j + 1, "in_sample": {"start": ins[0], "end": ins[1]}, "out_of_sample": {"start": oos[0], "end": oos[1]},
                      "chosen": {"timeframe": tf, "min_rr": rr, "liquidity_sweep": sweep, "order_block": ob, "displacement": disp,
                                 "risk_percent": risk, "sessions": list(sessions)},
                      "in_sample_metrics": ins_m, "out_of_sample_metrics": oos_m})
    return {"folds": folds, "combined_out_of_sample": {
        "total_trades": oos_trades, "net_r": round(oos_r, 2),
        "win_rate": round(oos_wins / oos_trades * 100, 1) if oos_trades else 0.0,
        "expectancy_r": round(oos_r / oos_trades, 3) if oos_trades else 0.0}}
