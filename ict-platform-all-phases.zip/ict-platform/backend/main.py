"""FastAPI application entry point.

    python -m backend.main            # http://localhost:8000
    uvicorn backend.main:app --reload

Serves the JSON API under /api and the built frontend (frontend/dist) at /.
This application performs analysis only. It contains no broker connection and
cannot place, modify or manage orders.
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.api.live_routes import build_live_router
from backend.api.phase_routes import build_phase_router
from backend.database.store import Store
from backend.market_data.calendar import CalendarService
from backend.services.jobs import JobManager
from backend.services.replay import ReplayManager
from backend.api.routes import build_router
from backend.live.hub import LiveHub
from backend.market_data import MarketDataService
from backend.services.analysis_service import AnalysisService

FRONTEND_DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"


def create_app(service: AnalysisService | None = None) -> FastAPI:
    service = service or AnalysisService(MarketDataService.from_env(), calendar=CalendarService.from_env())
    hub = LiveHub(service.data, service)
    data_dir = os.path.abspath(os.environ.get("ICT_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "data")))
    store = Store.from_env()
    jobs = JobManager(workers=int(os.environ.get("ICT_JOB_WORKERS", "2")))
    replay = ReplayManager(service)

    @asynccontextmanager
    async def lifespan(_app):
        yield
        await hub.shutdown()

    app = FastAPI(title="ICT Analysis & Backtesting Platform", version="0.2.0", lifespan=lifespan,
                  description="Analysis-only ICT market-structure platform with live gold data. No order execution.")
    app.state.hub = hub
    app.add_middleware(
        CORSMiddleware,
        allow_origins=os.environ.get("ICT_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(","),
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )
    app.include_router(build_router(service))
    app.include_router(build_live_router(hub))
    app.include_router(build_phase_router(service, jobs, store, replay, service.calendar, data_dir))
    if FRONTEND_DIST.is_dir():
        app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host=os.environ.get("ICT_HOST", "127.0.0.1"), port=int(os.environ.get("ICT_PORT", "8000")))
