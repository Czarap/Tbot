"""Local store for candles CLOSED by the live feed.

Some sources keep only a short rolling history (biquote: ~300 one-minute bars).
Every candle the live hub closes is appended to
``data/live_cache/<provider>_<symbol>_<tf>.csv`` and loaded back on start-up,
so the usable history keeps growing while the app runs. Disable with
``ICT_PERSIST_LIVE=0``. Simulated data is never persisted.
"""
from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Optional

import pandas as pd

from .base import CANDLE_COLUMNS


class LiveCandleStore:
    def __init__(self, directory: str | os.PathLike, enabled: bool = True):
        self.dir = Path(directory)
        self.enabled = enabled
        self._lock = threading.Lock()

    def _path(self, provider_id: str, symbol: str, tf: str) -> Path:
        safe = "".join(ch for ch in f"{provider_id}_{symbol}_{tf}" if ch.isalnum() or ch in "_-")
        return self.dir / f"{safe}.csv"

    def append(self, provider_id: str, symbol: str, tf: str, candle: dict) -> None:
        if not self.enabled:
            return
        path = self._path(provider_id, symbol, tf)
        with self._lock:
            self.dir.mkdir(parents=True, exist_ok=True)
            new = not path.exists()
            with path.open("a", encoding="utf-8") as f:
                if new:
                    f.write(",".join(CANDLE_COLUMNS) + "\n")
                f.write(",".join(str(int(candle["time"])) if c == "time" else repr(float(candle.get(c, 0.0))) for c in CANDLE_COLUMNS) + "\n")

    def load(self, provider_id: str, symbol: str, tf: str) -> Optional[pd.DataFrame]:
        if not self.enabled:
            return None
        path = self._path(provider_id, symbol, tf)
        if not path.exists():
            return None
        try:
            df = pd.read_csv(path)
        except Exception:  # noqa: BLE001 - a damaged cache must never stop the app
            return None
        df = df.dropna()
        df["time"] = df["time"].astype("int64")
        # keep the last write for a timestamp (a candle can be re-closed after a resync)
        return df.drop_duplicates("time", keep="last").sort_values("time").reset_index(drop=True)
