"""MarketDataService: one entry point for candles at any timeframe.

* Picks a provider per instrument (XAUUSD and GC can come from different vendors).
* Loads the best native timeframe, cleans it, resamples upwards when needed.
* Merges candles CLOSED by the live feed (``append_live``) on top of history.
* Splits off the still-forming candle: analysis only ever sees CLOSED candles
  (anti-repainting); the chart gets the forming one separately.
"""
from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from typing import Iterable, Optional

import pandas as pd

from .base import CANDLE_COLUMNS, MarketDataProvider, ProviderInfo
from .cleaning import DataQualityReport, clean_candles
from .csv_provider import CSVProvider
from .live_store import LiveCandleStore
from .resample import WEEK, bucket_start, resample
from .synthetic import SyntheticProvider
from .timeframes import TIMEFRAMES


@dataclass
class CandleSet:
    symbol: str
    timeframe: str
    df: pd.DataFrame  # CLOSED candles only
    quality: DataQualityReport
    source_timeframe: str
    forming: Optional[dict] = None  # the still-open candle, if any
    provider_id: str = ""


def split_forming(df: pd.DataFrame, tf_seconds: int, now: float) -> tuple[pd.DataFrame, Optional[dict]]:
    if df.empty:
        return df, None
    last = df.iloc[-1]
    if int(last["time"]) + tf_seconds > now:
        forming = {k: (int(last[k]) if k == "time" else float(last[k])) for k in CANDLE_COLUMNS}
        return df.iloc[:-1].reset_index(drop=True), forming
    return df, None


def merge_live(history: pd.DataFrame, live: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Live-closed candles replace history rows with the same timestamp and extend it."""
    if live is None or live.empty:
        return history
    if history.empty:
        return live.reset_index(drop=True)
    keep = history[~history["time"].isin(live["time"])]
    return pd.concat([keep, live], ignore_index=True).sort_values("time", kind="mergesort").reset_index(drop=True)


class MarketDataService:
    def __init__(self, providers: Iterable[MarketDataProvider] | dict, default: Optional[str] = None,
                 cache_ttl: float = 300.0, symbol_defaults: Optional[dict[str, str]] = None,
                 live_store: Optional[LiveCandleStore] = None):
        plist = list(providers.values()) if isinstance(providers, dict) else list(providers)
        self.providers: dict[str, MarketDataProvider] = {p.id: p for p in plist}
        self.default = default if default in self.providers else plist[0].id
        self.symbol_defaults = symbol_defaults or {}
        self._ttl = cache_ttl
        self._raw: dict[tuple, tuple[float, pd.DataFrame, DataQualityReport]] = {}
        self._live: dict[tuple, pd.DataFrame] = {}
        self._version: dict[tuple, int] = {}
        self._lock = threading.RLock()
        self.live_store = live_store
        self._loaded_store: set = set()

    # ------------------------------------------------------------------ setup
    @classmethod
    def from_env(cls) -> "MarketDataService":
        from .providers.biquote import BiquoteProvider
        from .providers.databento_gc import DatabentoGCProvider
        from .providers.pyth_pro import PythProProvider
        from .providers.twelve_data import TwelveDataProvider

        data_dir = os.environ.get("ICT_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
        csv = CSVProvider(os.path.abspath(data_dir))
        bq, pyth, td, dbn = BiquoteProvider(), PythProProvider(), TwelveDataProvider(), DatabentoGCProvider()
        sim = SyntheticProvider(days=int(os.environ.get("ICT_SYNTHETIC_DAYS", "365")))
        providers: list[MarketDataProvider] = [bq, pyth, td, dbn, csv, sim]

        def pick(symbol: str, env: str, order: list[MarketDataProvider]) -> str:
            want = os.environ.get(env, os.environ.get("ICT_DATA_PROVIDER", "auto")).lower()
            if want not in ("", "auto"):
                return want
            for p in order:
                info = p.info()
                if info.configured and symbol in info.symbols and (p is not csv or symbol in [s.symbol for s in csv.symbols()]):
                    return p.id
            return sim.id

        defaults = {
            "XAUUSD": pick("XAUUSD", "ICT_PROVIDER_XAUUSD", [bq, pyth, td, csv]),
            "GC": pick("GC", "ICT_PROVIDER_GC", [dbn, pyth, csv]),
        }
        store = LiveCandleStore(os.path.join(os.path.abspath(data_dir), "live_cache"),
                                enabled=os.environ.get("ICT_PERSIST_LIVE", "1") != "0")
        return cls(providers, defaults["XAUUSD"], symbol_defaults=defaults, live_store=store)

    def provider(self, provider_id: Optional[str] = None, symbol: Optional[str] = None) -> MarketDataProvider:
        pid = provider_id or (self.symbol_defaults.get(symbol) if symbol else None)
        if pid is None and symbol:
            pid = next((p.id for p in self.providers.values()
                        if p.info().configured and symbol in [s.symbol for s in p.symbols()]), None)
        pid = pid or self.default
        if pid not in self.providers:
            raise KeyError(f"Unknown data provider '{pid}'")
        return self.providers[pid]

    def provider_infos(self) -> list[ProviderInfo]:
        return [p.info() for p in self.providers.values()]

    def instruments(self) -> list[dict]:
        out = []
        seen = set()
        for p in self.providers.values():
            for s in p.symbols():
                if s.symbol in seen:
                    continue
                seen.add(s.symbol)
                out.append({**s.to_dict(), "default_provider": self.provider(None, s.symbol).id,
                            "providers": [q.id for q in self.providers.values() if s.symbol in [x.symbol for x in q.symbols()]]})
        order = {"XAUUSD": 0, "GC": 1, "EURUSD": 2, "GBPUSD": 3, "USDJPY": 4, "BTCUSD": 5, "NAS100": 6, "US30": 7}
        return sorted(out, key=lambda x: order.get(x["symbol"], 9))

    # ------------------------------------------------------------------ live
    def append_live(self, provider_id: str, symbol: str, timeframe: str, candle: dict) -> None:
        """Record a candle CLOSED by the live feed (native timeframes only)."""
        key = (provider_id, symbol, timeframe)
        row = pd.DataFrame([{c: candle[c] for c in CANDLE_COLUMNS}])
        self._ensure_store_loaded(key)
        if self.live_store is not None and not self.providers[provider_id].info().is_synthetic:
            self.live_store.append(provider_id, symbol, timeframe, candle)
        with self._lock:
            cur = self._live.get(key)
            if cur is not None and len(cur):
                cur = cur[cur["time"] != int(candle["time"])]
                cur = pd.concat([cur, row], ignore_index=True).sort_values("time").tail(20000).reset_index(drop=True)
            else:
                cur = row
            self._live[key] = cur
            self._version[(provider_id, symbol)] = self._version.get((provider_id, symbol), 0) + 1

    def _ensure_store_loaded(self, key: tuple) -> None:
        if self.live_store is None or key in self._loaded_store:
            return
        self._loaded_store.add(key)
        if self.providers[key[0]].info().is_synthetic:
            return
        stored = self.live_store.load(*key)
        if stored is not None and len(stored):
            with self._lock:
                self._live[key] = merge_live(stored, self._live.get(key))

    def invalidate_history(self, provider_id: str, symbol: str) -> None:
        """Force a history reload (used to re-synchronise after a reconnect)."""
        with self._lock:
            for k in [k for k in self._raw if k[0] == provider_id and k[1] == symbol]:
                del self._raw[k]
            self._version[(provider_id, symbol)] = self._version.get((provider_id, symbol), 0) + 1

    def data_version(self, provider_id: str, symbol: str) -> int:
        return self._version.get((provider_id, symbol), 0)

    # --------------------------------------------------------------- candles
    def _source_tf(self, provider: MarketDataProvider, symbol: str, timeframe: str) -> str:
        natives = provider.native_timeframes(symbol)
        if not natives:
            raise LookupError(f"Provider '{provider.id}' has no data for {symbol}")
        if timeframe in natives:
            return timeframe
        target = TIMEFRAMES[timeframe]
        usable = [tf for tf in natives if TIMEFRAMES[tf] < target and target % TIMEFRAMES[tf] == 0]
        if not usable:
            raise LookupError(f"Provider '{provider.id}' cannot supply {symbol} {timeframe} (native: {natives})")
        return max(usable, key=lambda tf: TIMEFRAMES[tf])

    def _history(self, provider: MarketDataProvider, symbol: str, src: str) -> tuple[pd.DataFrame, DataQualityReport]:
        key = (provider.id, symbol, src)
        now = time.time()
        with self._lock:
            hit = self._raw.get(key)
            if hit and now - hit[0] < self._ttl:
                return hit[1], hit[2]
        raw = provider.get_historical_data(symbol, src)
        clean, rep = clean_candles(raw, TIMEFRAMES[src])
        if src in ("4h", "1d") and len(clean):
            # put vendor 4h/1d bars on the same session grid as the live aggregator (17:00 New York)
            t = clean["time"].to_numpy()
            rep.realigned_bars = int((bucket_start(t, src) != t).sum())
            if rep.realigned_bars:
                clean = resample(clean, src)
        with self._lock:
            self._raw[key] = (now, clean, rep)
        return clean, rep

    def get_candles(self, symbol: str, timeframe: str, provider_id: Optional[str] = None, now: Optional[float] = None) -> CandleSet:
        provider = self.provider(provider_id, symbol)
        provider.get_symbol_info(symbol)
        src = self._source_tf(provider, symbol, timeframe)
        hist, rep = self._history(provider, symbol, src)
        self._ensure_store_loaded((provider.id, symbol, src))
        with self._lock:
            live = self._live.get((provider.id, symbol, src))
        merged = merge_live(hist, live)
        df = merged if src == timeframe else resample(merged, timeframe)
        closed, forming = split_forming(df, TIMEFRAMES[timeframe], time.time() if now is None else now)
        return CandleSet(symbol, timeframe, closed, rep, src, forming, provider.id)

    def get_context(self, symbol: str, provider_id: Optional[str] = None) -> dict[str, pd.DataFrame]:
        """Closed daily + weekly candles used for previous-day / previous-week levels."""
        daily = self.get_candles(symbol, "1d", provider_id).df
        weekly = resample(daily, WEEK) if len(daily) else daily
        return {"1d": daily, "1w": weekly}
