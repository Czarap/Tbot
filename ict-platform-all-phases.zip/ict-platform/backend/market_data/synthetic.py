"""Deterministic synthetic gold data + a SIMULATED live tick feed.

USED ONLY when no real data source is configured (e.g. offline demo). The
prices are randomly generated and are NOT real market prices. The UI shows a
clear "SYNTHETIC DATA" badge whenever this provider is active.

The generator tries to be *structurally* plausible so the ICT detectors have
something meaningful to chew on: gold's trading hours (Sun 18:00 -> Fri 17:00
New York, daily 17:00 break), session-dependent volatility (quiet Asia,
active London / New York), volatility clustering, multi-day trends and
occasional news-style displacement bursts at 08:30 / 10:00 New York.
"""
from __future__ import annotations

import time as _time

import numpy as np
import pandas as pd

import asyncio
import math
import os

from .base import KNOWN_SYMBOLS, MarketDataProvider, OnEvent, OnTick, ProviderError, ProviderInfo, SymbolInfo, Tick
from .market_hours import is_market_closed, to_local_naive


def generate_xauusd_1m(days: int = 365, end_utc: int | None = None, seed: int = 7, start_price: float = 3600.0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    if end_utc is None:
        end_utc = int(_time.time()) // 60 * 60
    end_utc = end_utc // 60 * 60
    start = end_utc - days * 86400
    t = np.arange(start, end_utc, 60, dtype="int64")
    t = t[~is_market_closed(t)]
    n = len(t)

    local = to_local_naive(t)
    hour = local.hour.values + local.minute.values / 60.0
    # Session volatility profile (USD per minute, 1 sigma) in New York hours.
    vol = np.full(n, 0.32)
    vol[(hour >= 19) | (hour < 2)] = 0.28   # Asia
    vol[(hour >= 2) & (hour < 7)] = 0.55    # London
    vol[(hour >= 7) & (hour < 11.5)] = 0.70  # New York AM
    vol[(hour >= 11.5) & (hour < 16)] = 0.45
    # Volatility clustering: slow log-random-walk multiplier (mean-reverting).
    cl = np.zeros(n)
    eps = rng.normal(0, 0.035, n)
    for i in range(1, n):
        cl[i] = 0.995 * cl[i - 1] + eps[i]
    vol = 1.4 * vol * np.exp(cl)
    # Trend regimes lasting 0.5 - 4 days.
    drift = np.zeros(n)
    i = 0
    while i < n:
        length = int(rng.integers(700, 5500))
        drift[i : i + length] = rng.normal(0.0016, 0.05)
        i += length
    # News bursts: a handful of high-impact minutes per week.
    shocks = np.zeros(n)
    is_news_minute = ((local.hour.values == 8) & (local.minute.values == 30)) | ((local.hour.values == 10) & (local.minute.values == 0))
    news_idx = np.nonzero(is_news_minute & (rng.random(n) < 0.35))[0]
    for j in news_idx:
        size = rng.normal(0, 1) * rng.uniform(6, 16)
        k = int(rng.integers(3, 9))
        shocks[j : j + k] += size / k
    # Mean reversion to a slowly moving anchor creates ranges + sweeps.
    rets = rng.standard_t(5, n) * vol / np.sqrt(5 / 3) + drift + shocks
    close = np.empty(n)
    p = start_price
    anchor = start_price
    for i in range(n):
        anchor += 0.002 * (p - anchor)
        p = p + rets[i] - 0.0015 * (p - anchor)
        close[i] = p
    open_ = np.empty(n)
    open_[0] = start_price
    open_[1:] = close[:-1]
    gap_open = np.diff(t, prepend=t[0]) > 60
    open_[gap_open] += rng.normal(0, 0.6, gap_open.sum())
    wick = np.abs(rng.normal(0, 1, (2, n))) * vol * 0.55
    high = np.maximum(open_, close) + wick[0]
    low = np.minimum(open_, close) - wick[1]
    volume = np.round((40 + 400 * vol) * (1 + np.abs(rets) / (vol + 1e-9) * 0.4) * rng.uniform(0.7, 1.3, n))
    df = pd.DataFrame({"time": t, "open": open_, "high": high, "low": low, "close": close, "volume": volume})
    for c in ("open", "high", "low", "close"):
        df[c] = df[c].round(2)
    return df


class SyntheticProvider(MarketDataProvider):
    """Offline provider: synthetic history plus simulated ticks.

    Status is always reported as SIMULATED (never LIVE). GC is generated from a
    different seed with a futures-style premium so the two instruments differ.
    Env: ICT_SIM_IGNORE_HOURS=1 keeps ticking when the real market is closed;
    ICT_SIM_DISCONNECT_EVERY=<s> simulates a dropped connection for testing.
    """

    id = "simulated"

    def __init__(self, days: int = 365, seed: int = 7, end_utc: int | None = None, tick_interval: float = 0.25):
        self.days = days
        self.seed = seed
        self.end_utc = end_utc
        self.tick_interval = tick_interval
        self._cache: dict[str, pd.DataFrame] = {}
        self._last: dict[str, float] = {}

    def info(self) -> ProviderInfo:
        return ProviderInfo(
            id=self.id,
            name="Simulated feed",
            description=f"Randomly generated gold-like candles ({self.days} days) and simulated ticks. For offline testing only.",
            is_synthetic=True,
            native_timeframes=["1m"],
            symbols=["XAUUSD", "GC"],
            realtime=False,
            transport="simulated",
            warning="SIMULATED DATA - not real gold prices. Set PYTH_API_KEY, TWELVEDATA_API_KEY or DATABENTO_API_KEY for real data.",
        )

    def symbols(self) -> list[SymbolInfo]:
        return [KNOWN_SYMBOLS["XAUUSD"], KNOWN_SYMBOLS["GC"]]

    def native_timeframes(self, symbol: str) -> list[str]:
        return ["1m"]

    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        self.get_symbol_info(symbol)
        if timeframe != "1m":
            raise ValueError("Simulated provider only produces 1m data; higher TFs are resampled")
        if symbol not in self._cache:
            if symbol == "GC":
                df = generate_xauusd_1m(self.days, self.end_utc, self.seed + 101, start_price=3620.0)
                for c in ("open", "high", "low", "close"):
                    df[c] = (df[c] + 22.0).round(1)  # futures premium over spot, 0.1 tick
            else:
                df = generate_xauusd_1m(self.days, self.end_utc, self.seed)
            self._cache[symbol] = df
        return self._cache[symbol].copy()

    @property
    def supports_streaming(self) -> bool:
        return True

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        rng = np.random.default_rng(int(_time.time() * 1000) % 2**32)
        price = self._last.get(symbol) or float(self.get_historical_data(symbol, "1m")["close"].iloc[-1])
        step = 0.1 if symbol == "GC" else 0.01
        ignore_hours = os.environ.get("ICT_SIM_IGNORE_HOURS") == "1"
        drop_every = float(os.environ.get("ICT_SIM_DISCONNECT_EVERY", "0") or 0)
        started = _time.time()
        on_event("connected", {"transport": "simulated"})
        while True:
            await asyncio.sleep(self.tick_interval)
            now = _time.time()
            if drop_every and now - started > drop_every:
                raise ProviderError("Simulated connection drop")
            if not ignore_hours and is_market_closed(np.array([int(now)]))[0]:
                continue
            sigma = 0.9 * math.sqrt(self.tick_interval / 60.0) * 1.4
            price = max(1.0, price + rng.standard_t(5) * sigma)
            price = round(round(price / step) * step, 2)
            self._last[symbol] = price
            spread = 0.3 if symbol == "GC" else 0.18
            on_tick(Tick(symbol, now, price, bid=round(price - spread / 2, 2), ask=round(price + spread / 2, 2),
                         size=float(rng.integers(1, 20))))
