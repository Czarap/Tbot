"""Resample candles to higher timeframes.

* 5m .. 1h  : aligned to UTC multiples (New York offsets are whole hours, so
              these also align to New York clock hours).
* 4h        : anchored at the 17:00 New York rollover -> 17,21,01,05,09,13.
* 1d        : one candle per trading day (17:00 New York -> 17:00).
* 1w        : trading weeks starting Sunday 17:00 New York (internal use for
              previous-week high/low).
Bucket timestamps are the theoretical bucket OPEN time in UTC seconds.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .base import CANDLE_COLUMNS
from .market_hours import EXCHANGE_TZ, ROLLOVER_HOUR, to_local_naive, local_naive_to_utc_seconds

WEEK = "1w"


def bucket_start(times: np.ndarray, target: str | int, tz: str = EXCHANGE_TZ) -> np.ndarray:
    """Bucket open time (UTC seconds) for each timestamp."""
    times = np.asarray(times, dtype="int64")
    if isinstance(target, str) and target not in ("4h", "1d", WEEK):
        from .timeframes import tf_seconds
        target = tf_seconds(target)
    if isinstance(target, int):
        if target in (14400, 86400):
            target = {14400: "4h", 86400: "1d"}[target]
        else:
            return (times // target) * target

    local = to_local_naive(times, tz)
    shift = pd.Timedelta(hours=24 - ROLLOVER_HOUR)
    shifted = local + shift  # trading-day wall clock: 00:00 == 17:00 NY
    tdate = shifted.normalize()
    if target == "4h":
        start_shifted = tdate + pd.to_timedelta((shifted.hour // 4) * 4, unit="h")
    elif target == "1d":
        start_shifted = tdate
    elif target == WEEK:
        start_shifted = tdate - pd.to_timedelta(tdate.dayofweek, unit="D")
    else:  # pragma: no cover
        raise ValueError(target)
    return local_naive_to_utc_seconds(pd.DatetimeIndex(start_shifted - shift), tz)


def resample(df: pd.DataFrame, target: str | int) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=CANDLE_COLUMNS)
    key = bucket_start(df["time"].to_numpy(), target)
    g = df.assign(_k=key).groupby("_k", sort=True)
    out = pd.DataFrame(
        {
            "time": g["_k"].first().index.astype("int64"),
            "open": g["open"].first().to_numpy(),
            "high": g["high"].max().to_numpy(),
            "low": g["low"].min().to_numpy(),
            "close": g["close"].last().to_numpy(),
            "volume": g["volume"].sum().to_numpy(),
        }
    )
    return out.reset_index(drop=True)
