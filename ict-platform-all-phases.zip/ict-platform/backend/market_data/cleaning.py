"""Candle data validation and cleaning.

Handles: missing values, non-numeric junk, unsorted rows, duplicate
timestamps, inconsistent OHLC (high < close etc.) and reports gaps. Gaps are
*reported, never filled*: inventing candles would create fake price action
that the ICT detectors would then analyse.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict

import numpy as np
import pandas as pd

from .base import CANDLE_COLUMNS
from .market_hours import is_market_closed


@dataclass
class DataQualityReport:
    rows_in: int = 0
    rows_out: int = 0
    invalid_rows_removed: int = 0
    duplicates_removed: int = 0
    was_unsorted: bool = False
    ohlc_fixed: int = 0
    gaps_total: int = 0
    gaps_unexpected: int = 0
    largest_gap_seconds: int = 0
    unexpected_gap_samples: list[dict] = field(default_factory=list)
    realigned_bars: int = 0  # provider 4h/1d bars moved onto the 17:00 New York session grid

    def to_dict(self) -> dict:
        return asdict(self)


def clean_candles(df: pd.DataFrame, tf_seconds: int, check_market_hours: bool = True) -> tuple[pd.DataFrame, DataQualityReport]:
    rep = DataQualityReport(rows_in=len(df))
    if df.empty:
        return pd.DataFrame(columns=CANDLE_COLUMNS), rep

    out = df.copy()
    if "volume" not in out.columns:
        out["volume"] = 0.0
    missing = [c for c in CANDLE_COLUMNS if c not in out.columns]
    if missing:
        raise ValueError(f"Candle data is missing columns: {missing}")
    out = out[CANDLE_COLUMNS]

    for c in ["open", "high", "low", "close", "volume"]:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out["time"] = pd.to_numeric(out["time"], errors="coerce")
    out["volume"] = out["volume"].fillna(0.0)

    bad = out[["time", "open", "high", "low", "close"]].isna().any(axis=1)
    bad |= (out[["open", "high", "low", "close"]] <= 0).any(axis=1)
    rep.invalid_rows_removed = int(bad.sum())
    out = out[~bad].copy()
    out["time"] = out["time"].astype("int64")

    if not out["time"].is_monotonic_increasing:
        rep.was_unsorted = True
        out = out.sort_values("time", kind="mergesort")

    before = len(out)
    out = out.drop_duplicates(subset="time", keep="last")
    rep.duplicates_removed = before - len(out)

    o, h, l, c = (out[k].to_numpy() for k in ("open", "high", "low", "close"))
    true_high = np.maximum.reduce([o, h, l, c])
    true_low = np.minimum.reduce([o, h, l, c])
    fixed = (true_high != h) | (true_low != l)
    rep.ohlc_fixed = int(fixed.sum())
    out["high"] = true_high
    out["low"] = true_low

    out = out.reset_index(drop=True)
    rep.rows_out = len(out)

    if len(out) > 1:
        t = out["time"].to_numpy()
        diffs = np.diff(t)
        gap_idx = np.nonzero(diffs > tf_seconds)[0]
        rep.gaps_total = int(len(gap_idx))
        if len(gap_idx):
            rep.largest_gap_seconds = int(diffs[gap_idx].max())
            if check_market_hours and tf_seconds < 86400:
                # A gap is "expected" if the first missing candle falls in a closed period.
                first_missing = t[gap_idx] + tf_seconds
                expected = is_market_closed(first_missing)
                unexpected = gap_idx[~expected]
            else:
                unexpected = gap_idx[diffs[gap_idx] > 4 * 86400] if tf_seconds >= 86400 else gap_idx
            rep.gaps_unexpected = int(len(unexpected))
            rep.unexpected_gap_samples = [
                {"after_time": int(t[i]), "next_time": int(t[i + 1]), "missing_seconds": int(diffs[i] - tf_seconds)}
                for i in unexpected[:10]
            ]
    return out, rep
