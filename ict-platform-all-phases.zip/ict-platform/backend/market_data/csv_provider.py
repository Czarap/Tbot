"""CSV provider for real historical data you download yourself.

Put files in ``data/`` named ``<SYMBOL>_<TF>.csv`` (e.g. ``XAUUSD_1m.csv``,
``XAUUSD_1h.csv``). The parser understands the common export formats:

* generic   : time,open,high,low,close[,volume]   (epoch s/ms or ISO-8601)
* MetaTrader: <DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>...
* Dukascopy : Gmt time,Open,High,Low,Close,Volume  ("01.01.2024 00:00:00.000")
* HistData  : 20240102 180000;open;high;low;close;volume  (no header, EST w/o DST)

Set the source time zone with ``ICT_CSV_TZ`` (default UTC). HistData files are
always fixed EST (UTC-5) and are detected automatically.
"""
from __future__ import annotations

import csv
import io
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .base import KNOWN_SYMBOLS, MarketDataProvider, ProviderInfo, SymbolInfo
from .timeframes import TIMEFRAMES

_FILE_RE = re.compile(r"^([A-Z0-9]+)_(1m|5m|15m|30m|1h|4h|1d)\.csv$", re.I)


def _to_utc_seconds(dt: pd.Series, tz: str) -> np.ndarray:
    dt = pd.to_datetime(dt, errors="coerce")
    if getattr(dt.dt, "tz", None) is None:
        dt = dt.dt.tz_localize(tz, ambiguous="NaT", nonexistent="NaT")
    dt = dt.dt.tz_convert("UTC").dt.as_unit("s")
    secs = dt.astype("int64").astype("float64")
    secs[dt.isna()] = np.nan
    return secs.to_numpy(dtype="float64")


def parse_candle_csv(text: str, tz: str = "UTC") -> pd.DataFrame:
    """Parse CSV text in any supported format into the standard candle frame."""
    sample = text[:4096]
    first = sample.splitlines()[0] if sample else ""

    # HistData: "20240102 180000;2063.5;2064.1;..." (no header)
    if re.match(r"^\d{8} \d{6};", first):
        raw = pd.read_csv(io.StringIO(text), sep=";", header=None, names=["dt", "open", "high", "low", "close", "volume"])
        dt = pd.to_datetime(raw["dt"], format="%Y%m%d %H%M%S", errors="coerce") + pd.Timedelta(hours=5)
        raw["time"] = _to_utc_seconds(dt, "UTC")
        return raw[["time", "open", "high", "low", "close", "volume"]]

    try:
        delim = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except csv.Error:
        delim = ","
    raw = pd.read_csv(io.StringIO(text), sep=delim)
    raw.columns = [re.sub(r"[<>\s]", "", str(c)).lower() for c in raw.columns]
    rename = {"o": "open", "h": "high", "l": "low", "c": "close", "v": "volume", "tickvol": "volume", "vol": "volume", "tick_volume": "volume"}
    raw = raw.rename(columns={k: v for k, v in rename.items() if k in raw.columns and v not in raw.columns})

    if "date" in raw.columns and "time" in raw.columns:
        dt_str = raw["date"].astype(str).str.replace(".", "-", regex=False) + " " + raw["time"].astype(str)
        secs = _to_utc_seconds(dt_str, tz)
    else:
        tcol = next((c for c in ("time", "timestamp", "datetime", "date", "gmttime", "localtime") if c in raw.columns), None)
        if tcol is None:
            raise ValueError(f"No time column found in CSV columns {list(raw.columns)}")
        col = raw[tcol]
        if pd.api.types.is_numeric_dtype(col):
            vals = col.astype("float64").to_numpy()
            secs = np.where(vals > 1e12, vals / 1000.0, vals)  # ms -> s
        else:
            s = col.astype(str)
            if s.str.match(r"^\d{2}\.\d{2}\.\d{4}").all():  # Dukascopy dd.mm.yyyy
                parsed = pd.to_datetime(s.str.slice(0, 19), format="%d.%m.%Y %H:%M:%S", errors="coerce")
                secs = _to_utc_seconds(parsed, "UTC" if tcol == "gmttime" else tz)
            else:
                secs = _to_utc_seconds(s.str.replace(".", "-", regex=False) if s.str.match(r"^\d{4}\.\d{2}\.\d{2}").all() else s, tz)
    raw["time"] = secs
    if "volume" not in raw.columns:
        raw["volume"] = 0.0
    missing = [c for c in ("open", "high", "low", "close") if c not in raw.columns]
    if missing:
        raise ValueError(f"CSV is missing price columns: {missing}")
    return raw[["time", "open", "high", "low", "close", "volume"]]


class CSVProvider(MarketDataProvider):
    id = "csv"

    def __init__(self, directory: str | os.PathLike = "data", tz: str | None = None):
        self.directory = Path(directory)
        self.tz = tz or os.environ.get("ICT_CSV_TZ", "UTC")
        self._cache: dict[tuple[str, str], pd.DataFrame] = {}

    def _files(self) -> dict[tuple[str, str], Path]:
        found: dict[tuple[str, str], Path] = {}
        if self.directory.is_dir():
            for p in self.directory.iterdir():
                m = _FILE_RE.match(p.name)
                if m:
                    found[(m.group(1).upper(), m.group(2).lower())] = p
        return found

    def available(self) -> bool:
        return bool(self._files())

    def info(self) -> ProviderInfo:
        files = self._files()
        return ProviderInfo(
            id=self.id,
            name="CSV files",
            description=f"Historical candles loaded from {self.directory}/ ({len(files)} file(s), source tz {self.tz}).",
            is_synthetic=False,
            native_timeframes=sorted({tf for _, tf in files}, key=lambda x: TIMEFRAMES[x]),
            warning=None if files else f"No CSV files found in {self.directory}/ (expected e.g. XAUUSD_1m.csv)",
            symbols=sorted({s for s, _ in files}), realtime=False, transport="none", configured=bool(files),
            setup_hint=None if files else "Put files like XAUUSD_1m.csv or GC_1m.csv in data/.",
        )

    def symbols(self) -> list[SymbolInfo]:
        syms = sorted({s for s, _ in self._files()})
        return [KNOWN_SYMBOLS.get(s, SymbolInfo(s, s, 0.01, 2)) for s in syms]

    def native_timeframes(self, symbol: str) -> list[str]:
        return sorted([tf for (s, tf) in self._files() if s == symbol], key=lambda x: TIMEFRAMES[x])

    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        key = (symbol, timeframe)
        if key not in self._cache:
            path = self._files().get(key)
            if path is None:
                raise FileNotFoundError(f"No CSV for {symbol} {timeframe} in {self.directory}/")
            self._cache[key] = parse_candle_csv(path.read_text(), self.tz)
        return self._cache[key].copy()
