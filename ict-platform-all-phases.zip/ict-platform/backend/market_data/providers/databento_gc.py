"""Databento — COMEX gold futures (GC) from CME Globex (dataset GLBX.MDP3).

Requires ``pip install databento`` and ``DATABENTO_API_KEY``. Live CME data is
licensed: Databento passes CME exchange fees through, check your plan.

* Symbol: continuous front month by volume, ``GC.v.0`` (override with
  ``DATABENTO_GC_SYMBOL``, e.g. ``GC.c.0`` for calendar roll). The underlying
  contract changes at the roll; prices are NOT back-adjusted, so a roll can
  show as a gap.
* History: ``timeseries.get_range`` with schemas ``ohlcv-1m`` / ``ohlcv-1h``.
* Live: ``Live`` client, ``trades`` schema; each trade becomes a tick.
"""
from __future__ import annotations

import asyncio
import os
import threading
import time
from typing import Any, Optional

import pandas as pd

from ..base import (KNOWN_SYMBOLS, AuthError, MarketDataProvider, OnEvent, OnTick, ProviderError, ProviderInfo,
                    SymbolInfo, Tick)

DATASET = "GLBX.MDP3"
SCHEMA = {"1m": ("ohlcv-1m", 60, 3000), "1h": ("ohlcv-1h", 3600, 5000)}


def _db():
    try:
        import databento  # type: ignore
        return databento
    except ImportError:
        return None


def normalise_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Databento ``to_df()`` output (ts_event index) -> standard candle frame."""
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    idx = pd.DatetimeIndex(df.index)
    idx = idx.tz_localize("UTC") if idx.tz is None else idx.tz_convert("UTC")
    out = pd.DataFrame({
        "time": idx.as_unit("s").asi8.astype("int64"),
        "open": df["open"].astype(float).to_numpy(), "high": df["high"].astype(float).to_numpy(),
        "low": df["low"].astype(float).to_numpy(), "close": df["close"].astype(float).to_numpy(),
        "volume": df["volume"].astype(float).to_numpy() if "volume" in df else 0.0,
    })
    # Raw fixed-point prices (1 unit = 1e-9) if the client did not convert them.
    if out["close"].median() > 1e7:
        for c in ("open", "high", "low", "close"):
            out[c] = out[c] / 1e9
    return out


def trade_to_tick(record: Any, symbol: str) -> Optional[Tick]:
    price = getattr(record, "price", None)
    ts = getattr(record, "ts_event", None)
    if price is None or ts is None or getattr(record, "rtype", None) is None:
        return None
    px = float(getattr(record, "pretty_price", None) or price / 1e9)
    if px <= 0 or px > 1e7:
        return None  # undefined / sentinel price
    return Tick(symbol, int(ts) / 1e9, px, size=float(getattr(record, "size", 0) or 0))


class DatabentoGCProvider(MarketDataProvider):
    id = "databento"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key if api_key is not None else os.environ.get("DATABENTO_API_KEY", "")
        self.continuous = os.environ.get("DATABENTO_GC_SYMBOL", "GC.v.0")

    def info(self) -> ProviderInfo:
        pkg = _db() is not None
        configured = bool(self.api_key) and pkg
        hint = None
        if not pkg:
            hint = "pip install databento"
        elif not self.api_key:
            hint = "Set DATABENTO_API_KEY (CME live data is licensed)."
        return ProviderInfo(
            id=self.id, name=f"Databento CME ({self.continuous})", is_synthetic=False, realtime=True, transport="websocket",
            description="COMEX gold futures (GC) trades from CME Globex via Databento; continuous front month, not back-adjusted.",
            native_timeframes=list(SCHEMA), symbols=["GC"], configured=configured, setup_hint=hint,
        )

    def symbols(self) -> list[SymbolInfo]:
        return [KNOWN_SYMBOLS["GC"]]

    def native_timeframes(self, symbol: str) -> list[str]:
        return list(SCHEMA)

    def _require(self):
        db = _db()
        if db is None:
            raise ProviderError("The 'databento' package is not installed (pip install databento)")
        if not self.api_key:
            raise AuthError("DATABENTO_API_KEY is not set")
        return db

    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        self.get_symbol_info(symbol)
        db = self._require()
        schema, secs, bars = SCHEMA[timeframe]
        client = db.Historical(self.api_key)
        start = pd.Timestamp(time.time() - bars * secs * 7 / 5, unit="s", tz="UTC")
        try:
            data = client.timeseries.get_range(dataset=DATASET, schema=schema, stype_in="continuous",
                                               symbols=[self.continuous], start=start)
        except Exception as exc:  # databento raises its own BentoError subclasses
            text = str(exc)
            if "401" in text or "403" in text or "auth" in text.lower():
                raise AuthError(f"Databento: {text}") from exc
            raise ProviderError(f"Databento: {text}") from exc
        return normalise_ohlcv(data.to_df())

    @property
    def supports_streaming(self) -> bool:
        return True

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        db = self._require()
        loop = asyncio.get_running_loop()
        done: asyncio.Future = loop.create_future()
        client = db.Live(key=self.api_key)
        client.subscribe(dataset=DATASET, schema="trades", stype_in="continuous", symbols=[self.continuous])

        def run() -> None:
            try:
                loop.call_soon_threadsafe(on_event, "connected", {"symbol": self.continuous})
                for record in client:  # blocks; ends when the session closes
                    if isinstance(record, getattr(db, "ErrorMsg", ())):
                        raise ProviderError(f"Databento: {getattr(record, 'err', record)}")
                    tick = trade_to_tick(record, symbol) if isinstance(record, getattr(db, "TradeMsg", ())) else None
                    if tick is not None:
                        loop.call_soon_threadsafe(on_tick, tick)
                loop.call_soon_threadsafe(_set, done, ProviderError("Databento live session closed"))
            except Exception as exc:  # noqa: BLE001
                loop.call_soon_threadsafe(_set, done, exc)

        threading.Thread(target=run, name="databento-live", daemon=True).start()
        try:
            exc = await done
        finally:
            try:
                client.terminate()
            except Exception:  # noqa: BLE001
                pass
        raise exc


def _set(fut: asyncio.Future, exc: BaseException) -> None:
    if not fut.done():
        fut.set_result(exc)
