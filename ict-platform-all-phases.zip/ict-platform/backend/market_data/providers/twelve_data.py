"""Twelve Data — spot XAUUSD (``XAU/USD``).

Set ``TWELVEDATA_API_KEY``. Two live modes:

* ``TWELVEDATA_STREAM=websocket`` — ``wss://ws.twelvedata.com/v1/quotes/price``
  (full WebSocket access requires the Pro plan or higher; Basic/Grow only allow
  trial symbols).
* ``TWELVEDATA_STREAM=polling`` (default) — polls the latest 1-minute bar every
  ``TWELVEDATA_POLL_SECONDS`` (default 15 s). Works on smaller plans but uses API
  credits; the UI shows "polling" so nobody mistakes it for tick streaming.

All REST calls go through a token bucket (``TWELVEDATA_CREDITS_PER_MIN``,
default 8 = free plan). HTTP 429 / code 429 responses back off and retry.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, Callable, Optional

import pandas as pd

from ..base import (KNOWN_SYMBOLS, AuthError, MarketDataProvider, OnEvent, OnTick, ProviderError, ProviderInfo, Quote,
                    RateLimitError, SymbolInfo, Tick)
from ..http import TokenBucket, build_url, http_get_json

REST = "https://api.twelvedata.com"
WS_URL = "wss://ws.twelvedata.com/v1/quotes/price"
INTERVAL = {"1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1h"}
SYMBOLS = {"XAUUSD": "XAU/USD"}


def _check(payload: Any) -> Any:
    if isinstance(payload, dict) and payload.get("status") == "error":
        code = int(payload.get("code", 0) or 0)
        msg = payload.get("message", "unknown error")
        if code == 429:
            raise RateLimitError(f"Twelve Data: {msg}", retry_after=60)
        if code in (401, 403) or "plan" in msg.lower() or "api key" in msg.lower():
            raise AuthError(f"Twelve Data: {msg}")
        raise ProviderError(f"Twelve Data ({code}): {msg}")
    return payload


def parse_time_series(payload: dict) -> pd.DataFrame:
    _check(payload)
    values = payload.get("values") or []
    if not values:
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    df = pd.DataFrame(values)
    t = pd.to_datetime(df["datetime"], utc=True).dt.as_unit("s")
    out = pd.DataFrame({
        "time": t.astype("int64"),
        "open": pd.to_numeric(df["open"]), "high": pd.to_numeric(df["high"]),
        "low": pd.to_numeric(df["low"]), "close": pd.to_numeric(df["close"]),
        "volume": pd.to_numeric(df["volume"]) if "volume" in df else 0.0,
    })
    return out.sort_values("time").reset_index(drop=True)


def parse_ws_message(msg: dict, td_to_symbol: dict[str, str]) -> list[Tick]:
    ev = msg.get("event")
    if ev == "subscribe-status":
        fails = msg.get("fails") or []
        if msg.get("status") != "ok" or fails:
            raise AuthError(f"Twelve Data subscription failed for {fails or msg} (WebSocket needs the Pro plan for non-trial symbols)")
        return []
    if ev != "price":
        return []
    sym = td_to_symbol.get(msg.get("symbol", ""))
    if sym is None or msg.get("price") is None:
        return []
    return [Tick(sym, float(msg.get("timestamp") or time.time()), float(msg["price"]),
                 bid=float(msg["bid"]) if msg.get("bid") is not None else None,
                 ask=float(msg["ask"]) if msg.get("ask") is not None else None,
                 size=0.0)]


class TwelveDataProvider(MarketDataProvider):
    id = "twelvedata"

    def __init__(self, api_key: Optional[str] = None, fetch: Callable[[str, dict], Any] = http_get_json,
                 ws_connect: Optional[Callable[..., Any]] = None, sleep: Callable[[float], Any] = asyncio.sleep):
        self.api_key = api_key if api_key is not None else os.environ.get("TWELVEDATA_API_KEY", "")
        self.mode = os.environ.get("TWELVEDATA_STREAM", "polling").lower()
        self.poll_seconds = float(os.environ.get("TWELVEDATA_POLL_SECONDS", "15"))
        self._fetch = fetch
        self._ws_connect = ws_connect
        self._sleep = sleep
        self._limiter = TokenBucket(int(os.environ.get("TWELVEDATA_CREDITS_PER_MIN", "8")))

    def info(self) -> ProviderInfo:
        configured = bool(self.api_key)
        return ProviderInfo(
            id=self.id, name="Twelve Data", is_synthetic=False, realtime=True,
            transport="websocket" if self.mode == "websocket" else "polling",
            description=("Twelve Data spot XAU/USD. " + ("Streaming over WebSocket." if self.mode == "websocket"
                         else f"Latest 1-minute bar polled every {self.poll_seconds:g}s.")),
            native_timeframes=list(INTERVAL), symbols=list(SYMBOLS), configured=configured,
            setup_hint=None if configured else "Set TWELVEDATA_API_KEY.",
        )

    def symbols(self) -> list[SymbolInfo]:
        return [KNOWN_SYMBOLS[s] for s in SYMBOLS]

    def native_timeframes(self, symbol: str) -> list[str]:
        return list(INTERVAL)

    def _get(self, path: str, params: dict) -> Any:
        if not self.api_key:
            raise AuthError("TWELVEDATA_API_KEY is not set")
        self._limiter.acquire()
        return _check(self._fetch(build_url(f"{REST}{path}", {**params, "apikey": self.api_key}), {}))

    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        self.get_symbol_info(symbol)
        payload = self._get("/time_series", {"symbol": SYMBOLS[symbol], "interval": INTERVAL[timeframe],
                                             "outputsize": 5000, "timezone": "UTC", "format": "JSON"})
        return parse_time_series(payload)

    def get_realtime_data(self, symbol: str) -> Optional[Quote]:
        df = parse_time_series(self._get("/time_series", {"symbol": SYMBOLS[symbol], "interval": "1min", "outputsize": 1, "timezone": "UTC"}))
        if df.empty:
            return None
        r = df.iloc[-1]
        return Quote(symbol, min(time.time(), float(r["time"]) + 60), float(r["close"]))

    @property
    def supports_streaming(self) -> bool:
        return True

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        if self.mode == "websocket":
            await self._stream_ws(symbol, on_tick, on_event)
        else:
            await self._poll(symbol, on_tick, on_event)

    async def _poll(self, symbol: str, on_tick: OnTick, on_event: OnEvent) -> None:
        on_event("connected", {"transport": "polling", "interval": self.poll_seconds})
        while True:
            payload = await asyncio.to_thread(self._get, "/time_series", {
                "symbol": SYMBOLS[symbol], "interval": "1min", "outputsize": 2, "timezone": "UTC"})
            df = parse_time_series(payload)
            now = time.time()
            for r in df.itertuples(index=False):
                bar = {"time": int(r.time), "open": float(r.open), "high": float(r.high), "low": float(r.low),
                       "close": float(r.close), "volume": float(r.volume)}
                # "as of" time: a bar is at most current up to its end (or now)
                on_tick(Tick(symbol, min(now, bar["time"] + 60), bar["close"], bar=bar))
            await self._sleep(self.poll_seconds)

    async def _stream_ws(self, symbol: str, on_tick: OnTick, on_event: OnEvent) -> None:
        if not self.api_key:
            raise AuthError("TWELVEDATA_API_KEY is not set")
        from .pyth_pro import _default_ws_connect
        connect = self._ws_connect or _default_ws_connect
        async with connect(f"{WS_URL}?apikey={self.api_key}", {}) as ws:
            await ws.send(json.dumps({"action": "subscribe", "params": {"symbols": SYMBOLS[symbol]}}))
            on_event("connected", {"transport": "websocket"})

            async def heartbeat():
                while True:
                    await self._sleep(10)
                    await ws.send(json.dumps({"action": "heartbeat"}))

            hb = asyncio.create_task(heartbeat())
            try:
                async for raw in ws:
                    for tick in parse_ws_message(json.loads(raw), {v: k for k, v in SYMBOLS.items()}):
                        on_tick(tick)
            finally:
                hb.cancel()
        raise ProviderError("Twelve Data WebSocket closed by server")
