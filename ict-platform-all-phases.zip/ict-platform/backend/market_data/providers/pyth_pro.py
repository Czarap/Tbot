"""Pyth Pro (Pyth Network) — real-time spot XAUUSD.

Since the Pyth Core upgrade (Aug 2026) Pyth requires an API key (Starter / Pro
plan, or a trial key from Pyth Terminal). Set ``PYTH_API_KEY``.

* History : ``GET https://pyth.dourolabs.app/v1/{channel}/history`` (TradingView
            format: s, t, o, h, l, c, v) with ``Authorization: Bearer <key>``.
* Live    : WebSocket ``wss://pyth-lazer-{0,1,2}.dourolabs.app/v1/stream``,
            JSON ``subscribe`` message, ``streamUpdated`` events.
            Price = int(price) * 10 ** exponent; timestamps in microseconds.

Spot gold is Pyth feed 346 ``Metal.XAU/USD`` (override with PYTH_XAU_FEED_ID /
PYTH_XAU_SYMBOL). Pyth does not offer a continuous GC contract; month-specific
gold futures feeds can be mapped with PYTH_GC_FEED_ID + PYTH_GC_SYMBOL (they
must be re-pointed at each roll).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, Callable, Optional

import pandas as pd

from ..base import (KNOWN_SYMBOLS, AuthError, MarketDataProvider, OnEvent, OnTick, ProviderError, ProviderInfo,
                    SymbolInfo, Tick)
from ..http import TokenBucket, build_url, http_get_json

HISTORY_BASE = "https://pyth.dourolabs.app/v1"
WS_URLS = [f"wss://pyth-lazer-{i}.dourolabs.app/v1/stream" for i in range(3)]
RESOLUTION = {"1m": ("1", 60), "5m": ("5", 300), "15m": ("15", 900), "30m": ("30", 1800), "1h": ("60", 3600)}
HISTORY_BARS = {"1m": 3000, "5m": 3000, "15m": 3000, "30m": 3000, "1h": 5000}
CHUNK_BARS = 1500


def parse_history(payload: dict) -> pd.DataFrame:
    status = payload.get("s")
    if status == "no_data" or not payload.get("t"):
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    if status != "ok":
        raise ProviderError(f"Pyth history error: {payload.get('errmsg') or payload}")
    n = len(payload["t"])
    return pd.DataFrame({
        "time": [int(x) for x in payload["t"]],
        "open": payload["o"], "high": payload["h"], "low": payload["l"], "close": payload["c"],
        "volume": payload.get("v") or [0.0] * n,
    })


def parse_stream_message(msg: dict, feed_to_symbol: dict[int, str], exponents: dict[int, int]) -> list[Tick]:
    """Turn one Pyth Pro WebSocket message into normalised ticks."""
    mtype = msg.get("type")
    if mtype in ("subscriptionError", "error"):
        text = msg.get("error") or msg.get("message") or json.dumps(msg)[:200]
        if any(w in str(text).lower() for w in ("auth", "token", "entitle", "permission", "forbidden")):
            raise AuthError(f"Pyth: {text}")
        raise ProviderError(f"Pyth: {text}")
    if mtype != "streamUpdated":
        return []
    parsed = msg.get("parsed") or {}
    msg_ts = int(parsed.get("timestampUs", 0)) / 1e6
    out: list[Tick] = []
    for f in parsed.get("priceFeeds", []):
        fid = int(f.get("priceFeedId"))
        sym = feed_to_symbol.get(fid)
        if sym is None or f.get("price") in (None, ""):
            continue  # market closed / no price for this update
        if "exponent" in f and f["exponent"] is not None:
            exponents[fid] = int(f["exponent"])
        if fid not in exponents:
            continue
        exp = exponents[fid]

        def scale(v: Any) -> Optional[float]:
            if v in (None, ""):
                return None
            # divide by an exact power of ten to avoid 4000.0000000000005-style artefacts
            return round(int(v) / 10 ** -exp, 10) if exp < 0 else float(int(v) * 10 ** exp)

        ts = int(f.get("feedUpdateTimestamp") or 0) / 1e6 or msg_ts
        out.append(Tick(sym, ts, scale(f["price"]), bid=scale(f.get("bestBidPrice")), ask=scale(f.get("bestAskPrice"))))
    return out


class PythProProvider(MarketDataProvider):
    id = "pyth"

    def __init__(self, api_key: Optional[str] = None, fetch: Callable[[str, dict], Any] = http_get_json,
                 ws_connect: Optional[Callable[..., Any]] = None):
        self.api_key = api_key if api_key is not None else os.environ.get("PYTH_API_KEY", "")
        self.channel = os.environ.get("PYTH_CHANNEL", "fixed_rate@200ms")
        self.history_channel = os.environ.get("PYTH_HISTORY_CHANNEL", self.channel)
        self._fetch = fetch
        self._ws_connect = ws_connect
        self._limiter = TokenBucket(int(os.environ.get("PYTH_REQUESTS_PER_MIN", "120")))
        self.feeds: dict[str, tuple[int, str]] = {
            "XAUUSD": (int(os.environ.get("PYTH_XAU_FEED_ID", "346")), os.environ.get("PYTH_XAU_SYMBOL", "Metal.XAU/USD")),
        }
        if os.environ.get("PYTH_GC_FEED_ID") and os.environ.get("PYTH_GC_SYMBOL"):
            self.feeds["GC"] = (int(os.environ["PYTH_GC_FEED_ID"]), os.environ["PYTH_GC_SYMBOL"])

    # ---------------------------------------------------------------- metadata
    def info(self) -> ProviderInfo:
        configured = bool(self.api_key)
        return ProviderInfo(
            id=self.id, name="Pyth Pro", is_synthetic=False, realtime=True, transport="websocket",
            description="Pyth Network aggregated institutional prices (spot XAU/USD), streamed over WebSocket.",
            native_timeframes=list(RESOLUTION), symbols=list(self.feeds), configured=configured,
            setup_hint=None if configured else "Set PYTH_API_KEY (Pyth Terminal trial key or Starter/Pro plan).",
            warning=None if "GC" not in self.feeds else "GC via Pyth uses a single futures month; update PYTH_GC_* at each roll.",
        )

    def symbols(self) -> list[SymbolInfo]:
        return [KNOWN_SYMBOLS[s] for s in self.feeds]

    def native_timeframes(self, symbol: str) -> list[str]:
        return list(RESOLUTION)

    def _headers(self) -> dict:
        if not self.api_key:
            raise AuthError("PYTH_API_KEY is not set")
        return {"Authorization": f"Bearer {self.api_key}"}

    # -------------------------------------------------------------- historical
    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        self.get_symbol_info(symbol)
        res, secs = RESOLUTION[timeframe]
        _, pyth_symbol = self.feeds[symbol]
        end = int(time.time()) + secs
        start = end - HISTORY_BARS[timeframe] * secs * 7 // 5  # allow for weekends / closures
        frames = []
        t = start
        while t < end:
            t_to = min(end, t + CHUNK_BARS * secs)
            self._limiter.acquire()
            url = build_url(f"{HISTORY_BASE}/{self.history_channel}/history",
                            {"symbol": pyth_symbol, "resolution": res, "from": t, "to": t_to})
            frames.append(parse_history(self._fetch(url, self._headers())))
            t = t_to
        frames = [f for f in frames if len(f)]
        if not frames:
            return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
        return pd.concat(frames, ignore_index=True)

    # ---------------------------------------------------------------- realtime
    @property
    def supports_streaming(self) -> bool:
        return True

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        fid, _ = self.feeds[symbol]
        headers = self._headers()
        url = WS_URLS[attempt % len(WS_URLS)]
        connect = self._ws_connect or _default_ws_connect
        exponents: dict[int, int] = {}
        async with connect(url, headers) as ws:
            await ws.send(json.dumps({
                "type": "subscribe", "subscriptionId": 1, "priceFeedIds": [fid],
                "properties": ["price", "bestBidPrice", "bestAskPrice", "exponent", "feedUpdateTimestamp"],
                "formats": [], "deliveryFormat": "json", "channel": self.channel, "parsed": True, "jsonBinaryEncoding": "hex",
            }))
            on_event("connected", {"url": url})
            async for raw in ws:
                msg = json.loads(raw)
                for tick in parse_stream_message(msg, {fid: symbol}, exponents):
                    on_tick(tick)
        raise ProviderError("Pyth WebSocket closed by server")


def _default_ws_connect(url: str, headers: dict):
    try:
        import websockets
    except ImportError as exc:  # pragma: no cover
        raise ProviderError("The 'websockets' package is required for streaming: pip install websockets") from exc
    try:
        return websockets.connect(url, additional_headers=headers, ping_interval=20, ping_timeout=20, max_size=2**22)
    except TypeError:  # websockets < 14
        return websockets.connect(url, extra_headers=headers, ping_interval=20, ping_timeout=20, max_size=2**22)


_ = asyncio  # (kept for type-checkers; streaming is async)
