"""biquote.io — free real-time XAUUSD (no API key).

biquote re-publishes a MetaTrader 5 broker feed ("MetaTrader 5 (Broker 1)").
Prices are the broker's indicative CFD bid/ask (candles are built from the
MID price), not exchange data, and there is no real volume (tick volume only).
Gold futures (GC) are not offered, so this provider serves XAUUSD only.

* History : ``GET /api/{symbol}/ohlc?interval=1m|5m|15m|30m|1h|4h|1d&limit<=1000``
            Rolling retention: M1 ~300 bars, M5 288, M15/M30 192, H1 168, H4 180, D1 500.
            Live-closed candles are persisted locally (see live_store.py), so the
            usable history grows while the app runs.
* Live    : SignalR hub ``/hubs/tick`` (JSON protocol over WebSocket):
            negotiate -> handshake -> invoke ``Subscribe(["XAUUSD"])`` ->
            server pushes ``ReceiveTick``. Ticks are stamped in whole seconds.
* Fallback: ``BIQUOTE_STREAM=polling`` polls ``GET /api/{symbol}`` every
            ``BIQUOTE_POLL_SECONDS`` (default 1 s; the public limit is 15,000 req/min/IP).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, Callable, Optional

import pandas as pd

from ..base import (KNOWN_SYMBOLS, MarketDataProvider, OnEvent, OnTick, ProviderError, ProviderInfo, Quote, SymbolInfo,
                    Tick)
from ..http import TokenBucket, build_url, http_get_json, http_post_json

RS = "\x1e"  # SignalR record separator
INTERVALS = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


def _ts(value: Any) -> Optional[float]:
    """ISO-8601 string or epoch (s / ms) -> UTC epoch seconds."""
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        v = float(value)
        return v / 1000.0 if v > 1e11 else v
    t = pd.Timestamp(str(value))
    t = t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")
    return t.value / 1e9


def parse_ohlc(payload: dict) -> pd.DataFrame:
    bars = (payload or {}).get("bars") or []
    if not bars:
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    rows = []
    for b in bars:
        t = _ts(b.get("openTime"))
        if t is None:
            continue
        vol = b.get("volume") or 0
        rows.append((int(t), float(b["open"]), float(b["high"]), float(b["low"]), float(b["close"]),
                     float(vol if vol else b.get("tickVolume") or 0)))
    df = pd.DataFrame(rows, columns=["time", "open", "high", "low", "close", "volume"])
    return df.sort_values("time").reset_index(drop=True)  # API returns newest first


def parse_tick(obj: dict, to_internal: dict[str, str]) -> Optional[Tick]:
    sym = to_internal.get(str(obj.get("symbol", "")).replace("/", "").upper())
    if sym is None:
        return None
    bid, ask = obj.get("bid"), obj.get("ask")
    mid = obj.get("mid") if obj.get("mid") is not None else obj.get("price")
    if mid is None and bid is not None and ask is not None:
        mid = (float(bid) + float(ask)) / 2
    if mid is None or float(mid) <= 0:
        return None
    ts = _ts(obj.get("timestamp")) or _ts(obj.get("lastQuoteAt")) or time.time()
    return Tick(sym, ts, float(mid), bid=float(bid) if bid is not None else None, ask=float(ask) if ask is not None else None)


def split_frames(raw: Any) -> list[dict]:
    """SignalR JSON protocol: records terminated by 0x1E."""
    text = raw.decode() if isinstance(raw, (bytes, bytearray)) else str(raw)
    out = []
    for part in text.split(RS):
        part = part.strip()
        if part:
            out.append(json.loads(part))
    return out


class BiquoteProvider(MarketDataProvider):
    id = "biquote"

    def __init__(self, base_url: Optional[str] = None, fetch: Callable[[str, dict], Any] = http_get_json,
                 post: Callable[[str, dict], Any] = http_post_json, ws_connect: Optional[Callable[..., Any]] = None,
                 sleep: Callable[[float], Any] = asyncio.sleep):
        self.base = (base_url or os.environ.get("BIQUOTE_BASE_URL", "https://biquote.io")).rstrip("/")
        self.mode = os.environ.get("BIQUOTE_STREAM", "signalr").lower()
        self.poll_seconds = float(os.environ.get("BIQUOTE_POLL_SECONDS", "1"))
        # internal symbol -> broker symbol. More instruments: BIQUOTE_SYMBOLS=XAUUSD,EURUSD,...
        # and BIQUOTE_SYMBOL_MAP=NAS100=USTEC,US30=US30 where the broker uses other names
        # (look them up with GET https://biquote.io/api/symbols/search?q=nasdaq).
        wanted = [x.strip().upper() for x in os.environ.get("BIQUOTE_SYMBOLS", "XAUUSD,EURUSD,GBPUSD,USDJPY,BTCUSD").split(",")]
        mapping = dict(kv.split("=", 1) for kv in os.environ.get("BIQUOTE_SYMBOL_MAP", "").split(",") if "=" in kv)
        self.remote = {s: mapping.get(s, s) for s in wanted if s in KNOWN_SYMBOLS and s != "GC"}
        self.remote.setdefault("XAUUSD", os.environ.get("BIQUOTE_XAU_SYMBOL", "XAUUSD"))
        self._fetch, self._post, self._ws_connect, self._sleep = fetch, post, ws_connect, sleep
        self._limiter = TokenBucket(int(os.environ.get("BIQUOTE_REQUESTS_PER_MIN", "600")))

    # ---------------------------------------------------------------- metadata
    def info(self) -> ProviderInfo:
        polling = self.mode == "polling"
        return ProviderInfo(
            id=self.id, name="biquote", is_synthetic=False, realtime=True,
            transport="polling" if polling else "websocket",
            description="Free real-time XAUUSD (plus FX / crypto) from a MetaTrader 5 broker feed via biquote.io "
                        + ("(REST polling)." if polling else "(SignalR WebSocket)."),
            native_timeframes=INTERVALS, symbols=list(self.remote), configured=True,
            warning="biquote: indicative broker CFD prices (mid), not exchange data; no real volume. "
                    "Short history window (1m ≈ 5 h, 1h ≈ 1 week) — candles received live are saved locally so history grows.",
        )

    def symbols(self) -> list[SymbolInfo]:
        return [KNOWN_SYMBOLS[s] for s in self.remote]

    def native_timeframes(self, symbol: str) -> list[str]:
        return INTERVALS

    def _get(self, path: str, params: Optional[dict] = None) -> Any:
        self._limiter.acquire()
        url = build_url(f"{self.base}{path}", params) if params else f"{self.base}{path}"
        return self._fetch(url, {"Accept": "application/json"})

    # -------------------------------------------------------------- historical
    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        self.get_symbol_info(symbol)
        return parse_ohlc(self._get(f"/api/{self.remote[symbol]}/ohlc", {"interval": timeframe, "limit": 1000}))

    def get_realtime_data(self, symbol: str) -> Optional[Quote]:
        tick = parse_tick(self._get(f"/api/{self.remote[symbol]}"), {self.remote[symbol]: symbol})
        return Quote(symbol, tick.ts, tick.price, tick.bid, tick.ask) if tick else None

    # ---------------------------------------------------------------- realtime
    @property
    def supports_streaming(self) -> bool:
        return True

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        if self.mode == "polling":
            await self._poll(symbol, on_tick, on_event)
        else:
            await self._signalr(symbol, on_tick, on_event)

    async def _poll(self, symbol: str, on_tick: OnTick, on_event: OnEvent) -> None:
        mapping = {self.remote[symbol]: symbol}
        on_event("connected", {"transport": "polling", "interval": self.poll_seconds})
        while True:
            payload = await asyncio.to_thread(self._get, f"/api/{self.remote[symbol]}", {"allowStale": "true"})
            tick = parse_tick(payload, mapping)
            if tick is not None and payload.get("marketState", "open") != "closed":
                on_tick(tick)
            await self._sleep(self.poll_seconds)

    async def _signalr(self, symbol: str, on_tick: OnTick, on_event: OnEvent) -> None:
        from .pyth_pro import _default_ws_connect

        mapping = {self.remote[symbol]: symbol}
        hub = f"{self.base}/hubs/tick"
        headers: dict = {}
        try:
            neg = await asyncio.to_thread(self._post, f"{hub}/negotiate?negotiateVersion=1", {})
        except ProviderError:
            neg = {}  # some servers allow skipping negotiation for WebSockets
        if isinstance(neg, dict) and neg.get("url"):  # redirect (e.g. Azure SignalR service)
            hub = neg["url"].split("?")[0]
            if neg.get("accessToken"):
                headers["Authorization"] = f"Bearer {neg['accessToken']}"
            neg = await asyncio.to_thread(self._post, f"{hub}/negotiate?negotiateVersion=1", headers)
        token = (neg or {}).get("connectionToken") or (neg or {}).get("connectionId")
        ws_url = hub.replace("https://", "wss://").replace("http://", "ws://") + (f"?id={token}" if token else "")
        connect = self._ws_connect or _default_ws_connect

        async with connect(ws_url, headers) as ws:
            await ws.send(json.dumps({"protocol": "json", "version": 1}) + RS)
            handshake = split_frames(await ws.recv())
            if handshake and handshake[0].get("error"):
                raise ProviderError(f"biquote handshake failed: {handshake[0]['error']}")
            await ws.send(json.dumps({"type": 1, "target": "Subscribe", "arguments": [[self.remote[symbol]]]}) + RS)
            on_event("connected", {"transport": "signalr"})

            async def keepalive():
                while True:
                    await self._sleep(15)
                    await ws.send(json.dumps({"type": 6}) + RS)

            ka = asyncio.create_task(keepalive())
            try:
                for f in handshake[1:]:
                    self._dispatch(f, mapping, on_tick)
                async for raw in ws:
                    for f in split_frames(raw):
                        self._dispatch(f, mapping, on_tick)
            finally:
                ka.cancel()
        raise ProviderError("biquote hub connection closed")

    @staticmethod
    def _dispatch(frame: dict, mapping: dict[str, str], on_tick: OnTick) -> None:
        kind = frame.get("type")
        if kind == 1 and str(frame.get("target", "")).lower() == "receivetick":
            for arg in frame.get("arguments") or []:
                for obj in arg if isinstance(arg, list) else [arg]:
                    tick = parse_tick(obj, mapping)
                    if tick is not None:
                        on_tick(tick)
        elif kind == 7:
            raise ProviderError(f"biquote hub closed the connection: {frame.get('error') or 'no reason given'}")
        elif kind == 3 and frame.get("error"):
            raise ProviderError(f"biquote Subscribe failed: {frame['error']}")
