"""Vendor adapters. Each one normalises its feed into Tick / candle frames."""
