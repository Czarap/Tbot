"""Timeframe definitions shared by the whole backend.

All timestamps in this project are stored as **UTC epoch seconds of the candle
OPEN time** (int). Conversions to exchange / display time zones happen only at
the edges (resampling, session logic, UI formatting).
"""
from __future__ import annotations

TIMEFRAMES: dict[str, int] = {
    "1m": 60,
    "5m": 300,
    "15m": 900,
    "30m": 1800,
    "1h": 3600,
    "4h": 14400,
    "1d": 86400,
}

TIMEFRAME_LABELS: dict[str, str] = {
    "1m": "1 minute",
    "5m": "5 minutes",
    "15m": "15 minutes",
    "30m": "30 minutes",
    "1h": "1 hour",
    "4h": "4 hours",
    "1d": "1 day",
}

# Default higher timeframe used for "HTF bias" when analysing a given chart TF.
DEFAULT_HTF: dict[str, str | None] = {
    "1m": "15m",
    "5m": "1h",
    "15m": "4h",
    "30m": "4h",
    "1h": "1d",
    "4h": "1d",
    "1d": None,
}


def tf_seconds(tf: str) -> int:
    try:
        return TIMEFRAMES[tf]
    except KeyError as exc:  # pragma: no cover - guarded by API validation
        raise ValueError(f"Unsupported timeframe '{tf}'. Use one of {list(TIMEFRAMES)}") from exc


def is_intraday(tf: str) -> bool:
    return TIMEFRAMES[tf] < 86400
