"""Minimal JSON-over-HTTPS client (stdlib only) with error mapping and a
token-bucket rate limiter shared by REST calls of one provider."""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable, Optional

from .base import AuthError, ProviderError, RateLimitError

Fetcher = Callable[[str, dict], Any]  # (url, headers) -> parsed JSON


class TokenBucket:
    """Blocking limiter: ``capacity`` requests per ``period`` seconds."""

    def __init__(self, capacity: int, period: float = 60.0):
        self.capacity = max(1, capacity)
        self.period = period
        self._tokens = float(self.capacity)
        self._last = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, timeout: float = 90.0) -> None:
        deadline = time.monotonic() + timeout
        while True:
            with self._lock:
                now = time.monotonic()
                self._tokens = min(self.capacity, self._tokens + (now - self._last) * self.capacity / self.period)
                self._last = now
                if self._tokens >= 1:
                    self._tokens -= 1
                    return
                wait = (1 - self._tokens) * self.period / self.capacity
            if time.monotonic() + wait > deadline:
                raise RateLimitError("Local rate limit reached; request skipped", retry_after=wait)
            time.sleep(min(wait, 1.0))


def http_post_json(url: str, headers: Optional[dict] = None, timeout: float = 20.0) -> Any:
    return http_get_json(url, headers, timeout, method="POST")


def http_get_json(url: str, headers: Optional[dict] = None, timeout: float = 20.0, method: str = "GET") -> Any:
    req = urllib.request.Request(url, method=method, data=b"" if method == "POST" else None,
                                 headers={"User-Agent": "ICT-Lab/0.2 (analysis only)", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 - provider URLs are fixed https
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode()[:300]
        except Exception:  # pragma: no cover
            pass
        if exc.code in (401, 403):
            raise AuthError(f"HTTP {exc.code}: not authorised ({body or exc.reason})") from exc
        if exc.code == 429:
            retry = float(exc.headers.get("Retry-After", 60) or 60)
            raise RateLimitError(f"HTTP 429: rate limited ({body or exc.reason})", retry_after=retry) from exc
        raise ProviderError(f"HTTP {exc.code}: {body or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise ProviderError(f"Network error: {exc.reason}") from exc


def build_url(base: str, params: dict) -> str:
    return f"{base}?{urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})}"
