"""Exchange-time helpers (vectorised, DST-correct).

Gold (spot / CME) trades Sunday 18:00 -> Friday 17:00 New York time with a
daily maintenance break 17:00 -> 18:00. The *trading day* rolls over at 17:00
New York time, which is what most FX/metal platforms use for daily candles and
for "previous day high/low".
"""
from __future__ import annotations

import numpy as np
import pandas as pd

EXCHANGE_TZ = "America/New_York"
ROLLOVER_HOUR = 17  # 17:00 New York


def to_local_naive(times_utc: np.ndarray | pd.Series, tz: str = EXCHANGE_TZ) -> pd.DatetimeIndex:
    """UTC epoch seconds -> naive wall-clock DatetimeIndex in ``tz``."""
    idx = pd.to_datetime(np.asarray(times_utc, dtype="int64"), unit="s", utc=True)
    return idx.tz_convert(tz).tz_localize(None)


def local_naive_to_utc_seconds(naive: pd.DatetimeIndex, tz: str = EXCHANGE_TZ) -> np.ndarray:
    """Naive wall-clock times in ``tz`` -> UTC epoch seconds.

    Ambiguous wall times (DST fall-back hour) resolve to the first occurrence,
    non-existent ones (spring-forward gap) shift forward.
    """
    loc = naive.tz_localize(tz, ambiguous=np.ones(len(naive), dtype=bool), nonexistent="shift_forward")
    return loc.tz_convert("UTC").as_unit("s").asi8.astype("int64")


def trading_date(times_utc: np.ndarray | pd.Series, tz: str = EXCHANGE_TZ, rollover_hour: int = ROLLOVER_HOUR) -> pd.DatetimeIndex:
    """Trading date (normalised naive date) for each timestamp.

    A candle at 17:00 New York on Monday belongs to Tuesday's trading day.
    """
    local = to_local_naive(times_utc, tz)
    return (local + pd.Timedelta(hours=24 - rollover_hour)).normalize()


def is_market_closed(times_utc: np.ndarray | pd.Series, tz: str = EXCHANGE_TZ, asset_class: str = "metal") -> np.ndarray:
    """True where the market is normally closed.

    metal / index : weekend + daily 17:00-18:00 New York break (CME-style hours)
    forex         : weekend only (Friday 17:00 -> Sunday 17:00 New York)
    crypto        : never closed
    """
    if asset_class == "crypto":
        return np.zeros(len(np.asarray(times_utc)), dtype=bool)
    local = to_local_naive(times_utc, tz)
    dow = local.dayofweek.values  # Mon=0 .. Sun=6
    hour = local.hour.values
    if asset_class == "forex":
        return (dow == 5) | ((dow == 4) & (hour >= 17)) | ((dow == 6) & (hour < 17))
    daily_break = hour == 17
    weekend = (dow == 5) | ((dow == 4) & (hour >= 17)) | ((dow == 6) & (hour < 18))
    return daily_break | weekend
