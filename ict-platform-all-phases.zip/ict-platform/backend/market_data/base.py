"""Market-data abstraction.

    MarketDataProvider
      ├── get_historical_data()   historical OHLC candles (REST)
      ├── get_realtime_data()     latest quote snapshot (REST)
      ├── subscribe_realtime()    streaming ticks/bars (WebSocket or polling)
      └── get_symbol_info()       instrument metadata

Every provider returns **normalised** data, so the chart, the live hub and the
ICT engine never see vendor-specific formats:

* candles: DataFrame with columns ``time`` (int64, UTC epoch seconds of the
  candle OPEN), ``open``, ``high``, ``low``, ``close``, ``volume``
* ticks:   :class:`Tick` (UTC epoch seconds as float, price, optional bid/ask/size)

Adding a vendor = one subclass + one line in ``registry.py``.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from typing import Callable, Optional

import pandas as pd

CANDLE_COLUMNS = ["time", "open", "high", "low", "close", "volume"]


@dataclass(frozen=True)
class SymbolInfo:
    symbol: str
    description: str
    tick_size: float
    price_precision: int
    quote_currency: str = "USD"
    contract_size: float = 100.0
    exchange_timezone: str = "America/New_York"
    asset_class: str = "metal"
    market: str = ""  # human label, e.g. "Spot Gold" / "Gold Futures"
    instrument_type: str = "spot"  # spot | future

    def to_dict(self) -> dict:
        return asdict(self)


# XAUUSD and GC are deliberately DIFFERENT instruments: spot gold vs COMEX gold
# futures. Futures trade at a premium (carry) and roll between contracts.
KNOWN_SYMBOLS: dict[str, SymbolInfo] = {
    "XAUUSD": SymbolInfo("XAUUSD", "Gold / US Dollar (spot)", 0.01, 2, contract_size=100.0, market="Spot Gold"),
    "GC": SymbolInfo("GC", "COMEX Gold Futures (front month, continuous)", 0.1, 1, contract_size=100.0,
                     exchange_timezone="America/New_York", market="Gold Futures", instrument_type="future"),
    "EURUSD": SymbolInfo("EURUSD", "Euro / US Dollar", 0.00001, 5, contract_size=100_000, asset_class="forex", market="FX"),
    "GBPUSD": SymbolInfo("GBPUSD", "British Pound / US Dollar", 0.00001, 5, contract_size=100_000, asset_class="forex", market="FX"),
    "USDJPY": SymbolInfo("USDJPY", "US Dollar / Japanese Yen", 0.001, 3, quote_currency="JPY", contract_size=100_000, asset_class="forex", market="FX"),
    "BTCUSD": SymbolInfo("BTCUSD", "Bitcoin / US Dollar", 0.01, 2, contract_size=1, asset_class="crypto", market="Crypto (24/7)"),
    "NAS100": SymbolInfo("NAS100", "Nasdaq 100 index", 0.1, 1, contract_size=1, asset_class="index", market="Index"),
    "US30": SymbolInfo("US30", "Dow Jones 30 index", 1.0, 1, contract_size=1, asset_class="index", market="Index"),
}


@dataclass
class Tick:
    """One normalised price update."""

    symbol: str
    ts: float  # UTC epoch seconds (source timestamp, NOT receive time)
    price: float
    bid: Optional[float] = None
    ask: Optional[float] = None
    size: float = 0.0
    # Some feeds deliver bars instead of trades (e.g. polled 1-minute bars).
    bar: Optional[dict] = None  # {"time","open","high","low","close","volume"}

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Quote:
    symbol: str
    ts: float
    price: float
    bid: Optional[float] = None
    ask: Optional[float] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ProviderInfo:
    id: str
    name: str
    description: str
    is_synthetic: bool
    native_timeframes: list[str] = field(default_factory=list)
    warning: Optional[str] = None
    symbols: list[str] = field(default_factory=list)
    realtime: bool = False  # can deliver real-time (not delayed) updates for its symbols
    transport: str = "none"  # websocket | polling | simulated | none
    configured: bool = True  # has the credentials / packages it needs
    setup_hint: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


class ProviderError(Exception):
    """Generic upstream problem (bad response, network)."""


class AuthError(ProviderError):
    """Missing / invalid API key or plan not entitled to the data."""


class RateLimitError(ProviderError):
    def __init__(self, message: str, retry_after: float = 60.0):
        super().__init__(message)
        self.retry_after = retry_after


OnTick = Callable[[Tick], None]
OnEvent = Callable[[str, dict], None]  # ("connected"|"disconnected"|"info", details)


class MarketDataProvider(ABC):
    id: str = "base"

    # ---------------------------------------------------------------- metadata
    @abstractmethod
    def info(self) -> ProviderInfo: ...

    @abstractmethod
    def symbols(self) -> list[SymbolInfo]: ...

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        for s in self.symbols():
            if s.symbol == symbol:
                return s
        raise KeyError(f"Symbol '{symbol}' is not supported by data provider '{self.id}'")

    symbol_info = get_symbol_info  # backwards-compatible alias

    @abstractmethod
    def native_timeframes(self, symbol: str) -> list[str]:
        """Timeframes the source delivers directly; others are resampled."""

    # -------------------------------------------------------------- historical
    @abstractmethod
    def get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        """Candles for a native timeframe (may include the still-forming bar)."""

    def get_history(self, symbol: str, timeframe: str) -> pd.DataFrame:  # alias
        return self.get_historical_data(symbol, timeframe)

    # ---------------------------------------------------------------- realtime
    def get_realtime_data(self, symbol: str) -> Optional[Quote]:
        """Latest quote snapshot, if the provider offers one."""
        return None

    @property
    def supports_streaming(self) -> bool:
        return False

    async def subscribe_realtime(self, symbol: str, on_tick: OnTick, on_event: OnEvent, attempt: int = 0) -> None:
        """Stream updates until cancelled. Must raise on disconnect so the live
        hub can reconnect with back-off. Never places orders."""
        raise NotImplementedError(f"Provider '{self.id}' has no real-time feed")

    def is_realtime(self, symbol: str) -> bool:
        return self.info().realtime


def frame_from_rows(rows: list[tuple]) -> pd.DataFrame:
    return pd.DataFrame(rows, columns=CANDLE_COLUMNS)
