"""Economic calendar (news events) for chart markers and the news filter.

Sources, in order:
1. biquote.io ``GET /api/calendar`` (free, no key): UTC ISO times, ``importance``
   low|medium|high, ``currency``, ``name``, actual/forecast/previous.
2. ``data/calendar.csv`` (optional, for older history): columns
   ``time`` (ISO 8601 UTC), ``currency``, ``name``, ``importance`` [, forecast, previous, actual].

Gold reacts mostly to USD releases (CPI, NFP, FOMC, rate decisions, PPI, GDP,
Fed speeches), so the default filter is USD + high importance.
A coverage window is returned with every result: the news filter only judges
times inside it ("no data" is never treated as "no news").
"""
from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

import pandas as pd

from .http import build_url, http_get_json

log = logging.getLogger("ict.calendar")
LEVEL = {"low": 1, "medium": 2, "high": 3}


def _iso(t: int) -> str:
    return pd.Timestamp(int(t), unit="s", tz="UTC").strftime("%Y-%m-%dT%H:%M:%SZ")


def normalise_event(e: dict, source: str) -> Optional[dict]:
    raw_t = e.get("time") or e.get("timestamp") or e.get("date")
    if not raw_t:
        return None
    ts = pd.Timestamp(str(raw_t))
    ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    imp = str(e.get("importance", "low")).lower()
    return {
        "id": str(e.get("id") or f"{source}:{int(ts.timestamp())}:{e.get('name')}"),
        "time": int(ts.timestamp()),
        "name": str(e.get("name") or e.get("title") or e.get("event") or "Event"),
        "currency": str(e.get("currency") or "").upper(),
        "country": e.get("countryCode") or e.get("country"),
        "importance": imp if imp in LEVEL else "low",
        "actual": e.get("actual"), "forecast": e.get("forecast"), "previous": e.get("previous"),
        "exact_time": (e.get("timeMode", "exact") == "exact"),
        "source": source,
    }


class CalendarService:
    def __init__(self, base_url: Optional[str] = None, fetch: Callable[[str, dict], Any] = http_get_json,
                 csv_path: Optional[str] = None, enabled: bool = True, ttl: float = 600.0):
        self.base = (base_url or os.environ.get("BIQUOTE_BASE_URL", "https://biquote.io")).rstrip("/")
        self._fetch = fetch
        self.csv_path = Path(csv_path) if csv_path else None
        self.enabled = enabled
        self._ttl = ttl
        self._cache: dict[tuple, tuple[float, list, Optional[str]]] = {}
        self._lock = threading.Lock()

    @classmethod
    def from_env(cls) -> "CalendarService":
        data_dir = os.environ.get("ICT_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
        return cls(csv_path=os.path.join(os.path.abspath(data_dir), "calendar.csv"),
                   enabled=os.environ.get("ICT_CALENDAR", "biquote") != "off")

    def _remote(self, start: int, end: int) -> list[dict]:
        out: list[dict] = []
        cursor = start
        for _ in range(40):  # pagination guard
            url = build_url(f"{self.base}/api/calendar", {"from": _iso(cursor), "to": _iso(end), "limit": 500, "importance": "medium"})
            batch = self._fetch(url, {"Accept": "application/json"})
            if not isinstance(batch, list):
                batch = (batch or {}).get("events", [])
            evs = [x for x in (normalise_event(e, "biquote") for e in batch) if x]
            out.extend(evs)
            if len(batch) < 500 or not evs:
                break
            cursor = max(e["time"] for e in evs) + 1
        return out

    def _csv(self, start: int, end: int) -> list[dict]:
        if not self.csv_path or not self.csv_path.exists():
            return []
        df = pd.read_csv(self.csv_path)
        evs = [x for x in (normalise_event(r, "csv") for r in df.to_dict("records")) if x]
        return [e for e in evs if start <= e["time"] <= end]

    def events(self, start: int, end: int, currencies: Optional[list[str]] = None, min_importance: str = "high") -> dict:
        """Returns {"events": [...], "coverage": [start, end] | None, "sources": [...], "error": str | None}."""
        start, end = int(start), int(end)
        key = (start // 3600, end // 3600)
        now = time.time()
        with self._lock:
            hit = self._cache.get(key)
        if hit and now - hit[0] < self._ttl:
            evs, err = hit[1], hit[2]
        else:
            evs, err = [], None
            if self.enabled:
                try:
                    evs = self._remote(start, end)
                except Exception as exc:  # noqa: BLE001 - calendar problems must never break analysis
                    err = f"calendar unavailable: {exc}"
                    log.info(err)
            try:
                evs = evs + self._csv(start, end)
            except Exception as exc:  # noqa: BLE001
                err = (err or "") + f" | calendar.csv unreadable: {exc}"
            seen, uniq = set(), []
            for e in sorted(evs, key=lambda x: x["time"]):
                k = (e["time"], e["name"], e["currency"])
                if k not in seen:
                    seen.add(k)
                    uniq.append(e)
            evs = uniq
            with self._lock:
                self._cache[key] = (now, evs, err)
        if err is None and self.enabled:
            coverage: Optional[list] = [start, end]
        elif evs:  # remote failed: only the CSV's own span is covered
            coverage = [max(start, evs[0]["time"]), min(end, evs[-1]["time"])]
        else:
            coverage = None
        cur = {c.upper() for c in currencies} if currencies else None
        lvl = LEVEL.get(min_importance, 3)
        flt = [e for e in evs if LEVEL[e["importance"]] >= lvl and (cur is None or e["currency"] in cur)]
        return {"events": flt, "coverage": coverage,
                "sources": sorted({e["source"] for e in evs}), "error": err}


class NewsIndex:
    """Sorted event times + the window the calendar actually covers."""

    def __init__(self, events: list[dict], coverage: Optional[tuple[int, int]] = None):
        evs = sorted(events, key=lambda e: e["time"])
        self.times = [int(e["time"]) for e in evs]
        self.events = evs
        self.coverage = tuple(coverage) if coverage else None

    @classmethod
    def from_result(cls, res: dict) -> Optional["NewsIndex"]:
        return cls(res["events"], res["coverage"]) if res.get("coverage") else None

    def blocking(self, t: int, before_s: int, after_s: int) -> Optional[dict]:
        """First event E with E - before <= t <= E + after (t is inside E's no-trade window)."""
        import bisect

        i = bisect.bisect_left(self.times, t - after_s)
        if i < len(self.times) and self.times[i] <= t + before_s:
            return self.events[i]
        return None

    def covers(self, t: int) -> bool:
        return self.coverage is None or self.coverage[0] <= t <= self.coverage[1]
