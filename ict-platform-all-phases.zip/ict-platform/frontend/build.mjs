// Build script: esbuild (bundle) + Tailwind v4 compiler (CSS). No Vite needed.
//   node build.mjs                       -> dist/ (served by the FastAPI backend)
//   node build.mjs --watch               -> rebuild dist/ on every change
//   node build.mjs --snapshot file.json  -> dist-demo/index.html (single static file with embedded engine output)
import * as esbuild from 'esbuild';
import { compile } from 'tailwindcss';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const args = process.argv.slice(2);
const watch = args.includes('--watch');
const snapIdx = args.indexOf('--snapshot');
const snapshotFile = snapIdx >= 0 ? args[snapIdx + 1] : null;
const outDir = path.join(here, snapshotFile ? 'dist-demo' : 'dist');

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]));
}

async function buildCss() {
  const twDir = path.dirname(require.resolve('tailwindcss/package.json'));
  const input = fs.readFileSync(path.join(here, 'src/index.css'), 'utf8');
  const compiler = await compile(input, {
    base: path.join(here, 'src'),
    loadStylesheet: async (id, base) => {
      const file = id === 'tailwindcss' ? path.join(twDir, 'index.css') : path.resolve(base, id);
      return { content: fs.readFileSync(file, 'utf8'), base: path.dirname(file), path: file };
    },
  });
  const candidates = new Set();
  for (const f of walk(path.join(here, 'src')).filter((f) => /\.(tsx?|html)$/.test(f))) {
    for (const tok of fs.readFileSync(f, 'utf8').split(/[\s"'`{}()<>;,]+/)) if (tok) candidates.add(tok);
  }
  return compiler.build([...candidates]);
}

async function buildJs() {
  const res = await esbuild.build({
    entryPoints: [path.join(here, 'src/main.tsx')],
    bundle: true, minify: true, format: 'iife', target: ['es2020'], write: false, jsx: 'automatic',
    loader: { '.css': 'empty' }, define: { 'process.env.NODE_ENV': '"production"' }, legalComments: 'none',
  });
  return res.outputFiles[0].text;
}

const esc = (s) => s.replace(/<\/script/gi, '<\\/script');

async function buildAll() {
  const t0 = Date.now();
  const [css, js] = await Promise.all([buildCss(), buildJs()]);
  fs.mkdirSync(outDir, { recursive: true });
  const head = `<meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /><meta name="theme-color" content="#0b0e14" />`;
  if (snapshotFile) {
    const snap = fs.readFileSync(snapshotFile, 'utf8');
    const html = `<!DOCTYPE html><html lang="en"><head>${head}<title>ICT Lab — XAUUSD analysis demo</title><style>${css}</style></head>`
      + `<body><div id="root"></div><script>window.__ICT_SNAPSHOT__=${esc(snap)};</script><script>${esc(js)}</script></body></html>`;
    fs.writeFileSync(path.join(outDir, 'index.html'), html);
  } else {
    fs.mkdirSync(path.join(outDir, 'assets'), { recursive: true });
    fs.writeFileSync(path.join(outDir, 'assets/app.js'), js);
    fs.writeFileSync(path.join(outDir, 'assets/app.css'), css);
    fs.writeFileSync(path.join(outDir, 'index.html'), `<!DOCTYPE html><html lang="en"><head>${head}<title>ICT Lab — Analysis & Backtesting</title>`
      + `<link rel="stylesheet" href="/assets/app.css" /></head><body><div id="root"></div><script src="/assets/app.js"></script></body></html>`);
  }
  console.log(`built ${path.relative(here, outDir)} in ${Date.now() - t0} ms (js ${(js.length / 1024).toFixed(0)} KB, css ${(css.length / 1024).toFixed(0)} KB)`);
}

await buildAll();
if (watch) {
  console.log('watching src/ ...');
  let timer = null;
  fs.watch(path.join(here, 'src'), { recursive: true }, () => {
    clearTimeout(timer);
    timer = setTimeout(() => buildAll().catch((e) => console.error(e.message)), 150);
  });
}
