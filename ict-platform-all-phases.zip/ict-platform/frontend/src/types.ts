// Types mirroring the backend API (backend/ict_engine/types.py + services/analysis_service.py).

export type Direction = 'bullish' | 'bearish';
export type Timeframe = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d';
export type RuleMode = 'required' | 'scored' | 'off';

/** [time (UTC s, candle open), open, high, low, close, volume] */
export type CandleTuple = [number, number, number, number, number, number];

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Swing {
  id: string;
  kind: 'high' | 'low';
  index: number;
  time: number;
  price: number;
  confirmed_index: number;
  confirmed_time: number;
  label: string;
}

export interface StructureEvent {
  id: string;
  type: 'BOS' | 'CHoCH';
  direction: Direction;
  index: number;
  time: number;
  break_price: number;
  level: number;
  swing_id: string;
  swing_time: number;
  trend_before: Direction | null;
  trend_after: Direction;
  explanation: string[];
}

export type LiquidityKind =
  | 'swing_high' | 'swing_low' | 'equal_highs' | 'equal_lows'
  | 'pdh' | 'pdl' | 'pwh' | 'pwl' | 'session_high' | 'session_low';

export interface LiquidityLevel {
  id: string;
  kind: LiquidityKind;
  side: 'buy' | 'sell';
  label: string;
  price: number;
  start_time: number;
  created_index: number;
  created_time: number;
  active_from_index: number;
  status: 'active' | 'swept' | 'broken' | 'expired' | 'merged';
  end_index: number | null;
  end_time: number | null;
  sweep_id: string | null;
  meta: Record<string, unknown>;
}

export interface SweepEvent {
  id: string;
  side: 'buy' | 'sell';
  implication: Direction;
  level_id: string;
  level_kind: LiquidityKind;
  level_label: string;
  level_price: number;
  index: number;
  time: number;
  extreme: number;
  close: number;
  explanation: string[];
}

export interface FVG {
  id: string;
  direction: Direction;
  index: number;
  time: number;
  first_index: number;
  created_index: number;
  created_time: number;
  top: number;
  bottom: number;
  size: number;
  size_atr: number;
  ce: number;
  status: 'UNMITIGATED' | 'MITIGATED' | 'FILLED' | 'EXPIRED';
  mitigated_index: number | null;
  mitigated_time: number | null;
  filled_index: number | null;
  filled_time: number | null;
  max_fill_pct: number;
}

export interface Displacement {
  id: string;
  direction: Direction;
  index: number;
  time: number;
  start_index: number;
  start_time: number;
  kind: 'single' | 'multi';
  range: number;
  body: number;
  atr: number;
  range_atr: number;
  broke_structure: boolean;
  explanation: string[];
}

export interface OrderBlock {
  id: string;
  direction: Direction;
  index: number;
  time: number;
  created_index: number;
  created_time: number;
  top: number;
  bottom: number;
  structure_event_id: string;
  explanation: string[];
  status: 'UNMITIGATED' | 'MITIGATED' | 'INVALIDATED';
  mitigated_index: number | null;
  mitigated_time: number | null;
  invalidated_index: number | null;
  invalidated_time: number | null;
}

export interface DealingRange {
  high: number;
  low: number;
  equilibrium: number;
  high_time: number;
  low_time: number;
  source: string;
  as_of_time: number;
}

export interface SessionWindow {
  id: string;
  name: string;
  color: string;
  start_time: number;
  end_time: number | null;
  high: number;
  low: number;
  high_time: number;
  low_time: number;
  complete: boolean;
}

export interface SetupFactor {
  key: string;
  label: string;
  mode: RuleMode | 'pending';
  passed: boolean | null;
  points: number;
  detail: string;
}

export interface Setup {
  id: string;
  direction: Direction;
  label: string;
  symbol: string;
  timeframe: Timeframe;
  index: number;
  time: number;
  entry: number;
  stop_loss: number;
  take_profit: number;
  risk: number;
  reward: number;
  rr: number;
  score: number;
  max_score: number;
  factors: SetupFactor[];
  fvg_id: string;
  sweep_id: string | null;
  target_level_id: string | null;
  target_description: string;
  htf_timeframe: Timeframe | null;
  htf_bias: Direction | null;
  session: string | null;
  reasoning: string[];
}

export interface AnalysisSummary {
  trend: Direction | null;
  htf_timeframe: Timeframe | null;
  htf_bias: Direction | null;
  htf_candle_time: number | null;
  last_structure_event: StructureEvent | null;
  price: number | null;
  atr: number | null;
  zone: 'premium' | 'discount' | 'equilibrium' | null;
  nearest_buy_side: LiquidityLevel[];
  nearest_sell_side: LiquidityLevel[];
  active_fvgs: number;
  active_order_blocks: number;
  setup_rejections: Record<string, number>;
  candles_analysed: number;
}

export interface Analysis {
  swings: Swing[];
  structure_events: StructureEvent[];
  liquidity_levels: LiquidityLevel[];
  sweeps: SweepEvent[];
  fvgs: FVG[];
  displacements: Displacement[];
  order_blocks: OrderBlock[];
  sessions: SessionWindow[];
  dealing_range: DealingRange | null;
  setups: Setup[];
  summary: AnalysisSummary;
}

export interface ProviderInfo {
  id: string;
  name: string;
  description: string;
  is_synthetic: boolean;
  native_timeframes: Timeframe[];
  warning: string | null;
  symbols: string[];
  realtime: boolean;
  transport: 'websocket' | 'polling' | 'simulated' | 'none';
  configured: boolean;
  setup_hint: string | null;
}

export interface SymbolInfo {
  symbol: string;
  description: string;
  tick_size: number;
  price_precision: number;
  quote_currency: string;
  contract_size: number;
  exchange_timezone: string;
  asset_class: string;
  market: string;
  instrument_type: 'spot' | 'future';
}

export interface Instrument extends SymbolInfo {
  default_provider: string;
  providers: string[];
}

export interface DataQuality {
  rows_in: number;
  rows_out: number;
  invalid_rows_removed: number;
  duplicates_removed: number;
  was_unsorted: boolean;
  ohlc_fixed: number;
  gaps_total: number;
  gaps_unexpected: number;
  largest_gap_seconds: number;
  unexpected_gap_samples: { after_time: number; next_time: number; missing_seconds: number }[];
}

export interface SessionDef {
  name: string;
  start: string;
  end: string;
  enabled: boolean;
  color: string;
}

export interface ICTSettings {
  atr_period: number;
  structure: { swing_length: number; break_confirmation: 'close' | 'wick' };
  liquidity: {
    include_swing_levels: boolean;
    include_equal_levels: boolean;
    include_previous_day: boolean;
    include_previous_week: boolean;
    include_session_levels: boolean;
    equal_tolerance_atr: number;
    equal_lookback_swings: number;
    level_max_age_bars: number;
  };
  fvg: { min_size: number; min_size_atr: number; max_age_bars: number };
  displacement: {
    range_atr_mult: number;
    body_ratio: number;
    multi_candle_enabled: boolean;
    multi_candle_count: number;
    multi_candle_atr_mult: number;
    require_structure_break: boolean;
  };
  order_blocks: { enabled: boolean; zone: 'wick' | 'body'; lookback_bars: number; max_age_bars: number };
  dealing_range: { source: 'swings' | 'previous_day' };
  sessions: { timezone: string; sessions: SessionDef[] };
  mtf: { bias: Timeframe; structure: Timeframe; setup: Timeframe; entry: Timeframe };
  setups: {
    enabled: boolean;
    rules: Record<'htf_bias' | 'liquidity_sweep' | 'order_block' | 'structure_shift' | 'displacement' | 'premium_discount' | 'session' | 'liquidity_target' | 'news', RuleMode>;
    news_minutes_before: number;
    news_minutes_after: number;
    min_score: number;
    min_rr: number;
    sweep_lookback_bars: number;
    max_retrace_bars: number;
    confirmation: 'hold' | 'rejection';
    sl_buffer_atr: number;
    min_risk_atr: number;
    one_setup_per_sweep: boolean;
    setup_sessions: string[];
    htf_timeframe: Timeframe | null;
  };
}

export interface AnalysisResponse {
  symbol: string;
  timeframe: Timeframe;
  symbol_info: SymbolInfo;
  provider: ProviderInfo;
  source_timeframe: Timeframe;
  data_quality: DataQuality;
  settings: ICTSettings;
  candles: CandleTuple[];
  forming: Candle | null;
  analysis: Analysis;
  warmup_candles: number;
  compute_ms: number;
  generated_at: number;
  disclaimer: string;
}

export interface MetaResponse {
  default_provider: string;
  default_symbol?: string;
  providers: ProviderInfo[];
  instruments?: Instrument[];
  symbols: SymbolInfo[];
  live?: boolean;
  default_backtest?: BacktestConfig;
  default_grid?: OptimizeGrid;
  timeframes: { id: Timeframe; label: string; seconds: number }[];
  default_settings: ICTSettings;
  disclaimer: string;
  auto_trading: false;
}

export interface OverlayFlags {
  structure: boolean;
  swings: boolean;
  liquidity: boolean;
  swingLiquidity: boolean;
  sweeps: boolean;
  fvg: boolean;
  filledFvg: boolean;
  displacement: boolean;
  orderBlocks: boolean;
  premiumDiscount: boolean;
  previousLevels: boolean;
  sessions: boolean;
  setups: boolean;
  volume: boolean;
  highLow: boolean;
  news: boolean;
}

export interface EditedLevels {
  entry: number;
  stop_loss: number;
  take_profit: number;
}

export type DisplayTz = 'America/New_York' | 'UTC' | 'local';

export interface HoverInfo {
  x: number;
  y: number;
  title: string;
  lines: string[];
  color?: string;
}

export type FeedState = 'live' | 'delayed' | 'connecting' | 'reconnecting' | 'disconnected' | 'market_closed' | 'simulated' | 'historical';

export interface FeedStatus {
  state: FeedState;
  label: string;
  symbol: string;
  market: string;
  provider_id: string;
  provider_name: string;
  transport: string;
  connected: boolean;
  last_update: number | null;
  last_receive: number | null;
  lag_seconds: number | null;
  message: string | null;
  retry_in: number | null;
  server_time: number;
}

/** Normalised live candle (backend live/hub.py). */
export interface LiveCandle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  symbol: string;
  timeframe: Timeframe;
}

export interface LiveTick { price: number; bid: number | null; ask: number | null; ts: number }

export type LiveMessage =
  | { type: 'hello'; server_time: number; transport: string; analysis_only: true }
  | { type: 'status'; status: FeedStatus }
  | { type: 'snapshot'; payload: AnalysisResponse; status: FeedStatus }
  | { type: 'analysis'; payload: AnalysisResponse }
  | { type: 'candle'; candle: LiveCandle | null; tick: LiveTick | null }
  | { type: 'candle_closed'; candle: LiveCandle }
  | { type: 'error'; message: string }
  | { type: 'pong'; server_time: number };

// ---------------------------------------------------------------- phases 2-5
export interface MTFRow {
  role: 'bias' | 'structure' | 'setup' | 'entry';
  timeframe: Timeframe;
  trend: Direction | null;
  status: 'aligned' | 'conflict' | 'waiting' | 'setup' | 'error';
  zone?: string | null;
  last_event?: { type: string; direction: Direction; time: number } | null;
  recent_setup?: string | null;
  detail?: string;
}
export interface MTFResponse { symbol: string; bias: Direction | null; overall: 'aligned' | 'mixed' | 'waiting'; rows: MTFRow[] }

export interface CalendarEvent {
  id: string; time: number; name: string; currency: string; country: string | null;
  importance: 'low' | 'medium' | 'high'; actual: number | null; forecast: number | null; previous: number | null; exact_time: boolean;
}
export interface CalendarResponse { events: CalendarEvent[]; coverage: [number, number] | null; sources: string[]; error: string | null }

export interface RiskSettings { mode: 'fixed_percent' | 'fixed_dollar' | 'fixed_lots'; risk_percent: number; risk_dollar: number; lots: number; min_lots: number; max_lots: number; lot_step: number }
export interface PropRules { enabled: boolean; starting_balance: number; daily_loss_limit: number; max_drawdown: number; drawdown_mode: 'static' | 'trailing'; profit_target: number; max_trades_per_day: number | null; min_trading_days: number }
export interface BacktestConfig {
  symbol: string; timeframe: Timeframe; provider: string | null; start: string | null; end: string | null;
  starting_balance: number; risk: RiskSettings;
  costs: { spread: number; slippage: number; commission_per_lot: number };
  min_rr: number; max_trades_per_day: number; sessions: string[]; directions: Direction[];
  news: { enabled: boolean; minutes_before: number; minutes_after: number; min_importance: 'medium' | 'high'; currencies: string[] };
  entry: 'next_open'; same_bar: 'sl_first' | 'tp_first'; prop: PropRules; settings: ICTSettings; warmup_candles: number;
}

export interface Trade {
  id: string; setup_id: string; symbol: string; timeframe: Timeframe; direction: Direction; signal_time: number; entry_time: number;
  entry: number; stop_loss: number; take_profit: number; lots: number; risk_amount: number; planned_reward: number; rr: number;
  score: number; max_score: number; session: string | null; htf_bias: string | null; liquidity_event: string | null; fvg: string | null;
  order_block: string | null; displacement: string | null; setup_type: string; exit_time: number | null; exit_price: number | null;
  exit_reason: 'TP' | 'SL' | 'END' | null; result: 'WIN' | 'LOSS' | 'BREAKEVEN' | 'OPEN'; pnl: number; commission: number; r_multiple: number;
  duration_seconds: number; balance_after: number | null; notes: string;
}
export interface GroupStat { key: string; trades: number; wins: number; win_rate: number; net_r: number; net_pnl: number; avg_r: number }
export interface BacktestStats {
  total_trades: number; winning_trades: number; losing_trades: number; breakeven_trades: number; win_rate: number; average_r: number;
  net_r: number; net_profit: number; return_pct: number; profit_factor: number | null; profit_factor_note?: string; expectancy_r: number;
  expectancy_money: number; max_drawdown: number; max_drawdown_pct: number; max_consecutive_wins: number; max_consecutive_losses: number;
  largest_win: number; largest_loss: number; average_trade_duration_seconds: number; total_trading_days: number; commission_paid: number;
}
export interface PropResult {
  status: 'ACTIVE' | 'PASSED' | 'BREACHED'; reason: string | null; breach_time: number | null; passed_time: number | null;
  starting_balance: number; current_balance: number; profit: number; profit_target: number; target_progress_pct: number;
  max_drawdown_reached: number; max_drawdown_limit: number; worst_daily_loss: number; daily_loss_limit: number; drawdown_floor: number;
  trading_days: number; daily: { day: string; pnl: number; trades: number }[]; note: string;
}
export interface BacktestResult {
  run_id?: string; config: BacktestConfig; symbol_info: SymbolInfo; provider: ProviderInfo;
  period: { start: number; end: number; candles: number; warmup_candles: number }; candles: CandleTuple[]; trades: Trade[];
  equity: { time: number; balance: number }[]; drawdown: { time: number; drawdown: number; drawdown_pct: number }[];
  skipped: Record<string, number>; setups_found: number; starting_balance: number; final_balance: number; stats: BacktestStats;
  monthly: GroupStat[]; by_session: GroupStat[]; by_setup_type: GroupStat[]; by_direction: GroupStat[]; by_score: GroupStat[];
  prop: PropResult | null; warnings: string[]; compute_ms: number; disclaimer: string;
}
export interface Job<T = unknown> { id: string; kind: string; state: 'queued' | 'running' | 'done' | 'error' | 'cancelled'; progress: number; message: string; error: string | null; result?: T; meta: Record<string, unknown> }

export interface OptMetrics { total_trades: number; win_rate: number; expectancy_r: number; net_r: number; profit_factor: number | null; max_drawdown_pct: number; return_pct: number }
export interface OptParams { timeframe: Timeframe; min_rr: number; liquidity_sweep: string; order_block: string; displacement: string; risk_percent: number; sessions: string[] }
export interface OptRow { params: OptParams; train: OptMetrics; validation: OptMetrics; test?: OptMetrics; score: number | null }
export interface OptimizeResult {
  splits: Record<'train' | 'validation' | 'test', { start: number; end: number }>; combinations: number; signal_runs: number; results: OptRow[];
  walk_forward: { folds: { fold: number; in_sample: { start: number; end: number }; out_of_sample: { start: number; end: number }; chosen: OptParams | null; in_sample_metrics: OptMetrics | null; out_of_sample_metrics: OptMetrics | null }[];
    combined_out_of_sample: { total_trades: number; net_r: number; win_rate: number; expectancy_r: number } } | null;
  warnings: string[]; symbol: string;
}
export interface OptimizeGrid { risk_percent: number[]; min_rr: number[]; timeframes: Timeframe[]; sessions: string[][]; liquidity_sweep: string[]; order_block: string[]; displacement: string[] }

export interface RunSummary { id: string; created: number; symbol: string; timeframe: Timeframe; name: string | null; start: string | null; end: string | null; provider: string | null;
  stats: Pick<BacktestStats, 'total_trades' | 'win_rate' | 'net_r' | 'profit_factor' | 'max_drawdown_pct' | 'return_pct'> }
export interface Profile { id: number; name: string; settings: ICTSettings; backtest: Partial<BacktestConfig> | null; updated: number }

export interface ReplayInfo { id: string; time: number; index: number; remaining: number; at_end: boolean; first_time: number; last_time: number; new_setups: Setup[] }
export type ReplayState = AnalysisResponse & { replay: ReplayInfo };
