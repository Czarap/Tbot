/**
 * Canvas candlestick chart with ICT overlays.
 *
 * Framework-agnostic: React mounts it once and pushes data/flags into it.
 * Features: candles, volume, zoom (wheel / pinch), pan (drag / swipe), crosshair,
 * price + time axes, current-price line, visible high/low markers, session boxes,
 * premium/discount, FVG zones, liquidity lines, sweeps, BOS/CHoCH, swings,
 * displacement, setup position boxes, horizontal-line drawings, hover tooltips.
 */
import type {
  Analysis, CalendarEvent, Candle, DisplayTz, EditedLevels, HoverInfo, OverlayFlags, Setup, Trade,
} from '../types';
import { fmtDate, fmtDateTime, fmtNum, fmtPrice, fmtTime, wall } from './format';

export type Tool = 'cursor' | 'hline';

export interface ChartCallbacks {
  onHover?: (info: HoverInfo | null) => void;
  onCrosshair?: (candle: Candle | null) => void;
  onSelectSetup?: (id: string | null) => void;
  onDrawingsChange?: (prices: number[]) => void;
  onViewChange?: (atLatest: boolean) => void;
  onSelectTrade?: (id: string) => void;
}

interface Hit {
  kind: 'rect' | 'hline' | 'point';
  x0: number; y0: number; x1: number; y1: number;
  info: Omit<HoverInfo, 'x' | 'y'>;
  setupId?: string;
  tradeId?: string;
  drawingIndex?: number;
}

const C = {
  bg: '#0b0e14',
  grid: 'rgba(148,163,184,0.07)',
  axisText: '#8b95a7',
  axisBg: '#0b0e14',
  border: '#1e2533',
  up: '#26a69a',
  down: '#ef5350',
  bull: '#22c55e',
  bear: '#f43f5e',
  bsl: '#38bdf8',
  ssl: '#fb923c',
  prev: '#e2e8f0',
  eq: '#a78bfa',
  disp: '#facc15',
  cross: 'rgba(203,213,225,0.55)',
  drawing: '#eab308',
  obBull: '#3b82f6',
  obBear: '#d946ef',
};

const AXIS_W = 74;
const TIME_H = 26;
const SETUP_BARS = 30;
const FONT = '11px ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
const MONO = '11px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

const TIME_STEPS = [60, 300, 900, 1800, 3600, 7200, 14400, 21600, 43200, 86400, 172800, 604800, 2592000];

function alpha(hex: string, a: number): string {
  const h = hex.replace('#', '');
  const n = parseInt(h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

function niceStep(raw: number): number {
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const m = raw / p;
  return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10) * p;
}

export class CandleChart {
  private container: HTMLElement;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: ChartCallbacks;
  private ro: ResizeObserver;
  private dpr = 1;
  private w = 0;
  private h = 0;

  private candles: Candle[] = [];
  private times: number[] = [];
  private analysis: Analysis | null = null;
  private key = '';
  private precision = 2;
  private tfSeconds = 900;
  private watermark = '';
  private warning = '';

  private barSpacing = 8;
  private rightIndex = 0;
  private flags: OverlayFlags;
  private tz: DisplayTz = 'America/New_York';
  private selectedSetup: string | null = null;
  private edited: Record<string, EditedLevels> = {};
  private tool: Tool = 'cursor';
  private drawings: number[] = [];
  private trades: Trade[] = [];
  private selectedTrade: string | null = null;
  private news: CalendarEvent[] = [];

  private mouse: { x: number; y: number } | null = null;
  private pointers = new Map<number, { x: number; y: number }>();
  private drag: { x: number; y: number; right: number; moved: boolean; type: string } | null = null;
  private pinch: { dist: number; spacing: number; midIdx: number; midX: number } | null = null;
  private hits: Hit[] = [];
  private raf = 0;
  private pMin = 0;
  private pMax = 1;

  constructor(container: HTMLElement, flags: OverlayFlags, cb: ChartCallbacks = {}) {
    this.container = container;
    this.flags = flags;
    this.cb = cb;
    this.canvas = document.createElement('canvas');
    this.canvas.style.display = 'block';
    this.canvas.style.touchAction = 'none';
    this.canvas.style.cursor = 'crosshair';
    container.appendChild(this.canvas);
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D not supported');
    this.ctx = ctx;
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    this.resize();
    this.bind();
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.canvas.remove();
  }

  // ------------------------------------------------------------- public API
  setData(candles: Candle[], analysis: Analysis | null, key: string, precision: number, tfSeconds: number, watermark: string, warning = ''): void {
    const wasLatest = this.atLatest();
    const keyChanged = key !== this.key;
    this.candles = candles.slice();
    this.times = this.candles.map((c) => c.time);
    this.analysis = analysis;
    this.precision = precision;
    this.tfSeconds = tfSeconds;
    this.watermark = watermark;
    this.warning = warning;
    if (keyChanged) {
      this.key = key;
      this.barSpacing = this.w < 640 ? 6 : 8;
      this.rightIndex = candles.length - 1 + 6;
    } else if (wasLatest) {
      this.rightIndex = candles.length - 1 + 6; // auto-scroll: stay pinned to the newest candle
    }
    this.clampView();
    this.request();
  }

  /** Live update: replace the forming candle or append a new one. Older candles are ignored. */
  upsertCandle(c: Candle): void {
    const n = this.candles.length;
    if (n === 0) return;
    const last = this.candles[n - 1];
    if (c.time === last.time) {
      this.candles[n - 1] = c;
    } else if (c.time > last.time) {
      const pinned = this.atLatest();
      this.candles.push(c);
      this.times.push(c.time);
      if (pinned) this.rightIndex += 1; // auto-scroll only if the user is looking at the latest candle
    } else {
      return;
    }
    this.request();
  }

  setFlags(flags: OverlayFlags): void { this.flags = flags; this.request(); }
  setTimezone(tz: DisplayTz): void { this.tz = tz; this.request(); }
  setSelectedSetup(id: string | null): void { this.selectedSetup = id; this.request(); }
  setEdited(edited: Record<string, EditedLevels>): void { this.edited = edited; this.request(); }
  setTool(tool: Tool): void { this.tool = tool; this.canvas.style.cursor = tool === 'hline' ? 'copy' : 'crosshair'; }
  setDrawings(d: number[]): void { this.drawings = d; this.request(); }
  setTrades(t: Trade[], selected: string | null = null): void { this.trades = t; this.selectedTrade = selected; this.request(); }
  setNews(events: CalendarEvent[]): void { this.news = events; this.request(); }

  scrollToLatest(): void {
    this.rightIndex = this.candles.length - 1 + 6;
    this.clampView();
    this.request();
  }

  focusTime(t: number, spanBars = 80): void {
    const i = this.indexAtOrBefore(t);
    if (i < 0) return;
    const visible = this.plotW() / this.barSpacing;
    if (visible < spanBars * 0.6) this.barSpacing = Math.max(3, this.plotW() / spanBars);
    this.rightIndex = i + this.plotW() / this.barSpacing / 2;
    this.clampView();
    this.request();
  }

  zoom(factor: number): void {
    const mid = this.plotW() / 2;
    this.zoomAt(mid, this.barSpacing * factor);
  }

  // ---------------------------------------------------------------- geometry
  private plotW(): number { return Math.max(10, this.w - AXIS_W); }
  private plotH(): number { return Math.max(10, this.h - TIME_H); }
  private priceH(): number { return this.flags.volume ? this.plotH() * 0.86 : this.plotH(); }
  private x(i: number): number { return this.plotW() - (this.rightIndex - i) * this.barSpacing; }
  private indexAtX(x: number): number { return this.rightIndex - (this.plotW() - x) / this.barSpacing; }
  private topPad(): number { return this.w < 640 ? 40 : 24; }
  private y(p: number): number { const t = this.topPad(); return t + ((this.pMax - p) / (this.pMax - this.pMin || 1)) * (this.priceH() - t - 8); }
  private priceAtY(y: number): number { const t = this.topPad(); return this.pMax - ((y - t) / (this.priceH() - t - 8)) * (this.pMax - this.pMin); }

  private atLatest(): boolean { return this.candles.length === 0 || this.rightIndex >= this.candles.length - 1; }

  private clampView(): void {
    const n = this.candles.length;
    const vis = this.plotW() / this.barSpacing;
    this.rightIndex = Math.min(Math.max(this.rightIndex, Math.min(10, n)), n - 1 + vis * 0.8);
    this.cb.onViewChange?.(this.atLatest());
  }

  /** largest index with time <= t (or -1) */
  private indexAtOrBefore(t: number): number {
    const a = this.times;
    let lo = 0, hi = a.length - 1, ans = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (a[mid] <= t) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans;
  }

  /** fractional index for any time (before first candle -> negative) */
  private idx(t: number): number {
    if (this.times.length === 0) return 0;
    if (t < this.times[0]) return -1 - (this.times[0] - t) / this.tfSeconds;
    const i = this.indexAtOrBefore(t);
    if (this.times[i] === t) return i;
    if (i === this.times.length - 1) return i + (t - this.times[i]) / this.tfSeconds; // future (e.g. scheduled news)
    return i + Math.min(0.99, (t - this.times[i]) / this.tfSeconds);
  }

  // ------------------------------------------------------------------ events
  private bind(): void {
    const cv = this.canvas;
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      const rect = cv.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY) || e.shiftKey) {
        const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
        this.rightIndex += d / this.barSpacing;
        this.clampView();
      } else {
        const k = e.ctrlKey ? 0.01 : 0.0015;
        this.zoomAt(Math.min(mx, this.plotW()), this.barSpacing * Math.exp(-e.deltaY * k));
      }
      this.request();
    }, { passive: false });

    cv.addEventListener('pointerdown', (e) => {
      const p = this.local(e);
      this.pointers.set(e.pointerId, p);
      cv.setPointerCapture(e.pointerId);
      if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        const midX = (a.x + b.x) / 2;
        this.pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), spacing: this.barSpacing, midIdx: this.indexAtX(midX), midX };
        this.drag = null;
      } else {
        this.drag = { x: p.x, y: p.y, right: this.rightIndex, moved: false, type: e.pointerType };
      }
    });

    cv.addEventListener('pointermove', (e) => {
      const p = this.local(e);
      if (this.pointers.has(e.pointerId)) this.pointers.set(e.pointerId, p);
      if (this.pinch && this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        this.barSpacing = Math.min(60, Math.max(1.2, this.pinch.spacing * (dist / (this.pinch.dist || 1))));
        this.rightIndex = this.pinch.midIdx + (this.plotW() - this.pinch.midX) / this.barSpacing;
        this.clampView();
        this.request();
        return;
      }
      if (this.drag) {
        const dx = p.x - this.drag.x;
        if (Math.abs(dx) > 3 || Math.abs(p.y - this.drag.y) > 3) this.drag.moved = true;
        if (this.drag.moved) {
          this.rightIndex = this.drag.right - dx / this.barSpacing;
          this.clampView();
          if (this.drag.type !== 'mouse') { this.mouse = null; this.emitHover(null); }
        }
      }
      if (e.pointerType === 'mouse' || !this.drag) {
        this.mouse = p;
        this.updateHover();
      }
      this.request();
    });

    const end = (e: PointerEvent) => {
      const p = this.local(e);
      const wasDrag = this.drag?.moved ?? false;
      const wasPinch = !!this.pinch;
      this.pointers.delete(e.pointerId);
      if (this.pointers.size < 2) this.pinch = null;
      if (e.type === 'pointerup' && this.drag && !wasDrag && !wasPinch) this.click(p, e.pointerType);
      if (this.pointers.size === 0) this.drag = null;
    };
    cv.addEventListener('pointerup', end);
    cv.addEventListener('pointercancel', end);
    cv.addEventListener('pointerleave', (e) => {
      if (e.pointerType === 'mouse') {
        this.mouse = null;
        this.emitHover(null);
        this.cb.onCrosshair?.(null);
        this.request();
      }
    });
    cv.addEventListener('dblclick', () => {
      this.barSpacing = this.w < 640 ? 6 : 8;
      this.scrollToLatest();
    });
  }

  private local(e: PointerEvent | MouseEvent): { x: number; y: number } {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private zoomAt(mx: number, spacing: number): void {
    const idx = this.indexAtX(mx);
    this.barSpacing = Math.min(60, Math.max(1.2, spacing));
    this.rightIndex = idx + (this.plotW() - mx) / this.barSpacing;
    this.clampView();
    this.request();
  }

  private click(p: { x: number; y: number }, pointerType: string): void {
    if (p.x > this.plotW() || p.y > this.plotH()) return;
    if (this.tool === 'hline') {
      const price = Number(this.priceAtY(p.y).toFixed(this.precision));
      this.drawings = [...this.drawings, price];
      this.cb.onDrawingsChange?.(this.drawings);
      this.request();
      return;
    }
    const hit = this.hitAt(p.x, p.y);
    if (hit?.tradeId) {
      this.cb.onSelectTrade?.(hit.tradeId);
    } else if (hit?.setupId) {
      this.cb.onSelectSetup?.(hit.setupId);
    } else if (hit?.drawingIndex !== undefined && pointerType === 'mouse') {
      // click a drawing to remove it
      this.drawings = this.drawings.filter((_, i) => i !== hit.drawingIndex);
      this.cb.onDrawingsChange?.(this.drawings);
    }
    if (pointerType !== 'mouse') {
      this.mouse = p; // tap shows crosshair + tooltip on touch devices
      this.updateHover();
    }
    this.request();
  }

  private hitAt(x: number, y: number): Hit | null {
    for (let k = this.hits.length - 1; k >= 0; k--) {
      const h = this.hits[k];
      if (h.kind === 'rect') {
        if (x >= Math.min(h.x0, h.x1) && x <= Math.max(h.x0, h.x1) && y >= Math.min(h.y0, h.y1) && y <= Math.max(h.y0, h.y1)) return h;
      } else if (h.kind === 'hline') {
        if (Math.abs(y - h.y0) <= 4 && x >= h.x0 - 2 && x <= h.x1 + 2) return h;
      } else if (Math.hypot(x - h.x0, y - h.y0) <= 8) {
        return h;
      }
    }
    return null;
  }

  private updateHover(): void {
    const m = this.mouse;
    if (!m) return;
    const i = Math.round(this.indexAtX(m.x));
    const c = this.candles[i];
    this.cb.onCrosshair?.(c && m.x <= this.plotW() ? c : null);
    const hit = m.x <= this.plotW() ? this.hitAt(m.x, m.y) : null;
    this.emitHover(hit ? { ...hit.info, x: m.x, y: m.y } : null);
    this.canvas.style.cursor = hit?.setupId || hit?.tradeId ? 'pointer' : this.tool === 'hline' ? 'copy' : 'crosshair';
  }

  private emitHover(info: HoverInfo | null): void { this.cb.onHover?.(info); }

  // ---------------------------------------------------------------- render
  private resize(): void {
    const r = this.container.getBoundingClientRect();
    this.dpr = window.devicePixelRatio || 1;
    this.w = Math.max(50, Math.floor(r.width));
    this.h = Math.max(50, Math.floor(r.height));
    this.canvas.width = Math.floor(this.w * this.dpr);
    this.canvas.height = Math.floor(this.h * this.dpr);
    this.canvas.style.width = `${this.w}px`;
    this.canvas.style.height = `${this.h}px`;
    this.clampView();
    this.draw();
  }

  private request(): void {
    if (this.raf) return;
    this.raf = requestAnimationFrame(() => { this.raf = 0; this.draw(); });
  }

  private draw(): void {
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, this.w, this.h);
    this.hits = [];
    const n = this.candles.length;
    if (n === 0) {
      ctx.fillStyle = C.axisText;
      ctx.font = FONT;
      ctx.fillText('No data', 20, 30);
      return;
    }
    const pw = this.plotW();
    const i0 = Math.max(0, Math.floor(this.indexAtX(0)) - 1);
    const i1 = Math.min(n - 1, Math.ceil(this.rightIndex));
    this.computeScale(i0, i1);

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, pw, this.plotH());
    ctx.clip();
    this.drawWatermark();
    this.drawGrid(i0, i1);
    const a = this.analysis;
    if (a) {
      if (this.flags.sessions) this.drawSessions(a, i0, i1);
      if (this.flags.premiumDiscount) this.drawPremiumDiscount(a);
      if (this.flags.fvg) this.drawFVGs(a, i0, i1);
      if (this.flags.orderBlocks) this.drawOrderBlocks(a, i0, i1);
    }
    if (this.flags.volume) this.drawVolume(i0, i1);
    if (a && this.flags.displacement) this.drawDisplacement(a, i0, i1);
    this.drawCandles(i0, i1);
    if (a) {
      if (this.flags.liquidity || this.flags.previousLevels || this.flags.sessions) this.drawLiquidity(a, i0, i1);
      if (this.flags.structure) this.drawStructure(a, i0, i1);
      if (this.flags.swings) this.drawSwings(a, i0, i1);
      if (this.flags.sweeps) this.drawSweeps(a, i0, i1);
      if (this.flags.setups) this.drawSetups(a, i0, i1);
    }
    if (this.trades.length) this.drawTrades(i0, i1);
    if (this.flags.news && this.news.length) this.drawNews(i0, i1);
    if (this.flags.highLow) this.drawHighLow(i0, i1);
    this.drawDrawings();
    this.drawLastPrice();
    this.drawCrosshair();
    ctx.restore();
    this.drawAxes(i0, i1);
  }

  private computeScale(i0: number, i1: number): void {
    let lo = Infinity, hi = -Infinity;
    for (let i = i0; i <= i1; i++) {
      const c = this.candles[i];
      if (c.low < lo) lo = c.low;
      if (c.high > hi) hi = c.high;
    }
    const sel = this.selectedSetupObj();
    const si = sel ? this.idx(sel.time) : -1;
    if (sel && si >= i0 - SETUP_BARS && si <= i1 + 1) {
      const lv = this.levelsFor(sel);
      lo = Math.min(lo, lv.stop_loss, lv.take_profit);
      hi = Math.max(hi, lv.stop_loss, lv.take_profit);
    }
    if (!isFinite(lo)) { lo = 0; hi = 1; }
    const pad = (hi - lo) * 0.06 || 1;
    this.pMin = lo - pad;
    this.pMax = hi + pad;
  }

  private selectedSetupObj(): Setup | null {
    if (!this.selectedSetup || !this.analysis) return null;
    return this.analysis.setups.find((s) => s.id === this.selectedSetup) ?? null;
  }

  private levelsFor(s: Setup): EditedLevels {
    return this.edited[s.id] ?? { entry: s.entry, stop_loss: s.stop_loss, take_profit: s.take_profit };
  }

  private drawWatermark(): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(148,163,184,0.06)';
    ctx.font = `600 ${Math.max(24, Math.min(64, this.w / 14))}px ui-sans-serif, system-ui, sans-serif`;
    ctx.fillText(this.watermark, this.plotW() / 2, this.priceH() / 2 - (this.warning ? 24 : 0));
    if (this.warning) {
      ctx.fillStyle = 'rgba(251,146,60,0.10)';
      ctx.font = `700 ${Math.max(16, Math.min(40, this.w / 22))}px ui-sans-serif, system-ui, sans-serif`;
      ctx.fillText(this.warning, this.plotW() / 2, this.priceH() / 2 + 26);
    }
    ctx.restore();
  }

  private drawGrid(i0: number, i1: number): void {
    const ctx = this.ctx;
    ctx.strokeStyle = C.grid;
    ctx.lineWidth = 1;
    const step = niceStep((this.pMax - this.pMin) / Math.max(2, this.priceH() / 60));
    ctx.beginPath();
    for (let p = Math.ceil(this.pMin / step) * step; p <= this.pMax; p += step) {
      const y = Math.round(this.y(p)) + 0.5;
      ctx.moveTo(0, y); ctx.lineTo(this.plotW(), y);
    }
    for (const i of this.timeTicks(i0, i1).map((t) => t.i)) {
      const x = Math.round(this.x(i)) + 0.5;
      ctx.moveTo(x, 0); ctx.lineTo(x, this.plotH());
    }
    ctx.stroke();
  }

  private timeTicks(i0: number, i1: number): { i: number; label: string; major: boolean }[] {
    const minPx = 90;
    const step = TIME_STEPS.find((s) => (s / this.tfSeconds) * this.barSpacing >= minPx && s >= this.tfSeconds) ?? TIME_STEPS[TIME_STEPS.length - 1];
    const out: { i: number; label: string; major: boolean }[] = [];
    let prevBucket: number | null = null;
    let prevDay: number | null = null;
    let lastX = -1e9;
    for (let i = Math.max(0, i0 - 1); i <= i1; i++) {
      const w = wall(this.times[i], this.tz);
      const bucket = step >= 2592000 ? w.year * 12 + w.month : Math.floor(w.localSeconds / step);
      const day = Math.floor(w.localSeconds / 86400);
      if (prevBucket !== null && bucket !== prevBucket) {
        const x = this.x(i);
        if (x - lastX >= minPx * 0.7) {
          const major = day !== prevDay;
          const label = step >= 86400 || major ? fmtDate(this.times[i], this.tz) : fmtTime(this.times[i], this.tz);
          out.push({ i, label, major });
          lastX = x;
        }
      }
      prevBucket = bucket;
      prevDay = day;
    }
    return out;
  }

  private drawCandles(i0: number, i1: number): void {
    const ctx = this.ctx;
    const bw = Math.max(1, Math.floor(this.barSpacing * 0.7));
    for (let i = i0; i <= i1; i++) {
      const c = this.candles[i];
      const up = c.close >= c.open;
      const col = up ? C.up : C.down;
      const x = Math.round(this.x(i));
      ctx.fillStyle = col;
      const yh = this.y(c.high), yl = this.y(c.low);
      ctx.fillRect(x, Math.round(yh), 1, Math.max(1, Math.round(yl - yh)));
      if (bw > 2) {
        const yo = this.y(c.open), yc = this.y(c.close);
        const top = Math.round(Math.min(yo, yc));
        ctx.fillRect(x - Math.floor(bw / 2), top, bw, Math.max(1, Math.round(Math.abs(yc - yo))));
      }
    }
  }

  private drawVolume(i0: number, i1: number): void {
    const ctx = this.ctx;
    let vmax = 0;
    for (let i = i0; i <= i1; i++) vmax = Math.max(vmax, this.candles[i].volume);
    if (vmax <= 0) return;
    const base = this.plotH();
    const hgt = this.plotH() * 0.13;
    const bw = Math.max(1, Math.floor(this.barSpacing * 0.7));
    for (let i = i0; i <= i1; i++) {
      const c = this.candles[i];
      const vh = (c.volume / vmax) * hgt;
      ctx.fillStyle = alpha(c.close >= c.open ? C.up : C.down, 0.28);
      ctx.fillRect(Math.round(this.x(i)) - Math.floor(bw / 2), base - vh, bw, vh);
    }
  }

  private label(text: string, x: number, y: number, color: string, opts: { align?: CanvasTextAlign; bg?: string; base?: CanvasTextBaseline; font?: string } = {}): { w: number; h: number } {
    const ctx = this.ctx;
    ctx.font = opts.font ?? FONT;
    ctx.textAlign = opts.align ?? 'left';
    ctx.textBaseline = opts.base ?? 'middle';
    const w = ctx.measureText(text).width;
    if (opts.bg) {
      const bx = opts.align === 'right' ? x - w - 3 : opts.align === 'center' ? x - w / 2 - 3 : x - 3;
      ctx.fillStyle = opts.bg;
      ctx.fillRect(bx, y - 8, w + 6, 16);
    }
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
    return { w, h: 14 };
  }

  private drawSessions(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    if (this.tfSeconds > 3600) return;
    for (const s of a.sessions) {
      const xs = this.idx(s.start_time);
      const xe = s.end_time !== null ? this.idx(s.end_time) : this.candles.length;
      if (xe < i0 - 1 || xs > i1 + 1) continue;
      const x0 = this.x(xs) - this.barSpacing / 2, x1 = this.x(xe) - this.barSpacing / 2;
      const y0 = this.y(s.high), y1 = this.y(s.low);
      ctx.fillStyle = alpha(s.color, 0.07);
      ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx.strokeStyle = alpha(s.color, 0.45);
      ctx.setLineDash([2, 3]);
      ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      ctx.setLineDash([]);
      if (x1 - x0 > 30) this.label(s.name, x0 + 3, y0 - 7, alpha(s.color, 0.9), { font: '10px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'rect', x0, y0, x1, y1, info: {
        title: `${s.name} session${s.complete ? '' : ' (in progress)'}`, color: s.color,
        lines: [`High ${fmtPrice(s.high, this.precision)}  ·  Low ${fmtPrice(s.low, this.precision)}`, `Range ${fmtNum(s.high - s.low, this.precision)}`,
          `${fmtDateTime(s.start_time, this.tz)} → ${s.end_time ? fmtTime(s.end_time, this.tz) : 'now'}`],
      } });
    }
  }

  private drawPremiumDiscount(a: Analysis): void {
    const dr = a.dealing_range;
    if (!dr) return;
    const ctx = this.ctx;
    const xs = this.x(Math.min(this.idx(dr.high_time), this.idx(dr.low_time)));
    const xe = this.plotW();
    const yh = this.y(dr.high), ye = this.y(dr.equilibrium), yl = this.y(dr.low);
    ctx.fillStyle = 'rgba(244,63,94,0.06)';
    ctx.fillRect(xs, yh, xe - xs, ye - yh);
    ctx.fillStyle = 'rgba(34,197,94,0.06)';
    ctx.fillRect(xs, ye, xe - xs, yl - ye);
    ctx.strokeStyle = alpha(C.eq, 0.8);
    ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.moveTo(xs, ye); ctx.lineTo(xe, ye); ctx.stroke();
    ctx.setLineDash([]);
    const lx = Math.max(xs + 4, 4);
    const f = '10px ui-sans-serif, system-ui, sans-serif';
    if (yl - yh > 70) {
      this.label('Premium', lx, yh + 10, 'rgba(244,63,94,0.75)', { font: f });
      this.label('Discount', lx, yl - 10, 'rgba(34,197,94,0.75)', { font: f });
    }
    if (yl - yh > 24) this.label(`EQ ${fmtPrice(dr.equilibrium, this.precision)}`, Math.max(lx, xe - 120), ye - 8, alpha(C.eq, 0.95), { font: f });
    this.hits.push({ kind: 'hline', x0: xs, y0: ye, x1: xe, y1: ye, info: {
      title: 'Dealing range', color: C.eq,
      lines: [`High ${fmtPrice(dr.high, this.precision)}  ·  Low ${fmtPrice(dr.low, this.precision)}`, `Equilibrium (50%) ${fmtPrice(dr.equilibrium, this.precision)}`,
        `Source: ${dr.source === 'swings' ? 'latest confirmed swing high / low' : 'previous day high / low'}`, 'Above EQ = premium (favour shorts), below = discount (favour longs)'],
    } });
  }

  private drawFVGs(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    const n = this.candles.length;
    for (const g of a.fvgs) {
      if (g.status === 'FILLED' && !this.flags.filledFvg) continue;
      const xs = this.idx(g.time);
      const xe = g.filled_time !== null ? this.idx(g.filled_time) : n + 4;
      if (xe < i0 || xs > i1 + 1) continue;
      const x0 = this.x(xs) - this.barSpacing / 2, x1 = this.x(xe) + this.barSpacing / 2;
      const y0 = this.y(g.top), y1 = this.y(g.bottom);
      const col = g.direction === 'bullish' ? C.bull : C.bear;
      const filled = g.status === 'FILLED';
      ctx.fillStyle = alpha(col, filled ? 0.06 : g.status === 'MITIGATED' ? 0.13 : 0.2);
      ctx.fillRect(x0, y0, x1 - x0, Math.max(1, y1 - y0));
      ctx.strokeStyle = alpha(col, filled ? 0.25 : 0.55);
      ctx.lineWidth = 1;
      if (filled) ctx.setLineDash([3, 3]);
      ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, Math.max(1, y1 - y0));
      ctx.setLineDash([]);
      if (!filled && y1 - y0 >= 9 && x1 - x0 > 26) this.label('FVG', x0 + 3, (y0 + y1) / 2, alpha(col, 0.95), { font: '9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'rect', x0, y0: y0 - 1, x1, y1: y1 + 1, info: {
        title: `${g.direction === 'bullish' ? 'Bullish' : 'Bearish'} FVG`, color: col,
        lines: [
          `Upper: ${fmtPrice(g.top, this.precision)}`, `Lower: ${fmtPrice(g.bottom, this.precision)}`,
          `Size: ${fmtNum(g.size, this.precision)} (${g.size_atr.toFixed(2)} × ATR)  ·  CE ${fmtPrice(g.ce, this.precision)}`,
          `Status: ${g.status}${g.status === 'MITIGATED' ? ` (${Math.round(g.max_fill_pct * 100)}% filled)` : ''}`,
          `Created: ${fmtDateTime(g.created_time, this.tz)} (candle ${fmtTime(g.time, this.tz)})`,
          g.mitigated_time ? `Mitigated: ${fmtDateTime(g.mitigated_time, this.tz)}` : 'Mitigated: no',
          g.filled_time ? `Filled: ${fmtDateTime(g.filled_time, this.tz)}` : 'Completely filled: no',
        ],
      } });
    }
  }

  private drawOrderBlocks(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    const n = this.candles.length;
    for (const ob of a.order_blocks ?? []) {
      const xs = this.idx(ob.time);
      const xe = ob.invalidated_time !== null ? this.idx(ob.invalidated_time) : n + 4;
      if (xe < i0 || xs > i1 + 1) continue;
      const x0 = this.x(xs) - this.barSpacing / 2, x1 = this.x(xe) + this.barSpacing / 2;
      const y0 = this.y(ob.top), y1 = this.y(ob.bottom);
      const col = ob.direction === 'bullish' ? C.obBull : C.obBear;
      const dead = ob.status === 'INVALIDATED';
      ctx.fillStyle = alpha(col, dead ? 0.05 : 0.14);
      ctx.fillRect(x0, y0, x1 - x0, Math.max(1, y1 - y0));
      ctx.strokeStyle = alpha(col, dead ? 0.3 : 0.75);
      ctx.lineWidth = 1;
      ctx.setLineDash(dead ? [3, 3] : [6, 2]);
      ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, Math.max(1, y1 - y0));
      ctx.setLineDash([]);
      if (y1 - y0 >= 9 && x1 - x0 > 24) this.label(ob.direction === 'bullish' ? '+OB' : '−OB', x0 + 3, (y0 + y1) / 2, alpha(col, 1), { font: '600 9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'rect', x0, y0: y0 - 1, x1, y1: y1 + 1, info: {
        title: ob.explanation[0] ?? 'Order block', color: col,
        lines: [...ob.explanation.slice(1), `Status: ${ob.status}`, `OB candle: ${fmtDateTime(ob.time, this.tz)}`,
          `Known from: ${fmtDateTime(ob.created_time, this.tz)}`,
          ob.mitigated_time ? `Mitigated: ${fmtDateTime(ob.mitigated_time, this.tz)}` : 'Mitigated: no',
          ...(ob.invalidated_time ? [`Invalidated: ${fmtDateTime(ob.invalidated_time, this.tz)}`] : [])],
      } });
    }
  }

  private drawLiquidity(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    const n = this.candles.length;
    const pw = this.plotW();
    const labelsAtRight: { y: number; text: string; color: string }[] = [];
    for (const lv of a.liquidity_levels) {
      const prev = lv.kind === 'pdh' || lv.kind === 'pdl' || lv.kind === 'pwh' || lv.kind === 'pwl';
      const sess = lv.kind === 'session_high' || lv.kind === 'session_low';
      const swing = lv.kind === 'swing_high' || lv.kind === 'swing_low';
      if (prev && !this.flags.previousLevels) continue;
      if (sess && !this.flags.sessions) continue;
      if (!prev && !sess && !this.flags.liquidity) continue;
      if (swing && !this.flags.swingLiquidity) continue;
      const xs = this.idx(lv.start_time);
      const xe = lv.end_time !== null ? this.idx(lv.end_time) : n - 1 + 3;
      if (xe < i0 || xs > i1 + 1) continue;
      const x0 = Math.max(this.x(xs), -5), x1 = Math.min(lv.end_time !== null ? this.x(xe) : pw, pw);
      const y = Math.round(this.y(lv.price)) + 0.5;
      const col = prev ? C.prev : lv.side === 'buy' ? C.bsl : C.ssl;
      const swept = lv.status === 'swept';
      ctx.strokeStyle = alpha(col, swept ? 0.35 : swing ? 0.55 : 0.85);
      ctx.lineWidth = lv.kind.startsWith('equal') || prev ? 1.5 : 1;
      ctx.setLineDash(swing ? [4, 4] : prev ? [8, 4] : sess ? [2, 3] : []);
      ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
      ctx.setLineDash([]);
      const text = prev ? lv.label : sess ? lv.label : lv.kind.startsWith('equal') ? `${lv.label} ${lv.side === 'buy' ? 'BSL' : 'SSL'}` : lv.side === 'buy' ? 'BSL' : 'SSL';
      if (lv.end_time === null) labelsAtRight.push({ y, text, color: alpha(col, 0.95) });
      else if (x1 - x0 > 40 && !swing) this.label(text, x1 - 3, y - 7, alpha(col, 0.8), { align: 'right', font: '9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'hline', x0, y0: y, x1, y1: y, info: {
        title: `${lv.side === 'buy' ? 'Buy-side' : 'Sell-side'} liquidity · ${lv.label}`, color: col,
        lines: [
          `Price: ${fmtPrice(lv.price, this.precision)}`, `Type: ${lv.kind.replace('_', ' ')}`,
          `Known from: ${fmtDateTime(lv.created_time, this.tz)}`,
          `Status: ${lv.status.toUpperCase()}${lv.end_time ? ` at ${fmtDateTime(lv.end_time, this.tz)}` : ''}`,
          lv.side === 'buy' ? 'Resting buy stops above this high' : 'Resting sell stops below this low',
        ],
      } });
    }
    // right-edge labels for active levels, de-overlapped
    labelsAtRight.sort((p, q) => p.y - q.y);
    let lastY = -100;
    for (const l of labelsAtRight) {
      const y = Math.max(l.y - 7, lastY + 13);
      this.label(l.text, pw - 4, y, l.color, { align: 'right', bg: 'rgba(11,14,20,0.75)', font: '9px ui-sans-serif, system-ui, sans-serif' });
      lastY = y;
    }
  }

  private drawStructure(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    for (const ev of a.structure_events) {
      const xs = this.idx(ev.swing_time), xe = this.idx(ev.time);
      if (xe < i0 || xs > i1 + 1) continue;
      const x0 = this.x(xs), x1 = this.x(xe);
      const y = Math.round(this.y(ev.level)) + 0.5;
      const col = ev.direction === 'bullish' ? C.bull : C.bear;
      ctx.strokeStyle = col;
      ctx.lineWidth = 1;
      ctx.setLineDash(ev.type === 'CHoCH' ? [5, 3] : []);
      ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
      ctx.setLineDash([]);
      const lx = (x0 + x1) / 2;
      const ly = ev.direction === 'bullish' ? y - 8 : y + 8;
      this.label(ev.type, lx, ly, col, { align: 'center', font: `600 10px ui-sans-serif, system-ui, sans-serif` });
      this.hits.push({ kind: 'rect', x0: Math.min(x0, x1), y0: y - 14, x1: Math.max(x0, x1), y1: y + 14, info: {
        title: `${ev.type} · ${ev.direction}`, color: col, lines: [...ev.explanation.slice(1), `Time: ${fmtDateTime(ev.time, this.tz)}`],
      } });
    }
  }

  private drawSwings(a: Analysis, i0: number, i1: number): void {
    if (this.barSpacing < 3) return;
    for (const s of a.swings) {
      const i = this.idx(s.time);
      if (i < i0 || i > i1) continue;
      const x = this.x(i);
      const hi = s.kind === 'high';
      const y = this.y(s.price) + (hi ? -9 : 9);
      const col = s.label === 'HH' || s.label === 'HL' ? alpha(C.bull, 0.85) : s.label === 'LH' || s.label === 'LL' ? alpha(C.bear, 0.85) : C.axisText;
      this.label(s.label, x, y, col, { align: 'center', font: '9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'point', x0: x, y0: y, x1: x, y1: y, info: {
        title: `Swing ${s.kind} (${s.label})`, color: col,
        lines: [`Price: ${fmtPrice(s.price, this.precision)}`, `Candle: ${fmtDateTime(s.time, this.tz)}`,
          `Confirmed: ${fmtDateTime(s.confirmed_time, this.tz)} (${s.confirmed_index - s.index} candles later)`,
          s.label.length === 2 ? `${s.label} = ${s.kind === 'high' ? (s.label === 'HH' ? 'above' : 'below') + ' previous swing high' : (s.label === 'HL' ? 'above' : 'below') + ' previous swing low'}` : 'First swing in window'],
      } });
    }
  }

  private drawSweeps(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    for (const s of a.sweeps) {
      if (!this.flags.swingLiquidity && (s.level_kind === 'swing_high' || s.level_kind === 'swing_low')) continue;
      if (!this.flags.previousLevels && ['pdh', 'pdl', 'pwh', 'pwl'].includes(s.level_kind)) continue;
      const i = this.idx(s.time);
      if (i < i0 || i > i1) continue;
      const x = this.x(i);
      const buy = s.side === 'buy';
      const y = this.y(s.extreme) + (buy ? -6 : 6);
      const col = buy ? C.bear : C.bull;
      ctx.fillStyle = col;
      ctx.beginPath();
      if (buy) { ctx.moveTo(x - 4, y - 5); ctx.lineTo(x + 4, y - 5); ctx.lineTo(x, y); }
      else { ctx.moveTo(x - 4, y + 5); ctx.lineTo(x + 4, y + 5); ctx.lineTo(x, y); }
      ctx.fill();
      if (this.barSpacing >= 5) this.label('$', x, buy ? y - 12 : y + 12, col, { align: 'center', font: '600 9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'point', x0: x, y0: buy ? y - 6 : y + 6, x1: x, y1: y, info: {
        title: `Liquidity sweep · ${s.level_label}`, color: col, lines: [...s.explanation, `Time: ${fmtDateTime(s.time, this.tz)}`],
      } });
    }
  }

  private drawDisplacement(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    for (const d of a.displacements) {
      const s = this.idx(d.start_time), e = this.idx(d.time);
      if (e < i0 || s > i1) continue;
      let hi = -Infinity, lo = Infinity;
      for (let i = Math.max(0, Math.round(s)); i <= Math.min(this.candles.length - 1, Math.round(e)); i++) {
        hi = Math.max(hi, this.candles[i].high); lo = Math.min(lo, this.candles[i].low);
      }
      if (!isFinite(hi)) continue;
      const x0 = this.x(s) - this.barSpacing * 0.5, x1 = this.x(e) + this.barSpacing * 0.5;
      const y0 = this.y(hi) - 2, y1 = this.y(lo) + 2;
      ctx.fillStyle = 'rgba(250,204,21,0.07)';
      ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx.strokeStyle = 'rgba(250,204,21,0.55)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      this.hits.push({ kind: 'rect', x0, y0, x1, y1, info: { title: `${d.direction === 'bullish' ? 'Bullish' : 'Bearish'} displacement`, color: C.disp, lines: [...d.explanation.slice(1), `Time: ${fmtDateTime(d.time, this.tz)}`] } });
    }
  }

  private drawSetups(a: Analysis, i0: number, i1: number): void {
    const ctx = this.ctx;
    for (const s of a.setups) {
      const i = this.idx(s.time);
      if (i + SETUP_BARS < i0 || i > i1 + 1) continue;
      const sel = s.id === this.selectedSetup;
      const lv = this.levelsFor(s);
      const x0 = this.x(i), x1 = this.x(i + SETUP_BARS);
      const ye = this.y(lv.entry), ysl = this.y(lv.stop_loss), ytp = this.y(lv.take_profit);
      ctx.fillStyle = sel ? 'rgba(34,197,94,0.22)' : 'rgba(34,197,94,0.10)';
      ctx.fillRect(x0, Math.min(ye, ytp), x1 - x0, Math.abs(ytp - ye));
      ctx.fillStyle = sel ? 'rgba(244,63,94,0.22)' : 'rgba(244,63,94,0.10)';
      ctx.fillRect(x0, Math.min(ye, ysl), x1 - x0, Math.abs(ysl - ye));
      ctx.lineWidth = sel ? 1.5 : 1;
      for (const [yy, col] of [[ytp, '#60a5fa'], [ysl, C.bear], [ye, C.bull]] as [number, string][]) {
        ctx.strokeStyle = alpha(col, sel ? 1 : 0.7);
        ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x1, yy); ctx.stroke();
      }
      // marker under/over the trigger candle
      const long = s.direction === 'bullish';
      const c = this.candles[Math.round(i)];
      const my = c ? (long ? this.y(c.low) + 16 : this.y(c.high) - 16) : ye;
      ctx.fillStyle = long ? C.bull : C.bear;
      ctx.beginPath();
      if (long) { ctx.moveTo(x0, my - 7); ctx.lineTo(x0 - 6, my + 3); ctx.lineTo(x0 + 6, my + 3); }
      else { ctx.moveTo(x0, my + 7); ctx.lineTo(x0 - 6, my - 3); ctx.lineTo(x0 + 6, my - 3); }
      ctx.fill();
      const tag = `${long ? 'Possible Long' : 'Possible Short'} ${s.score}/${s.max_score}`;
      const tagY = Math.max(this.topPad() + 8, long ? my + 14 : my - 14);
      this.label(tag, x0 - 4, tagY, sel ? '#ffffff' : '#cbd5e1', { bg: sel ? (long ? 'rgba(22,163,74,0.9)' : 'rgba(225,29,72,0.9)') : 'rgba(15,23,42,0.85)', font: '600 10px ui-sans-serif, system-ui, sans-serif' });
      if (sel) {
        const p = this.precision;
        this.label(`TP ${fmtPrice(lv.take_profit, p)}`, x1 - 4, ytp + (long ? -8 : 8), '#93c5fd', { align: 'right' });
        this.label(`Entry ${fmtPrice(lv.entry, p)}`, x1 - 4, ye + (long ? 8 : -8), '#86efac', { align: 'right' });
        this.label(`SL ${fmtPrice(lv.stop_loss, p)}`, x1 - 4, ysl + (long ? 8 : -8), '#fda4af', { align: 'right' });
      }
      const rr = Math.abs(lv.take_profit - lv.entry) / Math.max(1e-9, Math.abs(lv.entry - lv.stop_loss));
      this.hits.push({ kind: 'rect', x0: x0 - 7, y0: Math.min(ytp, ysl, my - 8), x1, y1: Math.max(ytp, ysl, my + 8), setupId: s.id, info: {
        title: `${s.label} · ${s.score}/${s.max_score}`, color: long ? C.bull : C.bear,
        lines: [`Hypothetical entry ${fmtPrice(lv.entry, this.precision)}`, `Stop ${fmtPrice(lv.stop_loss, this.precision)}  ·  Target ${fmtPrice(lv.take_profit, this.precision)}`,
          `R:R 1:${rr.toFixed(2)}`, `${fmtDateTime(s.time, this.tz)}`, 'Click for the full reasoning'],
      } });
    }
  }

  private drawTrades(i0: number, i1: number): void {
    const ctx = this.ctx;
    const n = this.candles.length;
    for (const tr of this.trades) {
      const xs = this.idx(tr.entry_time);
      const xe = tr.exit_time !== null ? this.idx(tr.exit_time) : n - 1;
      if (xe < i0 - 1 || xs > i1 + 1) continue;
      const sel = tr.id === this.selectedTrade;
      const long = tr.direction === 'bullish';
      const x0 = this.x(xs), x1 = this.x(xe);
      const ye = this.y(tr.entry), ysl = this.y(tr.stop_loss), ytp = this.y(tr.take_profit);
      ctx.fillStyle = sel ? 'rgba(34,197,94,0.16)' : 'rgba(34,197,94,0.06)';
      ctx.fillRect(x0, Math.min(ye, ytp), Math.max(2, x1 - x0), Math.abs(ytp - ye));
      ctx.fillStyle = sel ? 'rgba(244,63,94,0.16)' : 'rgba(244,63,94,0.06)';
      ctx.fillRect(x0, Math.min(ye, ysl), Math.max(2, x1 - x0), Math.abs(ysl - ye));
      ctx.lineWidth = sel ? 1.5 : 1;
      ctx.setLineDash([4, 3]);
      ctx.strokeStyle = 'rgba(244,63,94,0.8)';
      ctx.beginPath(); ctx.moveTo(x0, ysl); ctx.lineTo(x1, ysl); ctx.stroke();
      ctx.strokeStyle = 'rgba(96,165,250,0.85)';
      ctx.beginPath(); ctx.moveTo(x0, ytp); ctx.lineTo(x1, ytp); ctx.stroke();
      ctx.setLineDash([]);
      // entry marker
      ctx.fillStyle = long ? C.bull : C.bear;
      ctx.beginPath();
      if (long) { ctx.moveTo(x0, ye); ctx.lineTo(x0 - 6, ye + 9); ctx.lineTo(x0 + 6, ye + 9); }
      else { ctx.moveTo(x0, ye); ctx.lineTo(x0 - 6, ye - 9); ctx.lineTo(x0 + 6, ye - 9); }
      ctx.fill();
      // exit marker + path
      if (tr.exit_time !== null && tr.exit_price !== null) {
        const yx = this.y(tr.exit_price);
        ctx.strokeStyle = 'rgba(203,213,225,0.5)';
        ctx.setLineDash([2, 3]);
        ctx.beginPath(); ctx.moveTo(x0, ye); ctx.lineTo(x1, yx); ctx.stroke();
        ctx.setLineDash([]);
        const win = tr.result === 'WIN';
        ctx.fillStyle = win ? '#16a34a' : tr.result === 'LOSS' ? '#e11d48' : '#64748b';
        ctx.beginPath(); ctx.arc(x1, yx, 6, 0, Math.PI * 2); ctx.fill();
        this.label(win ? '✓' : tr.result === 'LOSS' ? '✕' : '=', x1, yx + 0.5, '#fff', { align: 'center', font: '700 9px ui-sans-serif, system-ui, sans-serif' });
      }
      if (sel || this.barSpacing > 5) {
        this.label(`${tr.id} ${tr.r_multiple >= 0 ? '+' : ''}${tr.r_multiple.toFixed(2)}R`, x0 + 6, long ? Math.max(ye, ysl) + 12 : Math.min(ye, ysl) - 12,
          tr.result === 'WIN' ? '#86efac' : tr.result === 'LOSS' ? '#fda4af' : '#cbd5e1', { bg: 'rgba(11,14,20,0.8)', font: '600 9.5px ui-sans-serif, system-ui, sans-serif' });
      }
      const top = Math.min(ye, ysl, ytp) - 10, bot = Math.max(ye, ysl, ytp) + 10;
      this.hits.push({ kind: 'rect', x0: x0 - 7, y0: top, x1: Math.max(x1, x0 + 8), y1: bot, tradeId: tr.id, info: {
        title: `${tr.id} · ${long ? 'Long' : 'Short'} · ${tr.result} ${tr.r_multiple >= 0 ? '+' : ''}${tr.r_multiple.toFixed(2)}R`,
        color: tr.result === 'WIN' ? C.bull : tr.result === 'LOSS' ? C.bear : C.axisText,
        lines: [`Entry ${fmtPrice(tr.entry, this.precision)} at ${fmtDateTime(tr.entry_time, this.tz)}`,
          `SL ${fmtPrice(tr.stop_loss, this.precision)} · TP ${fmtPrice(tr.take_profit, this.precision)} · ${tr.lots} lots`,
          tr.exit_time ? `Exit ${fmtPrice(tr.exit_price, this.precision)} (${tr.exit_reason}) at ${fmtDateTime(tr.exit_time, this.tz)}` : 'Open',
          `P/L ${tr.pnl.toFixed(2)} · ${tr.setup_type} · score ${tr.score}/${tr.max_score}`, 'Click for details'],
      } });
    }
  }

  private drawNews(i0: number, i1: number): void {
    const ctx = this.ctx;
    const ph = this.plotH();
    for (const ev of this.news) {
      const i = this.idx(ev.time);
      if (i < i0 - 1 || i > i1 + 40) continue;
      const x = Math.round(this.x(i)) + 0.5;
      if (x < 0 || x > this.plotW()) continue;
      const col = ev.importance === 'high' ? '#f97316' : '#eab308';
      ctx.strokeStyle = alpha(col, 0.55);
      ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(x, 20); ctx.lineTo(x, ph); ctx.stroke();
      ctx.setLineDash([]);
      const short = ev.name.replace(/\(.*?\)/g, '').split(' ').filter(Boolean).map((w) => (w.length > 4 ? w.slice(0, 4) : w)).slice(0, 3).join(' ');
      this.label(`${ev.currency} ${short}`, x + 3, ph - 30, alpha(col, 0.95), { bg: 'rgba(11,14,20,0.85)', font: '600 9px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'rect', x0: x - 4, y0: 20, x1: x + 4, y1: ph, info: {
        title: `${ev.currency} · ${ev.name}`, color: col,
        lines: [`${fmtDateTime(ev.time, this.tz)}${ev.exact_time ? '' : ' (time not exact)'}`, `Importance: ${ev.importance.toUpperCase()}`,
          `Forecast: ${ev.forecast ?? '—'} · Previous: ${ev.previous ?? '—'} · Actual: ${ev.actual ?? '—'}`],
      } });
    }
  }

  private drawHighLow(i0: number, i1: number): void {
    let hi = -Infinity, lo = Infinity, ih = -1, il = -1;
    const pwIdx = Math.floor(this.indexAtX(this.plotW()));
    for (let i = Math.max(i0, Math.ceil(this.indexAtX(0))); i <= Math.min(i1, pwIdx); i++) {
      const c = this.candles[i];
      if (c.high > hi) { hi = c.high; ih = i; }
      if (c.low < lo) { lo = c.low; il = i; }
    }
    if (ih < 0) return;
    const ctx = this.ctx;
    ctx.strokeStyle = 'rgba(203,213,225,0.5)';
    const xh = this.x(ih), yh = this.y(hi), xl = this.x(il), yl = this.y(lo);
    ctx.beginPath(); ctx.moveTo(xh, yh - 2); ctx.lineTo(xh + 14, yh - 2); ctx.moveTo(xl, yl + 2); ctx.lineTo(xl + 14, yl + 2); ctx.stroke();
    const f = '10px ui-sans-serif, system-ui, sans-serif';
    const pw = this.plotW();
    const right = (x: number) => x + 110 < pw;
    this.label(`H ${fmtPrice(hi, this.precision)}`, right(xh) ? xh + 16 : xh - 4, yh - 2 - (right(xh) ? 0 : 10), '#cbd5e1', { font: f, align: right(xh) ? 'left' : 'right' });
    this.label(`L ${fmtPrice(lo, this.precision)}`, right(xl) ? xl + 16 : xl - 4, yl + 2 + (right(xl) ? 0 : 10), '#cbd5e1', { font: f, align: right(xl) ? 'left' : 'right' });
  }

  private drawDrawings(): void {
    const ctx = this.ctx;
    this.drawings.forEach((p, k) => {
      const y = Math.round(this.y(p)) + 0.5;
      ctx.strokeStyle = C.drawing;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW(), y); ctx.stroke();
      this.label(fmtPrice(p, this.precision), 6, y - 8, C.drawing, { bg: 'rgba(11,14,20,0.8)', font: '10px ui-sans-serif, system-ui, sans-serif' });
      this.hits.push({ kind: 'hline', x0: 0, y0: y, x1: this.plotW(), y1: y, drawingIndex: k, info: { title: 'Horizontal line', color: C.drawing, lines: [fmtPrice(p, this.precision), 'Click to remove'] } });
    });
  }

  private drawLastPrice(): void {
    const c = this.candles[this.candles.length - 1];
    const ctx = this.ctx;
    const y = Math.round(this.y(c.close)) + 0.5;
    ctx.strokeStyle = alpha(c.close >= c.open ? C.up : C.down, 0.8);
    ctx.setLineDash([1, 3]);
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW(), y); ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawCrosshair(): void {
    const m = this.mouse;
    if (!m || m.x > this.plotW() || m.y > this.plotH()) return;
    const ctx = this.ctx;
    const i = Math.round(this.indexAtX(m.x));
    const x = Math.round(this.x(i)) + 0.5;
    ctx.strokeStyle = C.cross;
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.plotH()); ctx.moveTo(0, Math.round(m.y) + 0.5); ctx.lineTo(this.plotW(), Math.round(m.y) + 0.5); ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawAxes(i0: number, i1: number): void {
    const ctx = this.ctx;
    const pw = this.plotW(), ph = this.plotH();
    ctx.fillStyle = C.axisBg;
    ctx.fillRect(pw, 0, AXIS_W, this.h);
    ctx.fillRect(0, ph, this.w, TIME_H);
    ctx.strokeStyle = C.border;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pw + 0.5, 0); ctx.lineTo(pw + 0.5, ph); ctx.lineTo(0, ph + 0.5); ctx.stroke();
    const step = niceStep((this.pMax - this.pMin) / Math.max(2, this.priceH() / 60));
    ctx.font = MONO;
    ctx.fillStyle = C.axisText;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (let p = Math.ceil(this.pMin / step) * step; p <= this.pMax; p += step) {
      const y = this.y(p);
      if (y < 6 || y > this.priceH() - 4) continue;
      ctx.fillText(fmtPrice(p, this.precision), pw + 6, y);
    }
    for (const t of this.timeTicks(i0, i1)) {
      const x = this.x(t.i);
      if (x < 10 || x > pw - 10) continue;
      this.label(t.label, x, ph + 13, t.major ? '#cbd5e1' : C.axisText, { align: 'center', font: t.major ? '600 11px ui-sans-serif, system-ui, sans-serif' : FONT });
    }
    // current price tag
    const last = this.candles[this.candles.length - 1];
    const col = last.close >= last.open ? C.up : C.down;
    const ly = this.y(last.close);
    if (ly > 0 && ly < this.priceH()) {
      ctx.fillStyle = col;
      ctx.fillRect(pw + 1, ly - 9, AXIS_W - 1, 18);
      this.label(fmtPrice(last.close, this.precision), pw + 6, ly, '#ffffff', { font: `600 ${MONO}` });
    }
    // selected setup level tags
    const sel = this.selectedSetupObj();
    if (sel && this.flags.setups) {
      const lv = this.levelsFor(sel);
      for (const [p, colr] of [[lv.take_profit, '#2563eb'], [lv.entry, '#16a34a'], [lv.stop_loss, '#e11d48']] as [number, string][]) {
        const y = this.y(p);
        if (y < 0 || y > this.priceH()) continue;
        ctx.fillStyle = colr;
        ctx.fillRect(pw + 1, y - 9, AXIS_W - 1, 18);
        this.label(fmtPrice(p, this.precision), pw + 6, y, '#ffffff', { font: MONO });
      }
    }
    // crosshair tags
    const m = this.mouse;
    if (m && m.x <= pw && m.y <= ph) {
      const price = this.priceAtY(m.y);
      ctx.fillStyle = '#334155';
      ctx.fillRect(pw + 1, m.y - 9, AXIS_W - 1, 18);
      this.label(fmtPrice(price, this.precision), pw + 6, m.y, '#f8fafc', { font: MONO });
      const i = Math.round(this.indexAtX(m.x));
      const c = this.candles[Math.min(Math.max(i, 0), this.candles.length - 1)];
      if (c) {
        const text = fmtDateTime(c.time, this.tz);
        ctx.font = FONT;
        const tw = ctx.measureText(text).width + 12;
        const x = Math.min(Math.max(this.x(i) - tw / 2, 0), pw - tw);
        ctx.fillStyle = '#334155';
        ctx.fillRect(x, ph + 2, tw, TIME_H - 4);
        this.label(text, x + tw / 2, ph + 13, '#f8fafc', { align: 'center' });
      }
    }
  }
}
