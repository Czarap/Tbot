import { useEffect, useRef, useState, type MouseEvent as RMouseEvent } from 'react';
import { fmtDate, fmtDateTime } from './format';
import type { DisplayTz } from '../types';

interface Props {
  points: { time: number; value: number }[];
  color?: string;
  fill?: boolean;
  height?: number;
  tz: DisplayTz;
  format?: (v: number) => string;
  baseline?: number;
  title?: string;
}

/** Small dependency-free canvas line/area chart (equity curve, drawdown). */
export function LineChart({ points, color = '#22c55e', fill = true, height = 160, tz, format = (v) => v.toFixed(2), baseline, title }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [w, setW] = useState(600);
  const [hover, setHover] = useState<{ x: number; i: number } | null>(null);

  useEffect(() => {
    if (!host.current) return;
    const ro = new ResizeObserver(() => setW(host.current!.clientWidth));
    ro.observe(host.current);
    return () => ro.disconnect();
  }, []);

  const pad = { l: 64, r: 10, t: 8, b: 20 };
  const xs = points.map((p) => p.time);
  const vs = points.map((p) => p.value);
  const t0 = Math.min(...xs), t1 = Math.max(...xs);
  let lo = Math.min(...vs, baseline ?? Infinity), hi = Math.max(...vs, baseline ?? -Infinity);
  if (hi === lo) { hi += 1; lo -= 1; }
  const X = (t: number) => pad.l + ((t - t0) / Math.max(1, t1 - t0)) * (w - pad.l - pad.r);
  const Y = (v: number) => pad.t + ((hi - v) / (hi - lo)) * (height - pad.t - pad.b);

  useEffect(() => {
    const cv = canvas.current;
    if (!cv || points.length < 2) return;
    const dpr = window.devicePixelRatio || 1;
    cv.width = w * dpr; cv.height = height * dpr;
    cv.style.width = `${w}px`; cv.style.height = `${height}px`;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, height);
    ctx.font = '10px ui-monospace, Menlo, monospace';
    ctx.fillStyle = '#64748b';
    ctx.strokeStyle = 'rgba(148,163,184,0.08)';
    for (let k = 0; k <= 4; k++) {
      const v = lo + ((hi - lo) * k) / 4;
      const y = Y(v);
      ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(format(v), pad.l - 6, y);
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (let k = 0; k <= 4; k++) {
      const t = t0 + ((t1 - t0) * k) / 4;
      ctx.fillText(fmtDate(t, tz), Math.min(w - 30, Math.max(pad.l + 20, X(t))), height - pad.b + 5);
    }
    if (baseline !== undefined) {
      ctx.strokeStyle = 'rgba(148,163,184,0.35)'; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(pad.l, Y(baseline)); ctx.lineTo(w - pad.r, Y(baseline)); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.beginPath();
    points.forEach((p, i) => (i ? ctx.lineTo(X(p.time), Y(p.value)) : ctx.moveTo(X(p.time), Y(p.value))));
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();
    if (fill) {
      const base = Y(baseline ?? lo);
      ctx.lineTo(X(points[points.length - 1].time), base); ctx.lineTo(X(points[0].time), base); ctx.closePath();
      ctx.fillStyle = color + '22'; ctx.fill();
    }
    if (hover) {
      const p = points[hover.i];
      ctx.strokeStyle = 'rgba(203,213,225,0.5)';
      ctx.beginPath(); ctx.moveTo(X(p.time), pad.t); ctx.lineTo(X(p.time), height - pad.b); ctx.stroke();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(X(p.time), Y(p.value), 3, 0, Math.PI * 2); ctx.fill();
    }
  });

  const onMove = (e: RMouseEvent) => {
    if (points.length < 2) return;
    const x = e.nativeEvent.offsetX;
    let best = 0, bd = Infinity;
    points.forEach((p, i) => { const d = Math.abs(X(p.time) - x); if (d < bd) { bd = d; best = i; } });
    setHover({ x, i: best });
  };

  return (
    <div ref={host} className="relative w-full" onMouseLeave={() => setHover(null)}>
      {title && <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-500">{title}</div>}
      {points.length < 2 ? <div className="grid h-24 place-items-center text-[12px] text-slate-500">Not enough data</div>
        : <canvas ref={canvas} onMouseMove={onMove} />}
      {hover && points[hover.i] && (
        <div className="pointer-events-none absolute right-2 top-5 rounded bg-slate-900/90 px-2 py-1 text-[11px] tabular-nums text-slate-200">
          {fmtDateTime(points[hover.i].time, tz)} · {format(points[hover.i].value)}
        </div>
      )}
    </div>
  );
}
