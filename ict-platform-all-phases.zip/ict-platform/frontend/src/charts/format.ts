import type { DisplayTz } from '../types';

const offsetCache = new Map<string, number>();

function resolveTz(tz: DisplayTz): string {
  if (tz === 'local') {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    } catch {
      return 'UTC';
    }
  }
  return tz;
}

const dtfCache = new Map<string, Intl.DateTimeFormat>();
function dtf(tz: string): Intl.DateTimeFormat {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
    dtfCache.set(tz, f);
  }
  return f;
}

/** UTC offset (seconds) of display time zone at UTC time t (seconds). Cached per UTC hour. */
export function tzOffset(t: number, tz: DisplayTz): number {
  const zone = resolveTz(tz);
  if (zone === 'UTC') return 0;
  const hour = Math.floor(t / 3600);
  const key = `${zone}|${hour}`;
  const hit = offsetCache.get(key);
  if (hit !== undefined) return hit;
  const parts = dtf(zone).formatToParts(new Date(hour * 3600 * 1000));
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour') % 24, get('minute'), get('second')) / 1000;
  const off = asUtc - hour * 3600;
  offsetCache.set(key, off);
  return off;
}

/** Wall-clock fields of t in the display tz. */
export function wall(t: number, tz: DisplayTz) {
  const d = new Date((t + tzOffset(t, tz)) * 1000);
  return {
    year: d.getUTCFullYear(), month: d.getUTCMonth(), day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), weekday: d.getUTCDay(),
    /** seconds since epoch of the local wall clock (for bucketing) */
    localSeconds: t + tzOffset(t, tz),
  };
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const pad = (n: number) => String(n).padStart(2, '0');

export function fmtTime(t: number, tz: DisplayTz): string {
  const w = wall(t, tz);
  return `${pad(w.hour)}:${pad(w.minute)}`;
}

export function fmtDate(t: number, tz: DisplayTz): string {
  const w = wall(t, tz);
  return `${MONTHS[w.month]} ${w.day}`;
}

export function fmtDateTime(t: number, tz: DisplayTz, withWeekday = true): string {
  const w = wall(t, tz);
  return `${withWeekday ? DAYS[w.weekday] + ' ' : ''}${MONTHS[w.month]} ${w.day} ${w.year} ${pad(w.hour)}:${pad(w.minute)}`;
}

export function tzLabel(tz: DisplayTz): string {
  if (tz === 'America/New_York') return 'New York';
  if (tz === 'UTC') return 'UTC';
  return resolveTz('local');
}

export function fmtPrice(p: number | null | undefined, precision = 2): string {
  if (p === null || p === undefined || !isFinite(p)) return '—';
  return p.toLocaleString('en-US', { minimumFractionDigits: precision, maximumFractionDigits: precision });
}

export function fmtNum(p: number, digits = 2): string {
  return p.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
