/**
 * Live connection to the backend: WebSocket first, Server-Sent Events fallback.
 *
 * - automatic reconnection with exponential back-off + jitter
 * - re-subscribes after every reconnect (the server then re-synchronises history)
 * - watchdog: if nothing arrives for 25 s the connection is treated as dead
 * - after two WebSocket failures without ever opening, switches to SSE
 */
import type { ICTSettings, LiveMessage, Timeframe } from '../types';

export interface LiveRequest {
  symbol: string;
  timeframe: Timeframe;
  provider?: string;
  limit: number;
  settings: ICTSettings;
}

export type TransportState = 'connecting' | 'open' | 'reconnecting';

export interface LiveHandlers {
  onMessage: (m: LiveMessage) => void;
  onTransport: (state: TransportState, info: { transport: 'websocket' | 'sse'; retryIn?: number; attempt: number }) => void;
}

function base(): string {
  const override = typeof window !== 'undefined' ? window.__ICT_API_BASE__ : undefined;
  return override ?? `${window.location.protocol}//${window.location.host}`;
}

export class LiveConnection {
  private h: LiveHandlers;
  private req: LiveRequest | null = null;
  private ws: WebSocket | null = null;
  private es: EventSource | null = null;
  private mode: 'websocket' | 'sse' = 'websocket';
  private wsFailuresBeforeOpen = 0;
  private attempt = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private ping: ReturnType<typeof setInterval> | null = null;
  private watchdog: ReturnType<typeof setInterval> | null = null;
  private lastMessage = 0;
  private closed = false;

  constructor(handlers: LiveHandlers) {
    this.h = handlers;
    this.watchdog = setInterval(() => {
      if (this.lastMessage && Date.now() - this.lastMessage > 25000 && (this.ws || this.es)) {
        this.lastMessage = 0;
        this.drop('no data for 25s');
      }
    }, 5000);
  }

  subscribe(req: LiveRequest): void {
    this.req = req;
    if (this.mode === 'websocket' && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ action: 'subscribe', ...req }));
      return;
    }
    if (this.mode === 'sse') {
      this.teardown();
      this.connect();
      return;
    }
    if (!this.ws) this.connect();
  }

  close(): void {
    this.closed = true;
    this.teardown();
    if (this.timer) clearTimeout(this.timer);
    if (this.watchdog) clearInterval(this.watchdog);
  }

  private connect(): void {
    if (this.closed || !this.req) return;
    this.h.onTransport('connecting', { transport: this.mode, attempt: this.attempt });
    if (this.mode === 'websocket' && typeof WebSocket !== 'undefined') this.connectWs();
    else this.connectSse();
  }

  private handle(raw: string): void {
    this.lastMessage = Date.now();
    let msg: LiveMessage;
    try { msg = JSON.parse(raw) as LiveMessage; } catch { return; }
    if (msg.type === 'hello') {
      this.attempt = 0;
      this.h.onTransport('open', { transport: this.mode, attempt: 0 });
    }
    this.h.onMessage(msg);
  }

  private connectWs(): void {
    const url = base().replace(/^http/, 'ws') + '/ws/live';
    let opened = false;
    const ws = new WebSocket(url);
    this.ws = ws;
    ws.onopen = () => {
      opened = true;
      this.wsFailuresBeforeOpen = 0;
      this.lastMessage = Date.now();
      if (this.req) ws.send(JSON.stringify({ action: 'subscribe', ...this.req }));
      this.ping = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send('{"action":"ping"}'); }, 15000);
    };
    ws.onmessage = (ev) => this.handle(String(ev.data));
    ws.onclose = () => {
      if (this.ws !== ws) return;
      if (!opened && ++this.wsFailuresBeforeOpen >= 2) this.mode = 'sse';
      this.drop('websocket closed');
    };
    ws.onerror = () => { /* onclose follows */ };
  }

  private connectSse(): void {
    const r = this.req!;
    const params = new URLSearchParams({ symbol: r.symbol, timeframe: r.timeframe, limit: String(r.limit), settings: JSON.stringify(r.settings) });
    if (r.provider) params.set('provider', r.provider);
    const es = new EventSource(`${base()}/api/live/stream?${params.toString()}`);
    this.es = es;
    es.onopen = () => { this.lastMessage = Date.now(); };
    es.onmessage = (ev) => this.handle(ev.data);
    es.onerror = () => { if (this.es === es) this.drop('event stream error'); };
  }

  private teardown(): void {
    if (this.ping) clearInterval(this.ping);
    this.ping = null;
    const ws = this.ws, es = this.es;
    this.ws = null;
    this.es = null;
    try { ws?.close(); } catch { /* ignore */ }
    try { es?.close(); } catch { /* ignore */ }
  }

  private drop(_reason: string): void {
    this.teardown();
    if (this.closed) return;
    this.attempt += 1;
    const delay = Math.min(30, 2 ** Math.min(this.attempt - 1, 5)) * (0.75 + Math.random() * 0.5);
    this.h.onTransport('reconnecting', { transport: this.mode, retryIn: delay, attempt: this.attempt });
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => this.connect(), delay * 1000);
  }
}
