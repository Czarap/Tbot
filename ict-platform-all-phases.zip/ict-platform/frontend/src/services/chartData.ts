import type { Analysis, AnalysisResponse, BacktestResult, ICTSettings } from '../types';

export const EMPTY_ANALYSIS: Analysis = {
  swings: [], structure_events: [], liquidity_levels: [], sweeps: [], fvgs: [], displacements: [], order_blocks: [], sessions: [],
  dealing_range: null, setups: [],
  summary: { trend: null, htf_timeframe: null, htf_bias: null, htf_candle_time: null, last_structure_event: null, price: null, atr: null,
    zone: null, nearest_buy_side: [], nearest_sell_side: [], active_fvgs: 0, active_order_blocks: 0, setup_rejections: {}, candles_analysed: 0 },
};

/** Wrap backtest candles so the regular chart component can display them with trade markers. */
export function backtestChartData(r: BacktestResult): AnalysisResponse {
  return {
    symbol: r.config.symbol, timeframe: r.config.timeframe, symbol_info: r.symbol_info, provider: r.provider,
    source_timeframe: r.config.timeframe, data_quality: {} as AnalysisResponse['data_quality'], settings: r.config.settings as ICTSettings,
    candles: r.candles, forming: null, analysis: EMPTY_ANALYSIS, warmup_candles: 0, compute_ms: r.compute_ms, generated_at: 0, disclaimer: r.disclaimer,
  };
}
