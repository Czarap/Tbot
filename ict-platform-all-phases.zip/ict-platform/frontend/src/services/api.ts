import type { AnalysisResponse, ICTSettings, MetaResponse, Timeframe } from '../types';

/**
 * Snapshot mode: the static demo build embeds pre-computed backend output in
 * `window.__ICT_SNAPSHOT__` so the UI can be viewed without a running server.
 * Everything shown is real engine output; only recomputation is unavailable.
 */
export interface Snapshot {
  meta: MetaResponse;
  analyses: Partial<Record<Timeframe, AnalysisResponse>>;
  created_at: number;
}

declare global {
  interface Window { __ICT_SNAPSHOT__?: Snapshot; __ICT_API_BASE__?: string }
}

export const snapshot: Snapshot | null = typeof window !== 'undefined' ? window.__ICT_SNAPSHOT__ ?? null : null;
export const isSnapshot = snapshot !== null;

/** Same origin by default (backend serves the UI). Override for a separately hosted UI. */
const API_BASE = typeof window !== 'undefined' ? window.__ICT_API_BASE__ ?? '' : '';

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) } });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail);
    } catch { /* keep statusText */ }
    throw new Error(`${res.status}: ${detail}`);
  }
  return res.json() as Promise<T>;
}

export async function fetchMeta(): Promise<MetaResponse> {
  if (snapshot) return snapshot.meta;
  return http<MetaResponse>('/api/meta');
}

export async function fetchAnalysis(args: { symbol: string; timeframe: Timeframe; limit: number; provider?: string; settings: ICTSettings }): Promise<AnalysisResponse> {
  if (snapshot) {
    const a = snapshot.analyses[args.timeframe];
    if (!a) throw new Error(`Timeframe ${args.timeframe} is not included in this static demo.`);
    return a;
  }
  return http<AnalysisResponse>('/api/analysis', { method: 'POST', body: JSON.stringify(args) });
}

// ------------------------------------------------------------- phases 2-5
import type {
  BacktestConfig, BacktestResult, CalendarResponse, Job, MTFResponse, OptimizeGrid, Profile, ReplayState, RunSummary,
} from '../types';

export const api = {
  mtf: (symbol: string, provider: string | undefined, settings: ICTSettings) =>
    http<MTFResponse>('/api/mtf', { method: 'POST', body: JSON.stringify({ symbol, provider, settings }) }),
  calendar: (start: number, end: number, currencies = 'USD', importance: 'medium' | 'high' = 'high') =>
    http<CalendarResponse>(`/api/calendar?start=${Math.floor(start)}&end=${Math.floor(end)}&currencies=${currencies}&importance=${importance}`),
  startBacktest: (cfg: BacktestConfig) => http<Job>('/api/backtest', { method: 'POST', body: JSON.stringify(cfg) }),
  startOptimize: (body: { base: BacktestConfig; grid: OptimizeGrid; train: number; validation: number; min_trades: number; walk_forward_folds: number; top_n: number }) =>
    http<Job>('/api/optimize', { method: 'POST', body: JSON.stringify(body) }),
  job: <T>(id: string, result = false) => http<Job<T>>(`/api/jobs/${id}${result ? '?result=true' : ''}`),
  cancelJob: (id: string) => http<{ cancelled: boolean }>(`/api/jobs/${id}`, { method: 'DELETE' }),
  runs: () => http<{ runs: RunSummary[] }>('/api/runs'),
  run: (id: string) => http<Partial<BacktestResult> & { id: string; trades: BacktestResult['trades'] }>(`/api/runs/${id}`),
  deleteRun: (id: string) => http<unknown>(`/api/runs/${id}`, { method: 'DELETE' }),
  setNote: (runId: string, tradeId: string, notes: string) =>
    http<unknown>(`/api/journal/${runId}/${tradeId}`, { method: 'PATCH', body: JSON.stringify({ notes }) }),
  profiles: () => http<{ profiles: Profile[] }>('/api/profiles'),
  saveProfile: (name: string, settings: ICTSettings, backtest?: Partial<BacktestConfig>) =>
    http<Profile>('/api/profiles', { method: 'POST', body: JSON.stringify({ name, settings, backtest: backtest ?? null }) }),
  deleteProfile: (id: number) => http<unknown>(`/api/profiles/${id}`, { method: 'DELETE' }),
  replayStart: (body: { symbol: string; timeframe: Timeframe; provider?: string; start: string; limit: number; settings: ICTSettings }) =>
    http<ReplayState>('/api/replay/start', { method: 'POST', body: JSON.stringify(body) }),
  replayStep: (id: string, n = 1) => http<ReplayState>(`/api/replay/${id}/step`, { method: 'POST', body: JSON.stringify({ n }) }),
  replayBack: (id: string, n = 1) => http<ReplayState>(`/api/replay/${id}/back`, { method: 'POST', body: JSON.stringify({ n }) }),
  replayStop: (id: string) => http<unknown>(`/api/replay/${id}`, { method: 'DELETE' }),
  upload: async (file: File, symbol: string, timeframe: string, tz: string) => {
    const res = await fetch(`${API_BASE}/api/data/upload?symbol=${symbol}&timeframe=${timeframe}&tz=${encodeURIComponent(tz)}`, { method: 'POST', body: file });
    const body = await res.json();
    if (!res.ok) throw new Error(typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail));
    return body as { saved: string; rows: number; first: number; last: number };
  },
};

/** Poll a job until it finishes. */
export async function waitForJob<T>(id: string, onProgress: (j: Job<T>) => void, signal?: { cancelled: boolean }): Promise<Job<T>> {
  for (;;) {
    if (signal?.cancelled) throw new Error('cancelled');
    const j = await api.job<T>(id);
    onProgress(j);
    if (j.state === 'done') return api.job<T>(id, true);
    if (j.state === 'error' || j.state === 'cancelled') throw new Error(j.error ?? j.state);
    await new Promise((r) => setTimeout(r, 600));
  }
}
