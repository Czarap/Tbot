import { useEffect, useRef, useState } from 'react';
import type { AnalysisResponse, Setup } from '../types';
import { loadLS, saveLS } from '../components/ui';

export interface AlertSettings { enabled: boolean; browser: boolean; sound: boolean; minScore: number; directions: ('bullish' | 'bearish')[] }
export interface AlertItem { id: string; at: number; setup: Setup; symbol: string; timeframe: string }

const DEFAULTS: AlertSettings = { enabled: true, browser: false, sound: true, minScore: 6, directions: ['bullish', 'bearish'] };

function beep() {
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = 880; g.gain.value = 0.05;
    o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.18);
  } catch { /* audio unavailable */ }
}

/** Alerts for NEW possible setups on the live chart. Alerts never execute trades. */
export function useSetupAlerts(data: AnalysisResponse | null, active: boolean) {
  const [settings, setSettingsState] = useState<AlertSettings>(() => ({ ...DEFAULTS, ...loadLS<Partial<AlertSettings>>('alerts', {}) }));
  const [items, setItems] = useState<AlertItem[]>([]);
  const seen = useRef<Set<string>>(new Set());
  const key = useRef('');
  const setSettings = (s: AlertSettings) => { setSettingsState(s); saveLS('alerts', s); };

  useEffect(() => {
    if (!data || !active) return;
    const k = `${data.symbol}|${data.timeframe}`;
    const ids = data.analysis.setups.map((s) => s.id);
    if (k !== key.current) { key.current = k; seen.current = new Set(ids); return; } // existing setups are not "new"
    const tf = data.candles.length > 1 ? data.candles[1][0] - data.candles[0][0] : 60;
    const lastT = data.candles.length ? data.candles[data.candles.length - 1][0] : 0;
    const fresh = data.analysis.setups.filter((s) => !seen.current.has(s.id) && s.time >= lastT - 2 * tf);
    ids.forEach((id) => seen.current.add(id));
    if (!settings.enabled) return;
    for (const s of fresh) {
      if (s.score < settings.minScore || !settings.directions.includes(s.direction)) continue;
      const item = { id: s.id, at: Date.now(), setup: s, symbol: data.symbol, timeframe: data.timeframe };
      setItems((cur) => [item, ...cur].slice(0, 20));
      if (settings.sound) beep();
      if (settings.browser && typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        try {
          new Notification(`${data.symbol} ${data.timeframe.toUpperCase()} — ${s.label}`, {
            body: `Confluence ${s.score}/${s.max_score} · hypothetical entry ${s.entry} · SL ${s.stop_loss} · TP ${s.take_profit}\nAnalysis only — no order was placed.`,
            tag: s.id,
          });
        } catch { /* notifications unavailable */ }
      }
    }
  }, [data, active, settings]);

  const requestPermission = async () => {
    if (typeof Notification === 'undefined') return 'unsupported';
    const p = await Notification.requestPermission();
    if (p === 'granted') setSettings({ ...settings, browser: true });
    return p;
  };
  return { settings, setSettings, items, dismiss: (id: string) => setItems((c) => c.filter((x) => x.id !== id)), requestPermission };
}
