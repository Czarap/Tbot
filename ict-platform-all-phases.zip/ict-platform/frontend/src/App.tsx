import { useEffect, useState } from 'react';
import { AppNav, type Page } from './components/AppNav';
import { loadLS } from './components/ui';
import { BacktestPage } from './pages/BacktestPage';
import { JournalPage } from './pages/JournalPage';
import { OptimizerPage } from './pages/OptimizerPage';
import { TradingPage } from './pages/TradingPage';
import { fetchMeta, isSnapshot } from './services/api';
import type { DisplayTz, MetaResponse } from './types';

const VALID: Page[] = ['chart', 'backtest', 'optimizer', 'journal'];
const fromHash = (): Page => {
  const h = (typeof window !== 'undefined' ? window.location.hash.slice(1) : '') as Page;
  return VALID.includes(h) && !isSnapshot ? h : 'chart';
};

export default function App() {
  const [page, setPage] = useState<Page>(fromHash);
  const [meta, setMeta] = useState<MetaResponse | null>(null);
  const tz = loadLS<DisplayTz>('tz', 'America/New_York');

  useEffect(() => {
    const f = () => setPage(fromHash());
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  useEffect(() => { if (page !== 'chart' && !meta) fetchMeta().then(setMeta).catch(() => undefined); }, [page, meta]);

  const go = (p: Page) => {
    setPage(p);
    try { window.history.replaceState(null, '', p === 'chart' ? window.location.pathname : `#${p}`); } catch { /* ignore */ }
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#0b0e14] text-slate-200 md:h-screen md:min-h-0">
      <AppNav page={page} onPage={go} staticDemo={isSnapshot} />
      {/* the chart page stays mounted so the live connection survives page switches */}
      <div className={page === 'chart' ? 'flex min-h-0 flex-1 flex-col' : 'hidden'}><TradingPage active={page === 'chart'} /></div>
      {page === 'backtest' && <BacktestPage meta={meta} tz={tz} />}
      {page === 'optimizer' && <OptimizerPage meta={meta} tz={tz} onBacktest={() => go('backtest')} />}
      {page === 'journal' && <JournalPage tz={tz} />}
    </div>
  );
}
