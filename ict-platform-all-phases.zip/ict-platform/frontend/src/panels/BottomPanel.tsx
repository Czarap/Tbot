import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { fmtDateTime, fmtPrice } from '../charts/format';
import type { AnalysisResponse, DisplayTz } from '../types';

export type BottomTab = 'setups' | 'log' | 'data' | 'extra';

interface Props {
  data: AnalysisResponse;
  tz: DisplayTz;
  selectedSetup: string | null;
  onSelectSetup: (id: string) => void;
  onFocus: (t: number) => void;
  extraTab?: { label: string; content: ReactNode };
  extraTabsBefore?: { id: string; label: string; content: ReactNode }[];
  requestTab?: { id: string; nonce: number } | null;
}

export function BottomPanel({ data, tz, selectedSetup, onSelectSetup, onFocus, extraTab, extraTabsBefore = [], requestTab }: Props) {
  const [tab, setTab] = useState<string>(extraTabsBefore[0]?.id ?? 'setups');
  useEffect(() => { if (requestTab && (requestTab.id !== 'analysis-mobile' || extraTabsBefore.length)) setTab(requestTab.id); }, [requestTab]); // eslint-disable-line react-hooks/exhaustive-deps
  const a = data.analysis;
  const prec = data.symbol_info.price_precision;

  const log = useMemo(() => {
    const items = [
      ...a.structure_events.map((e) => ({ t: e.time, kind: e.type, dir: e.direction, text: e.explanation.slice(1).join(' · ') })),
      ...a.sweeps.map((s) => ({ t: s.time, kind: 'Sweep', dir: s.implication, text: `${s.level_label} ${fmtPrice(s.level_price, prec)} — wick ${fmtPrice(s.extreme, prec)}, close ${fmtPrice(s.close, prec)}` })),
      ...a.displacements.map((d) => ({ t: d.time, kind: 'Displacement', dir: d.direction, text: d.explanation.slice(1).join(' · ') })),
    ];
    return items.sort((x, y) => y.t - x.t).slice(0, 400);
  }, [a, prec]);

  const q = data.data_quality;
  const tabs: { id: string; label: string }[] = [
    ...extraTabsBefore.map((t) => ({ id: t.id, label: t.label })),
    { id: 'setups', label: `Setups (${a.setups.length})` },
    { id: 'log', label: 'Event log' },
    { id: 'data', label: 'Data' },
    ...(extraTab ? [{ id: 'extra', label: extraTab.label }] : []),
  ];

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex shrink-0 gap-1 overflow-x-auto border-b border-[#1e2533] px-2">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`whitespace-nowrap border-b-2 px-2.5 py-1.5 text-[12px] ${tab === t.id ? 'border-amber-500 text-slate-100' : 'border-transparent text-slate-400 hover:text-slate-200'}`}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-auto">
        {extraTabsBefore.map((t) => tab === t.id && <div key={t.id}>{t.content}</div>)}
        {tab === 'extra' && extraTab?.content}
        {tab === 'setups' && (
          a.setups.length === 0 ? <p className="p-3 text-[12px] text-slate-500">No possible setups in this window with the current rules. See the Data tab for why candidates were rejected.</p> : (
            <table className="w-full text-[11.5px] tabular-nums">
              <thead className="sticky top-0 bg-[#0f131b] text-left text-[10.5px] uppercase tracking-wide text-slate-500">
                <tr>{['Time', 'Direction', 'Score', 'Entry', 'Stop', 'Target', 'R:R', 'Session', 'HTF'].map((h) => <th key={h} className="px-2 py-1 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {[...a.setups].reverse().map((s) => (
                  <tr key={s.id} onClick={() => onSelectSetup(s.id)} className={`cursor-pointer border-t border-[#161c27] hover:bg-[#141a24] ${s.id === selectedSetup ? 'bg-[#18202e]' : ''}`}>
                    <td className="px-2 py-1 text-slate-400">{fmtDateTime(s.time, tz, false)}</td>
                    <td className={`px-2 py-1 font-semibold ${s.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}`}>{s.direction === 'bullish' ? 'Possible Long' : 'Possible Short'}</td>
                    <td className="px-2 py-1 text-amber-300">{s.score}/{s.max_score}</td>
                    <td className="px-2 py-1">{fmtPrice(s.entry, prec)}</td>
                    <td className="px-2 py-1 text-rose-300/90">{fmtPrice(s.stop_loss, prec)}</td>
                    <td className="px-2 py-1 text-sky-300/90">{fmtPrice(s.take_profit, prec)}</td>
                    <td className="px-2 py-1">1:{s.rr.toFixed(2)}</td>
                    <td className="px-2 py-1 text-slate-400">{s.session ?? '—'}</td>
                    <td className="px-2 py-1 text-slate-400">{s.htf_bias ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}
        {tab === 'log' && (
          <ul className="divide-y divide-[#161c27] text-[11.5px]">
            {log.map((it, i) => (
              <li key={i} onClick={() => onFocus(it.t)} className="grid cursor-pointer grid-cols-[150px_95px_1fr] gap-2 px-2 py-1 hover:bg-[#141a24] max-sm:grid-cols-[1fr] max-sm:gap-0">
                <span className="tabular-nums text-slate-500">{fmtDateTime(it.t, tz, false)}</span>
                <span className={it.dir === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}>{it.kind} {it.dir === 'bullish' ? '▲' : '▼'}</span>
                <span className="text-slate-400">{it.text}</span>
              </li>
            ))}
          </ul>
        )}
        {tab === 'data' && (
          <div className="grid gap-4 p-3 text-[11.5px] text-slate-400 md:grid-cols-3">
            <div>
              <h4 className="panel-h">Source</h4>
              <div className="text-slate-200">{data.provider.name}</div>
              <div>{data.provider.description}</div>
              {data.provider.warning && <div className="mt-1 text-orange-300">{data.provider.warning}</div>}
              <div className="mt-1">Built from {data.source_timeframe} candles · {data.candles.length} shown + {data.warmup_candles} warm-up · {data.compute_ms} ms</div>
            </div>
            <div>
              <h4 className="panel-h">Data quality</h4>
              <div>Rows in / out: {q.rows_in.toLocaleString()} / {q.rows_out.toLocaleString()}</div>
              <div>Invalid rows removed: {q.invalid_rows_removed} · duplicates removed: {q.duplicates_removed}</div>
              <div>OHLC fixed: {q.ohlc_fixed} · gaps: {q.gaps_total} (unexpected {q.gaps_unexpected})</div>
              {q.unexpected_gap_samples.slice(0, 3).map((g, i) => <div key={i} className="text-amber-300/80">Gap after {fmtDateTime(g.after_time, tz)} ({Math.round(g.missing_seconds / 60)} min)</div>)}
            </div>
            <div>
              <h4 className="panel-h">Setup candidates rejected</h4>
              {Object.entries(a.summary.setup_rejections).length === 0 && <div>None</div>}
              {Object.entries(a.summary.setup_rejections).sort((x, y) => y[1] - x[1]).map(([k, v]) => <div key={k}>{v} × {k}</div>)}
              <div className="mt-1 text-slate-500">(counts include the warm-up period)</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
