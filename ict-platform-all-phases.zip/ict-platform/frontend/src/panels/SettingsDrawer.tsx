import { useEffect, useState, type ReactNode } from 'react';
import { DataSources } from '../components/DataImport';
import { api } from '../services/api';
import type { ICTSettings, MetaResponse, Profile, RuleMode, Timeframe } from '../types';

interface Props {
  open: boolean;
  settings: ICTSettings;
  defaults: ICTSettings | null;
  readOnly: boolean;
  onApply: (s: ICTSettings) => void;
  onClose: () => void;
  meta?: MetaResponse | null;
}

type Path = (string | number)[];

function getIn(o: unknown, path: Path): unknown {
  return path.reduce<unknown>((acc, k) => (acc as Record<string | number, unknown>)[k], o);
}
function setIn<T>(o: T, path: Path, v: unknown): T {
  const copy = structuredClone(o) as Record<string | number, unknown>;
  let cur = copy;
  for (let i = 0; i < path.length - 1; i++) cur = cur[path[i]] as Record<string | number, unknown>;
  cur[path[path.length - 1]] = v;
  return copy as T;
}

const RULES: { key: keyof ICTSettings['setups']['rules']; label: string }[] = [
  { key: 'htf_bias', label: 'HTF bias aligned' },
  { key: 'liquidity_sweep', label: 'Liquidity sweep' },
  { key: 'order_block', label: 'Order block from the same move' },
  { key: 'structure_shift', label: 'BOS / CHoCH after sweep' },
  { key: 'displacement', label: 'Displacement' },
  { key: 'premium_discount', label: 'Discount (long) / premium (short)' },
  { key: 'session', label: 'Inside selected session' },
  { key: 'liquidity_target', label: 'Liquidity target ≥ min R:R' },
  { key: 'news', label: 'No high-impact news nearby' },
];

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="border-b border-[#1e2533] px-4 py-3">
      <h3 className="panel-h mb-2">{title}</h3>
      <div className="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-2">{children}</div>
    </section>
  );
}

function Profiles({ draft, onLoad, readOnly }: { draft: ICTSettings; onLoad: (s: ICTSettings) => void; readOnly: boolean }) {
  const [list, setList] = useState<Profile[]>([]);
  const [name, setName] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => { if (!readOnly) api.profiles().then((r) => setList(r.profiles)).catch(() => undefined); }, [readOnly]);
  if (readOnly) return null;
  return (
    <section className="border-b border-[#1e2533] px-4 py-3">
      <h3 className="panel-h mb-2">Strategy profiles</h3>
      <div className="flex flex-wrap gap-1.5">
        <select className="tb-select max-w-[180px]" value="" onChange={(e) => { const p = list.find((x) => String(x.id) === e.target.value); if (p) { onLoad(p.settings); setName(p.name); setMsg(`Loaded "${p.name}" — press Apply.`); } }}>
          <option value="">Load profile…</option>{list.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input className="lv-input w-40 !text-left" placeholder="e.g. London Sweep Strategy" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="tb-btn" disabled={!name.trim()} onClick={() => api.saveProfile(name.trim(), draft).then((p) => { setList((l) => [...l.filter((x) => x.id !== p.id), p].sort((a, b) => a.name.localeCompare(b.name))); setMsg(`Saved "${p.name}".`); }).catch((e: Error) => setMsg(e.message))}>Save</button>
        {list.some((p) => p.name === name.trim()) && (
          <button className="tb-btn" onClick={() => { const p = list.find((x) => x.name === name.trim())!; api.deleteProfile(p.id).then(() => { setList((l) => l.filter((x) => x.id !== p.id)); setMsg(`Deleted "${p.name}".`); }); }}>Delete</button>
        )}
      </div>
      {msg && <p className="mt-1 text-[11px] text-slate-400">{msg}</p>}
    </section>
  );
}

export function SettingsDrawer({ open, settings, defaults, readOnly, onApply, onClose, meta }: Props) {
  const [draft, setDraft] = useState(settings);
  useEffect(() => { if (open) setDraft(settings); }, [open, settings]);
  if (!open) return null;

  const num = (path: Path, label: string, opts: { step?: number; min?: number; max?: number; hint?: string } = {}) => (
    <>
      <label className="text-slate-300" title={opts.hint}>{label}{opts.hint && <span className="block text-[10.5px] leading-4 text-slate-500">{opts.hint}</span>}</label>
      <input type="number" className="lv-input w-24" disabled={readOnly} step={opts.step ?? 1} min={opts.min} max={opts.max}
        value={getIn(draft, path) as number} onChange={(e) => setDraft(setIn(draft, path, Number(e.target.value)))} />
    </>
  );
  const bool = (path: Path, label: string) => (
    <>
      <label className="text-slate-300">{label}</label>
      <input type="checkbox" className="h-4 w-4 accent-amber-500" disabled={readOnly} checked={getIn(draft, path) as boolean}
        onChange={(e) => setDraft(setIn(draft, path, e.target.checked))} />
    </>
  );
  const sel = (path: Path, label: string, options: [string, string][], numeric = false) => (
    <>
      <label className="text-slate-300">{label}</label>
      <select className="tb-select" disabled={readOnly} value={String(getIn(draft, path) ?? '')}
        onChange={(e) => setDraft(setIn(draft, path, e.target.value === '' ? null : numeric ? Number(e.target.value) : e.target.value))}>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </>
  );

  const sessions = draft.sessions.sessions;
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50" onClick={onClose}>
      <div className="flex h-full w-full max-w-[440px] flex-col border-l border-[#1e2533] bg-[#0f131b] text-[12px] shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[#1e2533] px-4 py-3">
          <h2 className="text-[14px] font-semibold text-slate-100">Detection & setup settings</h2>
          <button onClick={onClose} className="rounded px-2 py-0.5 text-slate-400 hover:bg-[#1a2230]" aria-label="Close settings">✕</button>
        </div>
        {readOnly && (
          <div className="border-b border-sky-500/20 bg-sky-500/10 px-4 py-2 text-[11.5px] leading-4 text-sky-200">
            This static demo shows pre-computed results with the default rules. Run the backend locally to change these and re-run the analysis.
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto">
          <Profiles draft={draft} onLoad={setDraft} readOnly={readOnly} />
          <Section title="Market structure">
            {sel(['structure', 'swing_length'], 'Swing sensitivity', ['1', '2', '3', '4', '5', '7', '10', '15', '20'].map((v) => [v, v]), true)}
            {sel(['structure', 'break_confirmation'], 'BOS / CHoCH confirmation', [['close', 'Candle close'], ['wick', 'Wick']])}
            {num(['atr_period'], 'ATR period', { min: 2, max: 200 })}
          </Section>
          <Section title="Liquidity">
            {bool(['liquidity', 'include_swing_levels'], 'Swing highs / lows')}
            {bool(['liquidity', 'include_equal_levels'], 'Equal highs / lows')}
            {num(['liquidity', 'equal_tolerance_atr'], 'Equal-level tolerance (× ATR)', { step: 0.01, min: 0, max: 2 })}
            {bool(['liquidity', 'include_previous_day'], 'Previous day high / low')}
            {bool(['liquidity', 'include_previous_week'], 'Previous week high / low')}
            {bool(['liquidity', 'include_session_levels'], 'Session highs / lows')}
          </Section>
          <Section title="Fair value gaps">
            {num(['fvg', 'min_size'], 'Minimum size (price)', { step: 0.01, min: 0 })}
            {num(['fvg', 'min_size_atr'], 'Minimum size (× ATR)', { step: 0.05, min: 0, max: 5, hint: 'The larger of the two minimums applies.' })}
          </Section>
          <Section title="Displacement">
            {num(['displacement', 'range_atr_mult'], 'Candle range ≥ (× ATR)', { step: 0.1, min: 0.5, max: 10 })}
            {num(['displacement', 'body_ratio'], 'Body ≥ fraction of range', { step: 0.05, min: 0.1, max: 1 })}
            {bool(['displacement', 'multi_candle_enabled'], 'Also detect multi-candle moves')}
            {num(['displacement', 'multi_candle_count'], 'Consecutive candles', { min: 2, max: 10 })}
            {num(['displacement', 'multi_candle_atr_mult'], 'Combined body ≥ (× ATR)', { step: 0.1, min: 0.5, max: 20 })}
            {bool(['displacement', 'require_structure_break'], 'Require structure break')}
          </Section>
          <Section title="Order blocks">
            {bool(['order_blocks', 'enabled'], 'Detect order blocks')}
            {sel(['order_blocks', 'zone'], 'Zone', [['wick', 'Full candle (wick)'], ['body', 'Body only']])}
            {num(['order_blocks', 'lookback_bars'], 'Look-back from the break (candles)', { min: 2, max: 200 })}
          </Section>
          <Section title="Premium / discount">
            {sel(['dealing_range', 'source'], 'Dealing range from', [['swings', 'Latest swing high / low'], ['previous_day', 'Previous day high / low']])}
          </Section>
          <Section title={`Sessions (${draft.sessions.timezone})`}>
            {sessions.map((s, i) => (
              <div key={s.name} className="col-span-2 grid grid-cols-[auto_1fr_auto_auto] items-center gap-2">
                <input type="checkbox" className="h-4 w-4 accent-amber-500" disabled={readOnly} checked={s.enabled}
                  onChange={(e) => setDraft(setIn(draft, ['sessions', 'sessions', i, 'enabled'], e.target.checked))} />
                <span style={{ color: s.color }}>{s.name}</span>
                <input type="time" className="lv-input w-[92px]" disabled={readOnly} value={s.start} onChange={(e) => setDraft(setIn(draft, ['sessions', 'sessions', i, 'start'], e.target.value))} />
                <input type="time" className="lv-input w-[92px]" disabled={readOnly} value={s.end} onChange={(e) => setDraft(setIn(draft, ['sessions', 'sessions', i, 'end'], e.target.value))} />
              </div>
            ))}
          </Section>
          <Section title="Multi-timeframe roles">
            {(['bias', 'structure', 'setup', 'entry'] as const).map((role) =>
              sel(['mtf', role], role[0].toUpperCase() + role.slice(1), (['1m', '5m', '15m', '30m', '1h', '4h', '1d'] as Timeframe[]).map((t) => [t, t] as [string, string])))}
          </Section>
          <Section title="News filter (economic calendar)">
            {num(['setups', 'news_minutes_before'], 'Minutes before a release', { min: 0, max: 1440 })}
            {num(['setups', 'news_minutes_after'], 'Minutes after a release', { min: 0, max: 1440 })}
            <p className="col-span-2 text-[10.5px] leading-4 text-slate-500">High-impact USD events (CPI, NFP, FOMC, rates, PPI, GDP, Fed speakers). Set the rule mode below; when no calendar data covers a setup the rule is shown as pending and not scored.</p>
          </Section>
          <Section title="Setup rules">
            {RULES.map((r) => (
              <div key={r.key} className="col-span-2 grid grid-cols-[1fr_auto] items-center gap-2">
                <span className="text-slate-300">{r.label}</span>
                <div className="flex overflow-hidden rounded border border-[#263042]">
                  {(['required', 'scored', 'off'] as RuleMode[]).map((m) => (
                    <button key={m} disabled={readOnly} onClick={() => setDraft(setIn(draft, ['setups', 'rules', r.key], m))}
                      className={`px-2 py-0.5 text-[11px] ${draft.setups.rules[r.key] === m ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:bg-[#1a2230]'}`}>{m}</button>
                  ))}
                </div>
              </div>
            ))}
            {num(['setups', 'min_score'], 'Minimum confluence score', { min: 0, max: 10 })}
            {num(['setups', 'min_rr'], 'Minimum R:R', { step: 0.25, min: 0.5, max: 20 })}
            {sel(['setups', 'confirmation'], 'Entry confirmation', [['rejection', 'Rejection candle'], ['hold', 'Close holds FVG']])}
            {num(['setups', 'sweep_lookback_bars'], 'Sweep look-back (candles)', { min: 1, max: 200 })}
            {num(['setups', 'max_retrace_bars'], 'Max candles until FVG retrace', { min: 1, max: 500 })}
            {num(['setups', 'sl_buffer_atr'], 'Stop buffer (× ATR)', { step: 0.05, min: 0, max: 5 })}
            {num(['setups', 'min_risk_atr'], 'Minimum stop distance (× ATR)', { step: 0.05, min: 0, max: 5 })}
            {bool(['setups', 'one_setup_per_sweep'], 'One setup per sweep')}
            {sel(['setups', 'htf_timeframe'], 'HTF for bias', [['', 'Automatic'], ...(['5m', '15m', '30m', '1h', '4h', '1d'] as Timeframe[]).map((t) => [t, t] as [string, string])])}
            <label className="text-slate-300">Setup sessions</label>
            <div className="flex flex-wrap justify-end gap-1">
              {sessions.map((s) => {
                const on = draft.setups.setup_sessions.includes(s.name);
                return (
                  <button key={s.name} disabled={readOnly}
                    onClick={() => setDraft(setIn(draft, ['setups', 'setup_sessions'], on ? draft.setups.setup_sessions.filter((x) => x !== s.name) : [...draft.setups.setup_sessions, s.name]))}
                    className={`rounded border px-1.5 py-0.5 text-[11px] ${on ? 'border-amber-500/60 bg-amber-500/15 text-amber-200' : 'border-[#263042] text-slate-500'}`}>{on ? '☑' : '☐'} {s.name}</button>
                );
              })}
            </div>
          </Section>
          {!readOnly && (
            <section className="border-b border-[#1e2533] px-4 py-3">
              <h3 className="panel-h mb-2">Data providers</h3>
              <DataSources meta={meta ?? null} />
            </section>
          )}
        </div>
        <div className="flex items-center gap-2 border-t border-[#1e2533] px-4 py-3">
          <button className="tb-btn" disabled={readOnly || !defaults} onClick={() => defaults && setDraft(defaults)}>Reset to defaults</button>
          <div className="flex-1" />
          <button className="tb-btn" onClick={onClose}>Cancel</button>
          <button className="rounded-md bg-amber-500 px-3 py-1.5 text-[12px] font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-40" disabled={readOnly}
            onClick={() => { onApply(draft); onClose(); }}>Apply & re-analyse</button>
        </div>
      </div>
    </div>
  );
}
