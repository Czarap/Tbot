import { fmtDateTime, fmtPrice } from '../charts/format';
import type { DisplayTz, EditedLevels, Setup } from '../types';

interface Props {
  setup: Setup;
  precision: number;
  tz: DisplayTz;
  edited: EditedLevels | undefined;
  onEdit: (lv: EditedLevels | undefined) => void;
  onClose: () => void;
  onFocus: (t: number) => void;
}

function Mark({ passed, mode }: { passed: boolean | null; mode: string }) {
  if (mode === 'pending') return <span className="text-slate-500">…</span>;
  if (mode === 'off') return <span className="text-slate-600">–</span>;
  return passed ? <span className="text-emerald-400">✓</span> : <span className="text-rose-400">✗</span>;
}

export function SetupDetail({ setup: s, precision, tz, edited, onEdit, onClose, onFocus }: Props) {
  const lv = edited ?? { entry: s.entry, stop_loss: s.stop_loss, take_profit: s.take_profit };
  const long = s.direction === 'bullish';
  const risk = long ? lv.entry - lv.stop_loss : lv.stop_loss - lv.entry;
  const reward = long ? lv.take_profit - lv.entry : lv.entry - lv.take_profit;
  const valid = risk > 0 && reward > 0;
  const rr = valid ? reward / risk : 0;
  const step = Math.pow(10, -precision);
  const set = (k: keyof EditedLevels, v: string) => {
    const n = Number(v);
    if (!isFinite(n)) return;
    onEdit({ ...lv, [k]: n });
  };

  return (
    <div className="flex flex-col gap-3 p-3 text-[12px] text-slate-300">
      <div className="flex items-start justify-between">
        <div>
          <div className={`text-[13px] font-bold tracking-wide ${long ? 'text-emerald-300' : 'text-rose-300'}`}>{s.label}</div>
          <div className="text-[11px] text-slate-500">{s.symbol} · {s.timeframe.toUpperCase()} · {fmtDateTime(s.time, tz)}</div>
        </div>
        <button onClick={onClose} className="rounded px-2 py-0.5 text-slate-400 hover:bg-[#1a2230] hover:text-slate-200" aria-label="Close setup">✕</button>
      </div>

      <div className="flex items-center gap-3">
        <div className="grid h-14 w-14 place-items-center rounded-lg border border-amber-500/40 bg-amber-500/10">
          <div className="text-center leading-none"><div className="text-[18px] font-bold text-amber-300">{s.score}</div><div className="text-[10px] text-amber-200/70">/ {s.max_score}</div></div>
        </div>
        <div className="text-[11px] leading-4 text-slate-400">Confluence score. Every point is listed below — required rules must pass, scored rules add +1.</div>
      </div>

      <section className="card">
        <h3 className="panel-h">Why this setup</h3>
        <ul className="space-y-1.5">
          {s.factors.map((f) => (
            <li key={f.key} className="grid grid-cols-[14px_1fr_auto] gap-x-2">
              <Mark passed={f.passed} mode={f.mode} />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-200">{f.label}</span>
                  <span className={`rounded px-1 text-[9px] uppercase tracking-wide ${f.mode === 'required' ? 'bg-amber-500/15 text-amber-300' : f.mode === 'scored' ? 'bg-slate-600/30 text-slate-400' : 'bg-slate-700/30 text-slate-500'}`}>{f.mode}</span>
                </div>
                <div className="text-[11px] leading-4 text-slate-500">{f.detail}</div>
              </div>
              <span className={`tabular-nums ${f.points ? 'text-emerald-300' : 'text-slate-600'}`}>{f.mode === 'pending' || f.mode === 'off' ? '' : `+${f.points}`}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card">
        <div className="flex items-center justify-between">
          <h3 className="panel-h">Hypothetical levels</h3>
          {edited && <button className="text-[10.5px] text-slate-400 underline hover:text-slate-200" onClick={() => onEdit(undefined)}>reset</button>}
        </div>
        <div className="grid grid-cols-[70px_1fr] items-center gap-y-1.5">
          <label className="text-emerald-300" htmlFor="lv-entry">Entry</label>
          <input id="lv-entry" className="lv-input" type="number" step={step} value={lv.entry} onChange={(e) => set('entry', e.target.value)} />
          <label className="text-rose-300" htmlFor="lv-sl">Stop loss</label>
          <input id="lv-sl" className="lv-input" type="number" step={step} value={lv.stop_loss} onChange={(e) => set('stop_loss', e.target.value)} />
          <label className="text-sky-300" htmlFor="lv-tp">Take profit</label>
          <input id="lv-tp" className="lv-input" type="number" step={step} value={lv.take_profit} onChange={(e) => set('take_profit', e.target.value)} />
        </div>
        <div className="mt-2 grid grid-cols-3 gap-1 rounded bg-[#0b0e14] p-2 text-center tabular-nums">
          <div><div className="text-[10px] text-slate-500">Risk</div><div>{valid ? fmtPrice(risk, precision) : '—'}</div></div>
          <div><div className="text-[10px] text-slate-500">Reward</div><div>{valid ? fmtPrice(reward, precision) : '—'}</div></div>
          <div><div className="text-[10px] text-slate-500">R:R</div><div className="font-semibold text-amber-300">{valid ? `1:${rr.toFixed(2)}` : '—'}</div></div>
        </div>
        {!valid && <p className="mt-1.5 text-[11px] text-rose-300">For a {long ? 'long' : 'short'}, the stop must be {long ? 'below' : 'above'} entry and the target {long ? 'above' : 'below'} it.</p>}
        <p className="mt-1.5 text-[10.5px] text-slate-500">Target: {s.target_description}. Entry = close of the confirmation candle.</p>
        <p className="mt-1 text-[10.5px] text-slate-500">Hypothetical levels for analysis only. This platform never places orders.</p>
      </section>

      <button className="tb-btn self-start" onClick={() => onFocus(s.time)}>Show on chart</button>
    </div>
  );
}
