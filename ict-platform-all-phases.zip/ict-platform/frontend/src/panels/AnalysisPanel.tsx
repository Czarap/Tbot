import { fmtDateTime, fmtPrice } from '../charts/format';
import { MTFPanel } from '../components/MTFPanel';
import type { AnalysisResponse, CalendarEvent, DisplayTz, LiquidityLevel, MTFResponse } from '../types';

interface Props {
  data: AnalysisResponse;
  tz: DisplayTz;
  onSelectSetup: (id: string) => void;
  onFocus: (t: number) => void;
  mtf?: MTFResponse | null;
  mtfLoading?: boolean;
  news?: CalendarEvent[];
  newsError?: string | null;
}

function Bias({ v }: { v: string | null }) {
  if (!v) return <span className="badge bg-slate-700/40 text-slate-400">WAITING</span>;
  return v === 'bullish'
    ? <span className="badge bg-emerald-500/15 text-emerald-300">BULLISH ▲</span>
    : <span className="badge bg-rose-500/15 text-rose-300">BEARISH ▼</span>;
}

function LevelRow({ lv, price, prec }: { lv: LiquidityLevel; price: number; prec: number }) {
  const d = lv.price - price;
  return (
    <div className="flex items-center justify-between gap-2 py-0.5 tabular-nums">
      <span className={lv.side === 'buy' ? 'text-sky-300' : 'text-orange-300'}>{lv.label}</span>
      <span className="text-slate-300">{fmtPrice(lv.price, prec)}</span>
      <span className="w-14 text-right text-slate-500">{d >= 0 ? '+' : ''}{fmtPrice(d, prec)}</span>
    </div>
  );
}

export function AnalysisPanel({ data, tz, onSelectSetup, onFocus, mtf, mtfLoading, news, newsError }: Props) {
  const a = data.analysis;
  const s = a.summary;
  const prec = data.symbol_info.price_precision;
  const price = s.price ?? 0;
  const last = s.last_structure_event;
  const lastSweep = a.sweeps[a.sweeps.length - 1];
  const activeFvgs = a.fvgs.filter((g) => g.status !== 'FILLED');
  const nearestBull = activeFvgs.filter((g) => g.direction === 'bullish' && g.top <= price).sort((x, y) => y.top - x.top)[0];
  const nearestBear = activeFvgs.filter((g) => g.direction === 'bearish' && g.bottom >= price).sort((x, y) => x.bottom - y.bottom)[0];
  const latest = [...a.setups].reverse().slice(0, 3);
  const dr = a.dealing_range;
  const tfAligned = s.htf_bias && s.trend && s.htf_bias === s.trend;

  return (
    <div className="flex flex-col gap-3 p-3 text-[12px] text-slate-300">
      <div className="flex items-baseline justify-between">
        <h2 className="text-[11px] font-bold tracking-[0.12em] text-slate-400">ICT ANALYSIS</h2>
        <span className="text-right leading-tight"><span className="block text-[15px] font-semibold tabular-nums text-slate-100">{fmtPrice(s.price, prec)}</span>
          <span className="block text-[10px] text-slate-500">last closed candle</span></span>
      </div>

      <MTFPanel mtf={mtf ?? null} loading={!!mtfLoading} />

      <section className="card">
        <h3 className="panel-h">Bias</h3>
        <div className="grid grid-cols-[1fr_auto] gap-y-1.5">
          <span className="text-slate-400">{s.htf_timeframe ? `${s.htf_timeframe.toUpperCase()} (HTF)` : 'HTF'}</span><Bias v={s.htf_bias} />
          <span className="text-slate-400">{data.timeframe.toUpperCase()} structure</span><Bias v={s.trend} />
        </div>
        <p className="mt-2 text-[11px] text-slate-500">{s.htf_bias && s.trend ? (tfAligned ? '✓ Timeframes aligned' : '⚠ Timeframes disagree — lower conviction') : 'Not enough structure yet.'}</p>
      </section>

      <section className="card">
        <h3 className="panel-h">Structure</h3>
        {last ? (
          <button className="w-full text-left" onClick={() => onFocus(last.time)}>
            <div className={`font-semibold ${last.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}`}>{last.type} {last.direction}</div>
            <div className="mt-1 space-y-0.5 text-[11px] text-slate-400">{last.explanation.slice(1).map((l, i) => <div key={i}>{l}</div>)}</div>
            <div className="mt-1 text-[10.5px] text-slate-500">{fmtDateTime(last.time, tz)}</div>
          </button>
        ) : <p className="text-slate-500">No BOS / CHoCH yet.</p>}
      </section>

      {dr && (
        <section className="card">
          <h3 className="panel-h">Premium / Discount</h3>
          <div className="grid grid-cols-2 gap-y-0.5 tabular-nums text-[11.5px]">
            <span className="text-slate-500">Range high</span><span className="text-right">{fmtPrice(dr.high, prec)}</span>
            <span className="text-slate-500">Equilibrium</span><span className="text-right text-violet-300">{fmtPrice(dr.equilibrium, prec)}</span>
            <span className="text-slate-500">Range low</span><span className="text-right">{fmtPrice(dr.low, prec)}</span>
          </div>
          <div className="mt-1.5 text-[11px]">Price is in <b className={s.zone === 'premium' ? 'text-rose-300' : s.zone === 'discount' ? 'text-emerald-300' : 'text-violet-300'}>{(s.zone ?? '—').toUpperCase()}</b></div>
        </section>
      )}

      <section className="card">
        <h3 className="panel-h">Liquidity</h3>
        <div className="text-[11px]">
          {s.nearest_buy_side.slice().reverse().map((lv) => <LevelRow key={lv.id} lv={lv} price={price} prec={prec} />)}
          <div className="my-1 border-t border-dashed border-slate-700 text-center text-[10px] text-slate-500">price {fmtPrice(price, prec)}</div>
          {s.nearest_sell_side.map((lv) => <LevelRow key={lv.id} lv={lv} price={price} prec={prec} />)}
        </div>
        {lastSweep && (
          <button className="mt-2 w-full rounded bg-[#151b26] p-2 text-left text-[11px] hover:bg-[#1a2230]" onClick={() => onFocus(lastSweep.time)}>
            <div className={lastSweep.side === 'buy' ? 'text-rose-300' : 'text-emerald-300'}>Last sweep: {lastSweep.level_label} {fmtPrice(lastSweep.level_price, prec)}</div>
            <div className="text-slate-500">{fmtDateTime(lastSweep.time, tz)} · {lastSweep.implication} implication</div>
          </button>
        )}
      </section>

      <section className="card">
        <h3 className="panel-h">Fair Value Gaps</h3>
        <div className="text-[11px] text-slate-400">{s.active_fvgs} unfilled in view · {s.active_order_blocks ?? 0} active order blocks</div>
        {[nearestBear, nearestBull].filter(Boolean).map((g) => g && (
          <button key={g.id} onClick={() => onFocus(g.time)} className="mt-1 flex w-full justify-between rounded px-1 py-0.5 text-left text-[11px] tabular-nums hover:bg-[#151b26]">
            <span className={g.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}>{g.direction === 'bullish' ? 'Bull' : 'Bear'} FVG</span>
            <span>{fmtPrice(g.bottom, prec)} – {fmtPrice(g.top, prec)}</span>
            <span className="text-slate-500">{g.status === 'MITIGATED' ? 'mitig.' : 'fresh'}</span>
          </button>
        ))}
      </section>

      <section className="card">
        <h3 className="panel-h">Upcoming USD news</h3>
        {(() => {
          const now = Date.now() / 1000;
          const next = (news ?? []).filter((e) => e.time >= now - 3600).slice(0, 4);
          if (newsError && !(news ?? []).length) return <p className="text-[11px] text-slate-500">Calendar unavailable.</p>;
          if (!next.length) return <p className="text-[11px] text-slate-500">No high-impact USD releases in the next days.</p>;
          return next.map((e) => {
            const mins = Math.round((e.time - now) / 60);
            return (
              <div key={e.id} className="flex justify-between gap-2 py-0.5 text-[11px]">
                <span className="text-orange-300">{e.name}</span>
                <span className="whitespace-nowrap tabular-nums text-slate-500">{mins < 0 ? 'just released' : mins < 120 ? `in ${mins} min` : fmtDateTime(e.time, tz, false)}</span>
              </div>
            );
          });
        })()}
      </section>

      <section className="card">
        <h3 className="panel-h">Latest possible setups</h3>
        {latest.length === 0 && <p className="text-[11px] text-slate-500">No setup met the configured rules in this window.</p>}
        {latest.map((st) => (
          <button key={st.id} onClick={() => onSelectSetup(st.id)} className="mb-1.5 w-full rounded border border-[#263042] p-2 text-left hover:border-slate-500">
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold ${st.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}`}>{st.label}</span>
              <span className="badge bg-amber-500/15 text-amber-300">{st.score}/{st.max_score}</span>
            </div>
            <div className="mt-1 grid grid-cols-3 gap-1 text-[10.5px] tabular-nums text-slate-400">
              <span>E {fmtPrice(st.entry, prec)}</span><span>SL {fmtPrice(st.stop_loss, prec)}</span><span>TP {fmtPrice(st.take_profit, prec)}</span>
            </div>
            <div className="mt-0.5 text-[10.5px] text-slate-500">{fmtDateTime(st.time, tz)} · R:R 1:{st.rr.toFixed(2)}</div>
          </button>
        ))}
      </section>
    </div>
  );
}
