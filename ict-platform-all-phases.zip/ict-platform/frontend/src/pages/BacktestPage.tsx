import { useEffect, useMemo, useRef, useState } from 'react';
import { fmtDateTime, fmtPrice } from '../charts/format';
import { LineChart } from '../charts/LineChart';
import { BacktestForm } from '../components/BacktestForm';
import { ChartView } from '../components/ChartView';
import { Banner, Card, GroupTable, Progress, Stat, deepMerge, downloadText, duration, loadLS, money, saveLS, signed, tone } from '../components/ui';
import { api, waitForJob } from '../services/api';
import { backtestChartData } from '../services/chartData';
import type { BacktestConfig, BacktestResult, DisplayTz, ICTSettings, MetaResponse, OverlayFlags, Profile, Trade } from '../types';

const FLAGS: OverlayFlags = {
  structure: false, swings: false, liquidity: false, swingLiquidity: false, sweeps: false, fvg: false, filledFvg: false, displacement: false,
  orderBlocks: false, premiumDiscount: false, previousLevels: false, sessions: false, setups: false, volume: true, highLow: true, news: false,
};

export function tradesCsv(trades: Trade[]): string {
  const cols: (keyof Trade)[] = ['id', 'entry_time', 'symbol', 'timeframe', 'direction', 'entry', 'stop_loss', 'take_profit', 'lots', 'risk_amount',
    'planned_reward', 'rr', 'score', 'max_score', 'session', 'htf_bias', 'setup_type', 'liquidity_event', 'fvg', 'order_block', 'displacement',
    'exit_time', 'exit_price', 'exit_reason', 'result', 'pnl', 'r_multiple', 'duration_seconds', 'notes'];
  const esc = (v: unknown) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return [cols.join(','), ...trades.map((t) => cols.map((c) => esc(c.endsWith('_time') && t[c] ? new Date((t[c] as number) * 1000).toISOString() : t[c])).join(','))].join('\n');
}

export function TradeTable({ trades, precision, tz, selected, onSelect, runId, onNote }: {
  trades: Trade[]; precision: number; tz: DisplayTz; selected: string | null; onSelect: (id: string) => void; runId?: string;
  onNote?: (id: string, notes: string) => void;
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  return (
    <div className="max-h-[520px] overflow-auto">
      <table className="w-full text-[11.5px] tabular-nums">
        <thead className="sticky top-0 bg-[#10151e] text-left text-[10px] uppercase tracking-wide text-slate-500">
          <tr>{['ID', 'Entry time', 'Dir', 'Entry', 'SL', 'TP', 'Lots', 'Risk', 'R:R', 'Score', 'Session', 'Setup', 'Exit', 'Result', 'P/L', 'R', 'Duration', 'Notes'].map((h) => <th key={h} className="px-1.5 py-1 font-medium">{h}</th>)}</tr>
        </thead>
        <tbody>
          {trades.map((t) => (
            <tr key={t.id} onClick={() => onSelect(t.id)} className={`cursor-pointer border-t border-[#161c27] hover:bg-[#141a24] ${t.id === selected ? 'bg-[#18202e]' : ''}`}>
              <td className="px-1.5 py-1 text-slate-400">{t.id}</td>
              <td className="px-1.5 text-slate-400">{fmtDateTime(t.entry_time, tz, false)}</td>
              <td className={`px-1.5 font-semibold ${t.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}`}>{t.direction === 'bullish' ? 'Long' : 'Short'}</td>
              <td className="px-1.5">{fmtPrice(t.entry, precision)}</td>
              <td className="px-1.5 text-rose-300/90">{fmtPrice(t.stop_loss, precision)}</td>
              <td className="px-1.5 text-sky-300/90">{fmtPrice(t.take_profit, precision)}</td>
              <td className="px-1.5">{t.lots}</td>
              <td className="px-1.5">{money(t.risk_amount, 0)}</td>
              <td className="px-1.5">1:{t.rr.toFixed(2)}</td>
              <td className="px-1.5 text-amber-300">{t.score}/{t.max_score}</td>
              <td className="px-1.5 text-slate-400">{t.session ?? '—'}</td>
              <td className="px-1.5 text-slate-400">{t.setup_type}</td>
              <td className="px-1.5 text-slate-400">{t.exit_reason ?? '—'}</td>
              <td className={`px-1.5 font-semibold ${t.result === 'WIN' ? 'text-emerald-300' : t.result === 'LOSS' ? 'text-rose-300' : 'text-slate-400'}`}>{t.result}</td>
              <td className={`px-1.5 ${tone(t.pnl)}`}>{money(t.pnl, 0)}</td>
              <td className={`px-1.5 ${tone(t.r_multiple)}`}>{signed(t.r_multiple)}</td>
              <td className="px-1.5 text-slate-400">{duration(t.duration_seconds)}</td>
              <td className="min-w-[160px] px-1.5" onClick={(e) => e.stopPropagation()}>
                {editing === t.id ? (
                  <input autoFocus className="lv-input w-full !text-left" value={draft} onChange={(e) => setDraft(e.target.value)}
                    onBlur={() => { onNote?.(t.id, draft); setEditing(null); }}
                    onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') setEditing(null); }} />
                ) : (
                  <button className="w-full truncate text-left text-slate-400 hover:text-slate-200" disabled={!runId || !onNote}
                    onClick={() => { setEditing(t.id); setDraft(t.notes ?? ''); }}>{t.notes || (runId ? '+ add note' : '')}</button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function TradeDetail({ t, precision, tz }: { t: Trade; precision: number; tz: DisplayTz }) {
  const rows: [string, string | null][] = [
    ['Signal', fmtDateTime(t.signal_time, tz)], ['Entry', `${fmtPrice(t.entry, precision)} at ${fmtDateTime(t.entry_time, tz)}`],
    ['Stop / target', `${fmtPrice(t.stop_loss, precision)} / ${fmtPrice(t.take_profit, precision)}`],
    ['Size / risk', `${t.lots} lots · ${money(t.risk_amount)} · planned reward ${money(t.planned_reward)}`],
    ['Exit', t.exit_time ? `${fmtPrice(t.exit_price, precision)} (${t.exit_reason}) at ${fmtDateTime(t.exit_time, tz)}` : 'open'],
    ['Result', `${t.result} · ${money(t.pnl)} · ${signed(t.r_multiple)}R · commission ${money(t.commission)}`],
    ['HTF bias', t.htf_bias], ['Session', t.session], ['Liquidity event', t.liquidity_event], ['FVG', t.fvg], ['Order block', t.order_block],
    ['Displacement', t.displacement], ['Notes', t.notes || null],
  ];
  return (
    <div className="grid grid-cols-[110px_1fr] gap-x-3 gap-y-1 text-[11.5px]">
      {rows.flatMap(([k, v]) => [<span key={`${k}-k`} className="text-slate-500">{k}</span>, <span key={`${k}-v`} className="text-slate-300">{v ?? '—'}</span>])}
    </div>
  );
}

export function ResultView({ r, tz, onNote }: { r: BacktestResult; tz: DisplayTz; onNote?: (id: string, notes: string) => void }) {
  const [sel, setSel] = useState<string | null>(null);
  const [focus, setFocus] = useState<{ time: number; nonce: number } | null>(null);
  const s = r.stats;
  const prec = r.symbol_info.price_precision;
  const data = useMemo(() => backtestChartData(r), [r]);
  const selected = r.trades.find((t) => t.id === sel) ?? null;
  const pick = (id: string) => { setSel(id); const t = r.trades.find((x) => x.id === id); if (t) setFocus({ time: t.entry_time, nonce: Date.now() }); };
  const pf = s.profit_factor === null ? (s.profit_factor_note ? '∞' : '—') : s.profit_factor.toFixed(2);
  return (
    <div className="space-y-3">
      {r.warnings.map((w) => <Banner key={w}>{w}</Banner>)}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8">
        <Stat label="Total trades" value={s.total_trades} />
        <Stat label="Win rate" value={`${s.win_rate.toFixed(1)}%`} />
        <Stat label="Net R" value={signed(s.net_r)} className={tone(s.net_r)} />
        <Stat label="Net profit" value={money(s.net_profit, 0)} className={tone(s.net_profit)} />
        <Stat label="Profit factor" value={pf} />
        <Stat label="Expectancy" value={`${signed(s.expectancy_r, 3)}R`} className={tone(s.expectancy_r)} hint={`${money(s.expectancy_money)} per trade`} />
        <Stat label="Max drawdown" value={`${s.max_drawdown_pct.toFixed(2)}%`} className="text-rose-300" hint={money(s.max_drawdown)} />
        <Stat label="Avg R" value={signed(s.average_r, 3)} className={tone(s.average_r)} />
        <Stat label="Winning / losing" value={`${s.winning_trades} / ${s.losing_trades}`} />
        <Stat label="Max consec. wins" value={s.max_consecutive_wins} />
        <Stat label="Max consec. losses" value={s.max_consecutive_losses} />
        <Stat label="Largest win" value={money(s.largest_win, 0)} className="text-emerald-300" />
        <Stat label="Largest loss" value={money(s.largest_loss, 0)} className="text-rose-300" />
        <Stat label="Avg duration" value={duration(s.average_trade_duration_seconds)} />
        <Stat label="Trading days" value={s.total_trading_days} />
        <Stat label="Final balance" value={money(r.final_balance, 0)} hint={`started ${money(r.starting_balance, 0)} · return ${s.return_pct}%`} />
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        <Card><LineChart title="Equity curve" tz={tz} points={r.equity.map((p) => ({ time: p.time, value: p.balance }))} baseline={r.starting_balance} format={(v) => money(v, 0)} /></Card>
        <Card><LineChart title="Drawdown" tz={tz} color="#f43f5e" points={r.drawdown.map((p) => ({ time: p.time, value: p.drawdown_pct }))} baseline={0} format={(v) => `${v.toFixed(2)}%`} /></Card>
      </div>
      <Card title={`Trades on the chart · ${r.config.symbol} ${r.config.timeframe}`} right={<span className="text-[11px] text-slate-500">click a trade for details</span>}>
        <div className="relative h-[420px]">
          <ChartView data={data} flags={FLAGS} tz={tz} selectedSetup={null} edited={{}} tool="cursor" drawings={[]} focus={focus}
            onSelectSetup={() => undefined} onDrawingsChange={() => undefined} trades={r.trades} selectedTrade={sel} onSelectTrade={pick} />
        </div>
        {selected && <div className="mt-3 border-t border-[#1e2533] pt-3"><TradeDetail t={selected} precision={prec} tz={tz} /></div>}
      </Card>
      {r.prop && (
        <Card title="Prop-firm simulation" right={<span className={`badge ${r.prop.status === 'PASSED' ? 'bg-emerald-500/15 text-emerald-300' : r.prop.status === 'BREACHED' ? 'bg-rose-500/15 text-rose-300' : 'bg-sky-500/15 text-sky-300'}`}>{r.prop.status}</span>}>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-6">
            <Stat label="Account status" value={r.prop.status} className={r.prop.status === 'BREACHED' ? 'text-rose-300' : r.prop.status === 'PASSED' ? 'text-emerald-300' : 'text-sky-300'} />
            <Stat label="Current balance" value={money(r.prop.current_balance, 0)} />
            <Stat label="Max drawdown" value={money(r.prop.max_drawdown_reached, 0)} hint={`limit ${money(r.prop.max_drawdown_limit, 0)}`} />
            <Stat label="Worst daily loss" value={money(r.prop.worst_daily_loss, 0)} hint={`limit ${money(r.prop.daily_loss_limit, 0)}`} />
            <Stat label="Target progress" value={`${r.prop.target_progress_pct}%`} hint={`target ${money(r.prop.profit_target, 0)}`} />
            <Stat label="Breached?" value={r.prop.status === 'BREACHED' ? 'YES' : 'NO'} className={r.prop.status === 'BREACHED' ? 'text-rose-300' : 'text-emerald-300'} />
          </div>
          {r.prop.reason && <p className="mt-2 text-[12px] text-rose-200">{r.prop.reason} ({r.prop.breach_time ? fmtDateTime(r.prop.breach_time, tz) : ''})</p>}
          <p className="mt-1 text-[10.5px] text-slate-500">{r.prop.note}</p>
        </Card>
      )}
      <div className="grid gap-3 lg:grid-cols-2 xl:grid-cols-4">
        <Card title="Monthly results"><GroupTable rows={r.monthly} keyLabel="Month" /></Card>
        <Card title="Session results"><GroupTable rows={r.by_session} keyLabel="Session" /></Card>
        <Card title="Setup results"><GroupTable rows={r.by_setup_type} keyLabel="Setup" /></Card>
        <Card title="Direction & score">
          <GroupTable rows={r.by_direction} keyLabel="Direction" money={false} />
          <div className="mt-3"><GroupTable rows={r.by_score} keyLabel="Score" money={false} /></div>
        </Card>
      </div>
      <Card title="Signals not traded">
        <div className="text-[12px] text-slate-400">{r.setups_found} possible setups in the period · {s.total_trades} traded</div>
        <ul className="mt-1 grid gap-x-6 text-[12px] text-slate-400 md:grid-cols-2">
          {Object.entries(r.skipped).sort((a, b) => b[1] - a[1]).map(([k, v]) => <li key={k}>{v} × {k}</li>)}
        </ul>
      </Card>
      <Card title={`Trade journal (${r.trades.length})`} right={<button className="tb-btn" onClick={() => downloadText(`trades_${r.config.symbol}_${r.config.timeframe}.csv`, tradesCsv(r.trades))}>Export CSV</button>}>
        <TradeTable trades={r.trades} precision={prec} tz={tz} selected={sel} onSelect={pick} runId={r.run_id} onNote={onNote} />
      </Card>
      <p className="text-[10.5px] text-slate-500">{r.disclaimer}</p>
    </div>
  );
}

export function useStrategyInputs(meta: MetaResponse | null) {
  const [cfg, setCfg] = useState<BacktestConfig | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  useEffect(() => {
    if (!meta?.default_backtest) return;
    const settings = deepMerge(meta.default_settings, loadLS<ICTSettings | null>('settings', null) ?? meta.default_settings);
    const stored = loadLS<BacktestConfig | null>('bt.config', null);
    const base = deepMerge(meta.default_backtest, stored ?? meta.default_backtest);
    setCfg({ ...base, settings });
    api.profiles().then((p) => setProfiles(p.profiles)).catch(() => undefined);
  }, [meta]);
  const update = (c: BacktestConfig) => { setCfg(c); const { settings: _s, ...rest } = c; void _s; saveLS('bt.config', rest); };
  const applyProfile = (p: Profile) => {
    if (!cfg || !meta) return;
    setCfg({ ...deepMerge(cfg, p.backtest ?? {}), settings: deepMerge(meta.default_settings, p.settings) });
  };
  return { cfg, update, profiles, applyProfile };
}

export function BacktestPage({ meta, tz }: { meta: MetaResponse | null; tz: DisplayTz }) {
  const { cfg, update, profiles, applyProfile } = useStrategyInputs(meta);
  const [job, setJob] = useState<{ progress: number; message: string; id: string } | null>(null);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const cancel = useRef({ cancelled: false });

  const run = async () => {
    if (!cfg) return;
    setError(null);
    cancel.current = { cancelled: false };
    try {
      const j = await api.startBacktest(cfg);
      setJob({ progress: 0, message: 'Queued', id: j.id });
      const done = await waitForJob<BacktestResult>(j.id, (x) => setJob({ progress: x.progress, message: x.message, id: x.id }), cancel.current);
      setResult(done.result ?? null);
    } catch (e) {
      if ((e as Error).message !== 'cancelled') setError((e as Error).message);
    } finally {
      setJob(null);
    }
  };

  const onNote = (id: string, notes: string) => {
    if (!result?.run_id) return;
    api.setNote(result.run_id, id, notes).catch((e: Error) => setError(e.message));
    setResult({ ...result, trades: result.trades.map((t) => (t.id === id ? { ...t, notes } : t)) });
  };

  return (
    <div className="grid min-h-0 flex-1 md:grid-cols-[320px_1fr]">
      <aside className="overflow-y-auto border-r border-[#1e2533] bg-[#0d1118] p-3 md:max-h-[calc(100vh-40px)]">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-[13px] font-semibold text-slate-100">Backtest</h2>
          {profiles.length > 0 && (
            <select className="tb-select max-w-[150px]" value="" onChange={(e) => { const p = profiles.find((x) => String(x.id) === e.target.value); if (p) applyProfile(p); }}>
              <option value="">Load profile…</option>
              {profiles.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          )}
        </div>
        {cfg ? <BacktestForm meta={meta} value={cfg} onChange={update} /> : <p className="text-slate-500">Loading…</p>}
        <div className="sticky bottom-0 mt-3 bg-[#0d1118] pt-2">
          {job ? (
            <div className="space-y-2">
              <Progress value={job.progress} message={job.message} />
              <button className="tb-btn w-full" onClick={() => { cancel.current.cancelled = true; api.cancelJob(job.id).catch(() => undefined); }}>Cancel</button>
            </div>
          ) : (
            <button className="w-full rounded-md bg-amber-500 py-2 text-[13px] font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-40" disabled={!cfg} onClick={run}>Run backtest</button>
          )}
        </div>
      </aside>
      <main className="min-w-0 overflow-y-auto p-3 md:max-h-[calc(100vh-40px)]">
        {error && <div className="mb-3"><Banner kind="error">{error}</Banner></div>}
        {result ? <ResultView r={result} tz={tz} onNote={onNote} /> : (
          <div className="grid h-full place-items-center text-center text-[13px] text-slate-500">
            <div className="max-w-md space-y-2">
              <p>Configure the test on the left and press <b className="text-slate-300">Run backtest</b>.</p>
              <p className="text-[12px]">The same streaming ICT engine as the live chart processes the candles one by one; entries fill at the next candle's open, so the results contain no look-ahead.</p>
              <p className="text-[12px]">Results are saved to the Journal.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
