import { useEffect, useMemo, useState } from 'react';
import { fmtDateTime } from '../charts/format';
import { LineChart } from '../charts/LineChart';
import { Banner, Card, GroupTable, Stat, downloadText, money, signed, tone } from '../components/ui';
import { api } from '../services/api';
import type { BacktestResult, DisplayTz, RunSummary, Trade } from '../types';
import { TradeDetail, TradeTable, tradesCsv } from './BacktestPage';

type SavedRun = Partial<BacktestResult> & { id: string; trades: Trade[]; created?: number; config?: BacktestResult['config'] };

export function JournalPage({ tz }: { tz: DisplayTz }) {
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [runId, setRunId] = useState<string | null>(null);
  const [run, setRun] = useState<SavedRun | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [filter, setFilter] = useState({ result: 'all', session: 'all', setup: 'all', text: '' });
  const [error, setError] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState(false);

  const refresh = () => api.runs().then((r) => { setRuns(r.runs); if (!runId && r.runs[0]) setRunId(r.runs[0].id); }).catch((e: Error) => setError(e.message));
  useEffect(() => { refresh(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (runId) api.run(runId).then((r) => { setRun(r as SavedRun); setSel(null); }).catch((e: Error) => setError(e.message)); }, [runId]);

  const trades = useMemo(() => (run?.trades ?? []).filter((t) =>
    (filter.result === 'all' || t.result === filter.result) && (filter.session === 'all' || (t.session ?? 'none') === filter.session) &&
    (filter.setup === 'all' || t.setup_type === filter.setup) && (!filter.text || (t.notes ?? '').toLowerCase().includes(filter.text.toLowerCase()))), [run, filter]);
  const sessions = [...new Set((run?.trades ?? []).map((t) => t.session ?? 'none'))];
  const setups = [...new Set((run?.trades ?? []).map((t) => t.setup_type))];
  const prec = run?.trades?.[0] ? Math.max(1, (String(run.trades[0].entry).split('.')[1] ?? '').length) : 2;
  const selected = run?.trades.find((t) => t.id === sel) ?? null;
  const s = run?.stats;

  const onNote = (id: string, notes: string) => {
    if (!run) return;
    api.setNote(run.id, id, notes).catch((e: Error) => setError(e.message));
    setRun({ ...run, trades: run.trades.map((t) => (t.id === id ? { ...t, notes } : t)) });
  };

  return (
    <div className="grid min-h-0 flex-1 md:grid-cols-[300px_1fr]">
      <aside className="overflow-y-auto border-r border-[#1e2533] bg-[#0d1118] p-3 md:max-h-[calc(100vh-40px)]">
        <div className="mb-2 flex items-center justify-between"><h2 className="text-[13px] font-semibold text-slate-100">Trade journal</h2>
          <button className="text-[11px] text-slate-400 hover:text-slate-200" onClick={refresh}>↻</button></div>
        {runs.length === 0 && <p className="text-[12px] text-slate-500">No saved backtests yet. Every backtest you run is stored here with all its trades.</p>}
        <ul className="space-y-1.5">
          {runs.map((r) => (
            <li key={r.id}>
              <button onClick={() => setRunId(r.id)} className={`w-full rounded border p-2 text-left text-[11.5px] ${r.id === runId ? 'border-amber-500/50 bg-amber-500/5' : 'border-[#1c2331] hover:border-slate-600'}`}>
                <div className="flex justify-between"><span className="font-semibold text-slate-200">{r.symbol} · {r.timeframe}</span><span className={tone(r.stats.net_r)}>{signed(r.stats.net_r ?? 0)}R</span></div>
                <div className="text-slate-500">{r.start ?? 'start'} → {r.end ?? 'end'} · {r.stats.total_trades} trades · {(r.stats.win_rate ?? 0).toFixed(0)}%</div>
                <div className="text-[10.5px] text-slate-600">{fmtDateTime(r.created, tz)}</div>
              </button>
            </li>
          ))}
        </ul>
      </aside>
      <main className="min-w-0 space-y-3 overflow-y-auto p-3 md:max-h-[calc(100vh-40px)]">
        {error && <Banner kind="error">{error}</Banner>}
        {run && s && (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-[14px] font-semibold text-slate-100">{run.config?.symbol} {run.config?.timeframe} · {run.config?.start ?? ''} → {run.config?.end ?? ''}</h2>
              <div className="flex gap-2">
                <button className="tb-btn" onClick={() => downloadText(`journal_${run.id}.csv`, tradesCsv(run.trades))}>Export CSV</button>
                <button className={`tb-btn ${confirmDel ? '!border-rose-500/60 !text-rose-200' : ''}`} onBlur={() => setConfirmDel(false)}
                  onClick={() => { if (!confirmDel) { setConfirmDel(true); return; } setConfirmDel(false); api.deleteRun(run.id).then(() => { setRun(null); setRunId(null); refresh(); }); }}>
                  {confirmDel ? 'Click again to delete' : 'Delete run'}</button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8">
              <Stat label="Trades" value={s.total_trades} /><Stat label="Win rate" value={`${s.win_rate.toFixed(1)}%`} />
              <Stat label="Net R" value={signed(s.net_r)} className={tone(s.net_r)} /><Stat label="Net profit" value={money(s.net_profit, 0)} className={tone(s.net_profit)} />
              <Stat label="Profit factor" value={s.profit_factor?.toFixed(2) ?? '—'} /><Stat label="Expectancy" value={`${signed(s.expectancy_r, 3)}R`} className={tone(s.expectancy_r)} />
              <Stat label="Max DD" value={`${s.max_drawdown_pct.toFixed(2)}%`} className="text-rose-300" /><Stat label="Max losing streak" value={s.max_consecutive_losses} />
            </div>
            {run.equity && <Card><LineChart title="Equity curve" tz={tz} points={run.equity.map((p) => ({ time: p.time, value: p.balance }))} format={(v) => money(v, 0)} /></Card>}
            <div className="grid gap-3 lg:grid-cols-3">
              {run.monthly && <Card title="Monthly"><GroupTable rows={run.monthly} keyLabel="Month" /></Card>}
              {run.by_session && <Card title="Sessions"><GroupTable rows={run.by_session} keyLabel="Session" /></Card>}
              {run.by_setup_type && <Card title="Setups"><GroupTable rows={run.by_setup_type} keyLabel="Setup" /></Card>}
            </div>
            <Card title={`Trades (${trades.length} of ${run.trades.length})`} right={
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                <select className="tb-select" value={filter.result} onChange={(e) => setFilter({ ...filter, result: e.target.value })}>
                  {['all', 'WIN', 'LOSS', 'BREAKEVEN'].map((x) => <option key={x} value={x}>{x === 'all' ? 'All results' : x}</option>)}</select>
                <select className="tb-select" value={filter.session} onChange={(e) => setFilter({ ...filter, session: e.target.value })}>
                  <option value="all">All sessions</option>{sessions.map((x) => <option key={x} value={x}>{x}</option>)}</select>
                <select className="tb-select" value={filter.setup} onChange={(e) => setFilter({ ...filter, setup: e.target.value })}>
                  <option value="all">All setups</option>{setups.map((x) => <option key={x} value={x}>{x}</option>)}</select>
                <input className="lv-input w-32 !text-left" placeholder="search notes" value={filter.text} onChange={(e) => setFilter({ ...filter, text: e.target.value })} />
              </div>}>
              <TradeTable trades={trades} precision={prec} tz={tz} selected={sel} onSelect={setSel} runId={run.id} onNote={onNote} />
            </Card>
            {selected && <Card title={`Trade ${selected.id}`}><TradeDetail t={selected} precision={prec} tz={tz} /></Card>}
          </>
        )}
      </main>
    </div>
  );
}
