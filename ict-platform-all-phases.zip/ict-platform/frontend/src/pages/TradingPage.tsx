import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Tool } from '../charts/CandleChart';
import { ChartView } from '../components/ChartView';
import { Disclaimer } from '../components/Disclaimer';
import { AlertToasts, AlertsButton } from '../components/AlertsPanel';
import { LayersPanel } from '../components/LayersPanel';
import { ReplayBar } from '../components/ReplayBar';
import { MarketStatus } from '../components/MarketStatus';
import { TopBar } from '../components/TopBar';
import { AnalysisPanel } from '../panels/AnalysisPanel';
import { BottomPanel } from '../panels/BottomPanel';
import { SettingsDrawer } from '../panels/SettingsDrawer';
import { SetupDetail } from '../panels/SetupDetail';
import { useSetupAlerts } from '../services/alerts';
import { api, fetchAnalysis, fetchMeta, isSnapshot, snapshot } from '../services/api';
import { LiveConnection, type TransportState } from '../services/live';
import type { AnalysisResponse, CalendarEvent, Candle, DisplayTz, EditedLevels, FeedStatus, ICTSettings, LiveMessage, LiveTick, MetaResponse, MTFResponse, OverlayFlags, ReplayInfo, ReplayState, Timeframe } from '../types';

const DEFAULT_FLAGS: OverlayFlags = {
  structure: true, swings: true, liquidity: true, swingLiquidity: true, sweeps: true, fvg: true, filledFvg: false,
  displacement: true, orderBlocks: true, premiumDiscount: true, previousLevels: false, sessions: false, setups: true, volume: true, highLow: true, news: true,
};

// Browser storage is a convenience only (it can be unavailable or empty).
function load<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(`ict.${key}`);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch { return fallback; }
}
function loadScalar<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(`ict.${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch { return fallback; }
}
/** Stored settings may come from an older version: fill in any keys added since. */
function deepMerge<T>(defaults: T, stored: unknown): T {
  if (stored === null || typeof stored !== 'object' || Array.isArray(stored) || defaults === null || typeof defaults !== 'object' || Array.isArray(defaults)) {
    return (stored === undefined ? defaults : stored) as T;
  }
  const out: Record<string, unknown> = { ...(defaults as Record<string, unknown>) };
  for (const [k, v] of Object.entries(stored as Record<string, unknown>)) {
    if (k in out) out[k] = deepMerge(out[k], v);
  }
  return out as T;
}

function save(key: string, v: unknown) {
  try { window.localStorage.setItem(`ict.${key}`, JSON.stringify(v)); } catch { /* ignore */ }
}

function useMedia(q: string): boolean {
  const [m, setM] = useState(() => typeof window !== 'undefined' && window.matchMedia(q).matches);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const f = () => setM(mq.matches);
    mq.addEventListener('change', f);
    return () => mq.removeEventListener('change', f);
  }, [q]);
  return m;
}

export function TradingPage({ active = true }: { active?: boolean }) {
  const isMd = useMedia('(min-width: 768px)');
  const isLg = useMedia('(min-width: 1024px)');
  const [tabRequest, setTabRequest] = useState<{ id: string; nonce: number } | null>(null);
  const [meta, setMeta] = useState<MetaResponse | null>(null);
  const [symbol, setSymbol] = useState('XAUUSD');
  const [timeframe, setTimeframe] = useState<Timeframe>(() => loadScalar<Timeframe>('tf', '15m'));
  const [provider, setProvider] = useState<string>('');
  const [settings, setSettings] = useState<ICTSettings | null>(null);
  const [flags, setFlags] = useState<OverlayFlags>(() => load('flags', DEFAULT_FLAGS));
  const [tz, setTz] = useState<DisplayTz>(() => loadScalar<DisplayTz>('tz', 'America/New_York'));
  const [data, setData] = useState<AnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [edited, setEdited] = useState<Record<string, EditedLevels>>({});
  const [tool, setTool] = useState<Tool>('cursor');
  const [drawings, setDrawings] = useState<number[]>([]);
  const [focus, setFocus] = useState<{ time: number; nonce: number } | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reloadNonce, setReloadNonce] = useState(0);
  const [feedStatus, setFeedStatus] = useState<FeedStatus | null>(null);
  const [transport, setTransport] = useState<TransportState | null>(null);
  const [transportInfo, setTransportInfo] = useState<{ transport: string; retryIn?: number; attempt: number } | null>(null);
  const [forming, setForming] = useState<Candle | null>(null);
  const [tick, setTick] = useState<LiveTick | null>(null);
  const liveRef = useRef<LiveConnection | null>(null);
  const current = useRef({ symbol, timeframe });
  current.current = { symbol, timeframe };
  // ---- replay
  const [replayOpen, setReplayOpen] = useState(false);
  const [replay, setReplay] = useState<ReplayInfo | null>(null);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [replayBusy, setReplayBusy] = useState(false);
  const inFlight = useRef(false);
  const replayActive = replayOpen && replay !== null;
  const liveEnabled = !isSnapshot && meta?.live === true && !replayActive;
  // ---- MTF + news
  const [mtf, setMtf] = useState<MTFResponse | null>(null);
  const [mtfLoading, setMtfLoading] = useState(false);
  const [news, setNews] = useState<CalendarEvent[]>([]);
  const [newsError, setNewsError] = useState<string | null>(null);

  useEffect(() => { save('flags', flags); }, [flags]);
  useEffect(() => { save('tz', tz); }, [tz]);
  useEffect(() => { save('tf', timeframe); }, [timeframe]);

  // meta + initial settings
  useEffect(() => {
    fetchMeta().then((m) => {
      setMeta(m);
      const sym = m.default_symbol ?? 'XAUUSD';
      setSymbol(sym);
      setProvider(m.instruments?.find((i) => i.symbol === sym)?.default_provider ?? m.default_provider);
      const stored = isSnapshot ? null : loadScalar<ICTSettings | null>('settings', null);
      const defaults = isSnapshot ? Object.values(snapshot!.analyses)[0]!.settings : m.default_settings;
      setSettings(stored ? deepMerge(defaults, stored) : defaults);
      if (isSnapshot && !snapshot!.analyses[timeframe]) setTimeframe(Object.keys(snapshot!.analyses)[0] as Timeframe);
    }).catch((e: Error) => setError(`Could not reach the backend: ${e.message}`));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- live mode: one WebSocket (or SSE) connection, re-subscribed on every change
  useEffect(() => {
    if (!liveEnabled) return;
    const onMessage = (m: LiveMessage) => {
      const cur = current.current;
      switch (m.type) {
        case 'snapshot':
        case 'analysis': {
          const d = m.payload;
          if (d.symbol !== cur.symbol || d.timeframe !== cur.timeframe) return;
          setData(d);
          setForming(d.forming ?? null);
          setLoading(false);
          setError(null);
          setSelected((sel) => (sel && d.analysis.setups.some((x) => x.id === sel) ? sel : null));
          if (m.type === 'snapshot') setFeedStatus(m.status);
          break;
        }
        case 'candle':
        case 'candle_closed': {
          const c = m.candle;
          if (!c || c.symbol !== cur.symbol || c.timeframe !== cur.timeframe) return;
          setForming({ time: c.timestamp, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
          if (m.type === 'candle' && m.tick) setTick(m.tick);
          break;
        }
        case 'status':
          if (m.status.symbol === cur.symbol) setFeedStatus(m.status);
          break;
        case 'error':
          setError(m.message);
          setLoading(false);
          break;
        default:
          break;
      }
    };
    const conn = new LiveConnection({ onMessage, onTransport: (st, info) => { setTransport(st); setTransportInfo(info); } });
    liveRef.current = conn;
    return () => { conn.close(); liveRef.current = null; };
  }, [liveEnabled]);

  useEffect(() => {
    if (!liveEnabled || !settings || !provider || !liveRef.current) return;
    setLoading(true);
    liveRef.current.subscribe({ symbol, timeframe, provider, limit: 1500, settings });
  }, [liveEnabled, symbol, timeframe, provider, settings]);

  useEffect(() => { setForming(null); setTick(null); setFeedStatus(null); }, [symbol, provider]);
  useEffect(() => { setForming(null); }, [timeframe]);

  // ---- request/response mode (static demo or a backend without live support)
  useEffect(() => {
    if (liveEnabled || !meta || replayActive) return;
    if (!settings || !provider) return;
    let cancelled = false;
    setLoading(true);
    fetchAnalysis({ symbol, timeframe, limit: 1500, provider, settings })
      .then((d) => {
        if (cancelled) return;
        setData(d);
        setError(null);
        setSelected((cur) => (cur && d.analysis.setups.some((s) => s.id === cur) ? cur : null));
      })
      .catch((e: Error) => { if (!cancelled) setError(e.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [liveEnabled, meta, symbol, timeframe, provider, settings, reloadNonce, replayActive]);

  // ---- replay control
  const applyReplay = (st: ReplayState) => { setData(st); setForming(null); setReplay(st.replay); setLoading(false); setError(null); if (st.replay.at_end) setPlaying(false); };
  const replayCall = async (fn: () => Promise<ReplayState>) => {
    if (inFlight.current) return;
    inFlight.current = true; setReplayBusy(true);
    try { applyReplay(await fn()); } catch (e) { setError((e as Error).message); setPlaying(false); } finally { inFlight.current = false; setReplayBusy(false); }
  };
  const startReplay = (iso: string) => settings && replayCall(() => api.replayStart({ symbol, timeframe, provider, start: iso, limit: 600, settings }));
  const exitReplay = () => {
    if (replay) api.replayStop(replay.id).catch(() => undefined);
    setReplay(null); setPlaying(false); setReplayOpen(false); setReloadNonce((x) => x + 1);
  };
  useEffect(() => {
    if (!playing || !replay) return;
    const id = setInterval(() => { if (!inFlight.current) replayCall(() => api.replayStep(replay.id, 1)); }, Math.max(80, 1000 / speed));
    return () => clearInterval(id);
  }, [playing, speed, replay?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (replay) exitReplay(); }, [symbol, timeframe, provider]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---- multi-timeframe panel (refreshed every minute while live)
  useEffect(() => {
    if (isSnapshot || !settings || !provider || !active) return;
    let cancelled = false;
    const load = () => { setMtfLoading(true); api.mtf(symbol, provider, settings).then((m) => { if (!cancelled) setMtf(m); }).catch(() => { if (!cancelled) setMtf(null); }).finally(() => !cancelled && setMtfLoading(false)); };
    load();
    const id = replayActive ? undefined : setInterval(load, 60000);
    return () => { cancelled = true; if (id) clearInterval(id); };
  }, [symbol, provider, settings, active, replayActive]);

  // ---- economic calendar for news markers (refreshed every 10 minutes)
  const firstTime = data?.candles.length ? data.candles[0][0] : 0;
  useEffect(() => {
    if (isSnapshot || !firstTime) return;
    let cancelled = false;
    const load = () => api.calendar(firstTime - 86400, Date.now() / 1000 + 8 * 86400)
      .then((r) => { if (!cancelled) { setNews(r.events); setNewsError(r.error); } })
      .catch((e: Error) => { if (!cancelled) setNewsError(e.message); });
    load();
    const id = setInterval(load, 600000);
    return () => { cancelled = true; clearInterval(id); };
  }, [firstTime]);

  // ---- alerts on new live setups
  const alerts = useSetupAlerts(liveEnabled ? data : null, liveEnabled);

  const applySettings = useCallback((s: ICTSettings) => {
    setSettings(s);
    save('settings', s);
  }, []);

  const focusTime = useCallback((t: number) => setFocus({ time: t, nonce: Date.now() }), []);
  const selectSetup = useCallback((id: string | null) => {
    setSelected(id);
    if (id && !isMd) setTabRequest({ id: 'analysis-mobile', nonce: Date.now() });
    if (id) {
      const s = data?.analysis.setups.find((x) => x.id === id);
      if (s) focusTime(s.time);
    }
  }, [data, focusTime, isMd]);

  const selectedSetup = useMemo(() => data?.analysis.setups.find((s) => s.id === selected) ?? null, [data, selected]);
  const prec = data?.symbol_info.price_precision ?? 2;

  const layers = (
    <LayersPanel flags={flags} onFlags={setFlags} tool={tool} onTool={setTool} drawings={drawings.length} onClearDrawings={() => setDrawings([])} />
  );
  const rightContent = data && (selectedSetup ? (
    <SetupDetail setup={selectedSetup} precision={prec} tz={tz} edited={edited[selectedSetup.id]}
      onEdit={(lv) => setEdited((cur) => { const n = { ...cur }; if (lv) n[selectedSetup.id] = lv; else delete n[selectedSetup.id]; return n; })}
      onClose={() => setSelected(null)} onFocus={focusTime} />
  ) : (
    <AnalysisPanel data={data} tz={tz} onSelectSetup={(id) => selectSetup(id)} onFocus={focusTime} mtf={mtf} mtfLoading={mtfLoading} news={news} newsError={newsError} />
  ));

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-[#0b0e14] text-slate-200">
      <TopBar meta={meta} symbol={symbol} timeframe={timeframe} provider={provider} swingLength={settings?.structure.swing_length ?? 3} tz={tz}
        loading={loading} snapshot={isSnapshot} live={liveEnabled}
        onSymbol={(sym) => { setSymbol(sym); setSelected(null); setProvider(meta?.instruments?.find((i) => i.symbol === sym)?.default_provider ?? provider); }}
        onTimeframe={setTimeframe} onProvider={setProvider}
        onSwingLength={(n) => settings && applySettings({ ...settings, structure: { ...settings.structure, swing_length: n } })}
        onTz={setTz} onRefresh={() => setReloadNonce((x) => x + 1)} onSettings={() => setSettingsOpen(true)}
        onReplay={() => (replayOpen ? exitReplay() : setReplayOpen(true))} replayActive={replayOpen}
        extra={!isSnapshot ? <AlertsButton settings={alerts.settings} onSettings={alerts.setSettings} items={alerts.items} onPermission={alerts.requestPermission} tz={tz} onOpen={(id) => selectSetup(id)} /> : null} />
      {replayOpen && (
        <ReplayBar info={replay} playing={playing} speed={speed} busy={replayBusy} tz={tz} onStart={(iso) => { setPlaying(false); startReplay(iso); }}
          onPlay={setPlaying} onStep={() => replay && replayCall(() => api.replayStep(replay.id, 1))}
          onBack={() => replay && replayCall(() => api.replayBack(replay.id, 1))} onSpeed={setSpeed} onExit={exitReplay} />
      )}

      {!replayActive && <MarketStatus symbol={symbol} market={meta?.instruments?.find((i) => i.symbol === symbol)?.market ?? data?.symbol_info.market ?? ''}
        status={feedStatus} transport={liveEnabled ? transport : null} transportInfo={transportInfo} tick={tick}
        price={tick?.price ?? forming?.close ?? (data?.candles.length ? data.candles[data.candles.length - 1][4] : null)}
        precision={prec} tz={tz} staticDemo={isSnapshot} providerName={data?.provider.name ?? ''} />}
      {error && (
        <div className="border-b border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-[12px] text-rose-200">
          {error} {!isSnapshot && <span className="text-rose-300/70">— start the backend with <code className="rounded bg-black/30 px-1">python run.py</code> and refresh.</span>}
        </div>
      )}
      {data?.provider.warning && (
        <div className="border-b border-orange-500/20 bg-orange-500/[0.07] px-3 py-1 text-[11.5px] text-orange-200/90">⚠ {data.provider.warning}</div>
      )}

      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <aside className="hidden w-[188px] shrink-0 overflow-y-auto border-r border-[#1e2533] bg-[#0d1118] lg:block">{layers}</aside>

        <main className="flex min-w-0 flex-1 flex-col">
          <div className="relative h-[58vh] min-h-[320px] md:h-auto md:min-h-[300px] md:flex-1">
            <ChartView data={data} flags={flags} tz={tz} selectedSetup={selected} edited={edited} tool={tool} drawings={drawings} focus={focus} forming={forming} news={news}
              onSelectSetup={selectSetup} onDrawingsChange={setDrawings} />
            {loading && !data && <div className="absolute inset-0 grid place-items-center text-[13px] text-slate-400">Loading candles and running the ICT engine…</div>}
          </div>
          {data && (
            <div className="h-[46vh] min-h-[260px] border-t border-[#1e2533] bg-[#0f131b] md:h-[220px] md:min-h-0">
              <BottomPanel key={isMd ? 'md' : 'sm'} data={data} tz={tz} selectedSetup={selected} onSelectSetup={selectSetup} onFocus={focusTime}
                requestTab={tabRequest}
                extraTabsBefore={isMd ? [] : [{ id: 'analysis-mobile', label: selectedSetup ? 'Setup' : 'Analysis', content: rightContent }]}
                extraTab={isLg ? undefined : { label: 'Layers', content: layers }} />
            </div>
          )}
        </main>

        <aside className="hidden w-[330px] shrink-0 overflow-y-auto border-l border-[#1e2533] bg-[#0d1118] md:block">{rightContent}</aside>
      </div>

      <Disclaimer text={data?.disclaimer ?? meta?.disclaimer} />

      {settings && (
        <SettingsDrawer open={settingsOpen} settings={settings} defaults={meta?.default_settings ?? null} readOnly={isSnapshot}
          onApply={applySettings} onClose={() => setSettingsOpen(false)} meta={meta} />
      )}
      {!isSnapshot && <AlertToasts items={alerts.items} onDismiss={alerts.dismiss} onOpen={(id) => selectSetup(id)} />}
    </div>
  );
}
