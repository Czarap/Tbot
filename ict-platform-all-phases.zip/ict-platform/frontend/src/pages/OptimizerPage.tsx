import { useEffect, useRef, useState } from 'react';
import { fmtDate } from '../charts/format';
import { BacktestForm } from '../components/BacktestForm';
import { Banner, Card, Chips, Field, Num, Progress, loadLS, saveLS, signed, tone } from '../components/ui';
import { api, waitForJob } from '../services/api';
import type { DisplayTz, MetaResponse, OptimizeGrid, OptimizeResult, OptMetrics, OptParams, Timeframe } from '../types';
import { useStrategyInputs } from './BacktestPage';

const list = (s: string) => s.split(',').map((x) => Number(x.trim())).filter((x) => Number.isFinite(x) && x > 0);
const SESSION_SETS: Record<string, string[]> = { London: ['London'], 'New York': ['New York'], 'London + NY': ['London', 'New York'], Asia: ['Asia'], Any: [] };

function M({ m, dd = true }: { m?: OptMetrics; dd?: boolean }) {
  if (!m) return <td colSpan={dd ? 4 : 3} className="px-1.5 text-slate-600">—</td>;
  return (
    <>
      <td className="px-1.5">{m.total_trades}</td>
      <td className="px-1.5">{m.win_rate.toFixed(0)}%</td>
      <td className={`px-1.5 ${tone(m.expectancy_r)}`}>{signed(m.expectancy_r, 3)}</td>
      {dd && <td className="px-1.5 text-rose-300/80">{m.max_drawdown_pct.toFixed(1)}%</td>}
    </>
  );
}

const describe = (p: OptParams) => `${p.timeframe} · R:R ${p.min_rr} · sweep ${p.liquidity_sweep} · OB ${p.order_block} · ${p.sessions.join('+') || 'any session'} · ${p.risk_percent}%`;

export function OptimizerPage({ meta, tz, onBacktest }: { meta: MetaResponse | null; tz: DisplayTz; onBacktest: () => void }) {
  const { cfg, update } = useStrategyInputs(meta);
  const [grid, setGrid] = useState<OptimizeGrid | null>(null);
  const [split, setSplit] = useState({ train: 0.6, validation: 0.2, min_trades: 15, folds: 4 });
  const [job, setJob] = useState<{ progress: number; message: string; id: string } | null>(null);
  const [res, setRes] = useState<OptimizeResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const cancel = useRef({ cancelled: false });

  useEffect(() => { if (meta?.default_grid) setGrid(loadLS<OptimizeGrid>('opt.grid', meta.default_grid)); }, [meta]);
  useEffect(() => { if (grid) saveLS('opt.grid', grid); }, [grid]);

  if (!cfg || !grid) return <div className="p-6 text-slate-500">Loading…</div>;
  const signalRuns = grid.min_rr.length * grid.timeframes.length * grid.liquidity_sweep.length * grid.order_block.length * grid.displacement.length;
  const total = signalRuns * grid.risk_percent.length * grid.sessions.length;

  const run = async () => {
    setError(null); setRes(null);
    cancel.current = { cancelled: false };
    try {
      const j = await api.startOptimize({ base: cfg, grid, train: split.train, validation: split.validation, min_trades: split.min_trades, walk_forward_folds: split.folds, top_n: 10 });
      setJob({ progress: 0, message: 'Queued', id: j.id });
      const done = await waitForJob<OptimizeResult>(j.id, (x) => setJob({ progress: x.progress, message: x.message, id: x.id }), cancel.current);
      setRes(done.result ?? null);
    } catch (e) {
      if ((e as Error).message !== 'cancelled') setError((e as Error).message);
    } finally { setJob(null); }
  };

  const applyParams = (p: OptParams) => {
    const next = { ...cfg, timeframe: p.timeframe, min_rr: p.min_rr, sessions: p.sessions, risk: { ...cfg.risk, mode: 'fixed_percent' as const, risk_percent: p.risk_percent },
      settings: { ...cfg.settings, setups: { ...cfg.settings.setups, rules: { ...cfg.settings.setups.rules,
        liquidity_sweep: p.liquidity_sweep as 'required', order_block: p.order_block as 'scored', displacement: p.displacement as 'scored' } } } };
    update(next);
    saveLS('settings', next.settings);
    onBacktest();
  };

  const modes = ['required', 'scored', 'off'] as const;
  return (
    <div className="grid min-h-0 flex-1 md:grid-cols-[320px_1fr]">
      <aside className="overflow-y-auto border-r border-[#1e2533] bg-[#0d1118] p-3 md:max-h-[calc(100vh-40px)]">
        <h2 className="mb-3 text-[13px] font-semibold text-slate-100">Strategy optimizer</h2>
        <fieldset className="mb-3 space-y-2 border-b border-[#1e2533] pb-3 text-[12px]">
          <legend className="panel-h">Parameter grid</legend>
          <Field label="Risk % values"><input className="lv-input w-32" defaultValue={grid.risk_percent.join(', ')} onBlur={(e) => setGrid({ ...grid, risk_percent: list(e.target.value) })} /></Field>
          <Field label="Min R:R values"><input className="lv-input w-32" defaultValue={grid.min_rr.join(', ')} onBlur={(e) => setGrid({ ...grid, min_rr: list(e.target.value) })} /></Field>
          <Field label="Entry timeframes"><Chips options={['1m', '5m', '15m', '30m', '1h'] as const} value={grid.timeframes as ('1m' | '5m' | '15m' | '30m' | '1h')[]} onChange={(v) => setGrid({ ...grid, timeframes: v as Timeframe[] })} /></Field>
          <Field label="Sessions">
            <Chips options={Object.keys(SESSION_SETS)} value={Object.keys(SESSION_SETS).filter((k) => grid.sessions.some((s) => s.join() === SESSION_SETS[k].join()))}
              onChange={(v) => setGrid({ ...grid, sessions: v.map((k) => SESSION_SETS[k]) })} />
          </Field>
          <Field label="Liquidity sweep"><Chips options={modes} value={grid.liquidity_sweep as typeof modes[number][]} onChange={(v) => setGrid({ ...grid, liquidity_sweep: v })} /></Field>
          <Field label="Order block"><Chips options={modes} value={grid.order_block as typeof modes[number][]} onChange={(v) => setGrid({ ...grid, order_block: v })} /></Field>
          <Field label="Displacement"><Chips options={modes} value={grid.displacement as typeof modes[number][]} onChange={(v) => setGrid({ ...grid, displacement: v })} /></Field>
          <p className={`text-[11px] ${total > 2000 || signalRuns > 120 ? 'text-rose-300' : 'text-slate-500'}`}>{total} combinations · {signalRuns} signal runs (limit 2000 / 120)</p>
          <p className="text-[10.5px] leading-4 text-slate-500">The FVG is the entry mechanism of this model, so it is always required.</p>
        </fieldset>
        <fieldset className="mb-3 space-y-2 border-b border-[#1e2533] pb-3 text-[12px]">
          <legend className="panel-h">Validation</legend>
          <Field label="Training share"><Num value={split.train} step={0.05} min={0.2} max={0.8} onChange={(v) => setSplit({ ...split, train: v })} /></Field>
          <Field label="Validation share"><Num value={split.validation} step={0.05} min={0.1} max={0.4} onChange={(v) => setSplit({ ...split, validation: v })} /></Field>
          <p className="text-[11px] text-slate-500">Test (out-of-sample): {Math.round((1 - split.train - split.validation) * 100)}% — never used for ranking.</p>
          <Field label="Min validation trades"><Num value={split.min_trades} min={1} onChange={(v) => setSplit({ ...split, min_trades: v })} /></Field>
          <Field label="Walk-forward folds" hint="0 = off"><Num value={split.folds} min={0} max={12} onChange={(v) => setSplit({ ...split, folds: v })} /></Field>
        </fieldset>
        <details className="mb-3">
          <summary className="cursor-pointer text-[12px] text-slate-400">Base backtest settings</summary>
          <div className="mt-2"><BacktestForm meta={meta} value={cfg} onChange={update} compact /></div>
        </details>
        <div className="sticky bottom-0 bg-[#0d1118] pt-2">
          {job ? (
            <div className="space-y-2"><Progress value={job.progress} message={job.message} />
              <button className="tb-btn w-full" onClick={() => { cancel.current.cancelled = true; api.cancelJob(job.id).catch(() => undefined); }}>Cancel</button></div>
          ) : (
            <button className="w-full rounded-md bg-amber-500 py-2 text-[13px] font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-40"
              disabled={total === 0 || total > 2000 || signalRuns > 120} onClick={run}>Run optimization</button>
          )}
        </div>
      </aside>
      <main className="min-w-0 space-y-3 overflow-y-auto p-3 md:max-h-[calc(100vh-40px)]">
        <Banner>
          <b>Overfitting warning.</b> Testing many combinations on the same history always finds some that look good by luck. Results are ranked on the
          <b> validation</b> period (expectancy adjusted for trade count, decay from training and drawdown — not total profit). The <b>test</b> period is untouched
          until the end, and walk-forward shows how re-optimising would have performed on unseen data.
        </Banner>
        {error && <Banner kind="error">{error}</Banner>}
        {!res && !job && <p className="p-6 text-center text-[13px] text-slate-500">Set the grid on the left and run. Expect roughly a second per signal run per few thousand candles.</p>}
        {res && (
          <>
            {res.warnings.slice(2).map((w) => <Banner key={w} kind="error">{w}</Banner>)}
            <Card title="Periods">
              <div className="grid grid-cols-3 gap-2 text-[12px]">
                {(['train', 'validation', 'test'] as const).map((k) => (
                  <div key={k} className="rounded border border-[#1c2331] p-2"><div className="text-[10px] uppercase tracking-wider text-slate-500">{k}</div>
                    <div className="text-slate-300">{fmtDate(res.splits[k].start, tz)} → {fmtDate(res.splits[k].end, tz)}</div></div>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-slate-500">{res.combinations} combinations from {res.signal_runs} signal runs.</p>
            </Card>
            <Card title="Ranked combinations (by validation score)">
              <div className="max-h-[460px] overflow-auto">
                <table className="w-full text-[11.5px] tabular-nums">
                  <thead className="sticky top-0 bg-[#10151e] text-left text-[10px] uppercase tracking-wide text-slate-500">
                    <tr><th className="px-1.5 py-1">#</th><th className="px-1.5">Parameters</th><th className="px-1.5">Score</th>
                      <th className="px-1.5" colSpan={3}>Train (n · win · E[R])</th><th className="px-1.5" colSpan={4}>Validation (n · win · E[R] · DD)</th>
                      <th className="px-1.5" colSpan={4}>Test (n · win · E[R] · DD)</th><th /></tr>
                  </thead>
                  <tbody>
                    {res.results.slice(0, 60).map((r, i) => (
                      <tr key={i} className="border-t border-[#161c27]">
                        <td className="px-1.5 py-1 text-slate-500">{i + 1}</td>
                        <td className="px-1.5 text-slate-300">{describe(r.params)}</td>
                        <td className="px-1.5 text-amber-300">{r.score === null ? 'n/a' : r.score.toFixed(3)}</td>
                        <M m={r.train} dd={false} /><M m={r.validation} /><M m={r.test} />
                        <td className="px-1.5"><button className="text-[11px] text-sky-300 hover:underline" onClick={() => applyParams(r.params)}>Backtest</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="mt-2 text-[10.5px] text-slate-500">"n/a" = fewer validation trades than the minimum. Test results are shown only for the top 10.</p>
            </Card>
            {res.walk_forward && (
              <Card title="Walk-forward test" right={<span className={`text-[12px] font-semibold ${tone(res.walk_forward.combined_out_of_sample.net_r)}`}>
                Combined out-of-sample: {res.walk_forward.combined_out_of_sample.total_trades} trades · {signed(res.walk_forward.combined_out_of_sample.net_r)}R ·
                E[R] {signed(res.walk_forward.combined_out_of_sample.expectancy_r, 3)}</span>}>
                <table className="w-full text-[11.5px] tabular-nums">
                  <thead className="text-left text-[10px] uppercase tracking-wide text-slate-500"><tr><th className="py-1">Fold</th><th>Optimised on</th><th>Chosen parameters</th><th colSpan={4}>Next period (out-of-sample)</th></tr></thead>
                  <tbody>
                    {res.walk_forward.folds.map((f) => (
                      <tr key={f.fold} className="border-t border-[#161c27]">
                        <td className="py-1">{f.fold}</td>
                        <td className="text-slate-400">{fmtDate(f.in_sample.start, tz)} → {fmtDate(f.in_sample.end, tz)}</td>
                        <td className="text-slate-300">{f.chosen ? describe(f.chosen) : 'no eligible combination'}</td>
                        <M m={f.out_of_sample_metrics ?? undefined} />
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            )}
          </>
        )}
      </main>
    </div>
  );
}
