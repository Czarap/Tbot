import type { ReactNode } from 'react';
import type { DisplayTz, MetaResponse, Timeframe } from '../types';

interface Props {
  meta: MetaResponse | null;
  symbol: string;
  timeframe: Timeframe;
  provider: string;
  swingLength: number;
  tz: DisplayTz;
  loading: boolean;
  snapshot: boolean;
  live: boolean;
  onSymbol: (s: string) => void;
  onTimeframe: (tf: Timeframe) => void;
  onProvider: (p: string) => void;
  onSwingLength: (n: number) => void;
  onTz: (tz: DisplayTz) => void;
  onRefresh: () => void;
  onSettings: () => void;
  onReplay?: () => void;
  replayActive?: boolean;
  extra?: ReactNode;
}

const TFS: Timeframe[] = ['1m', '5m', '15m', '30m', '1h', '4h', '1d'];

export function TopBar(p: Props) {
  const inst = p.meta?.instruments?.find((i) => i.symbol === p.symbol);
  const providers = (p.meta?.providers ?? []).filter((x) => !inst || inst.providers.includes(x.id) || x.id === p.provider);
  const current = providers.find((x) => x.id === p.provider);
  return (
    <header className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-[#1e2533] bg-[#0d1118] px-3 py-2">
      <div className="flex overflow-hidden rounded-md border border-[#263042]" role="group" aria-label="Instrument">
        {(p.meta?.instruments ?? p.meta?.symbols ?? [{ symbol: p.symbol, market: '' }]).slice(0, 2).map((s) => (
          <button key={s.symbol} onClick={() => p.onSymbol(s.symbol)} title={s.market}
            className={`px-2.5 py-1 text-left leading-tight transition-colors ${s.symbol === p.symbol ? 'bg-[#1d2636] text-slate-50' : 'text-slate-400 hover:bg-[#151c28]'}`}>
            <span className="block text-[12px] font-bold">{s.symbol}</span>
            <span className="block text-[9.5px] text-slate-500">{s.market}</span>
          </button>
        ))}
      </div>

      {(p.meta?.instruments?.length ?? 0) > 2 && (
        <select aria-label="More instruments" className={`tb-select ${p.meta!.instruments!.slice(2).some((i) => i.symbol === p.symbol) ? '!border-amber-500/60 font-semibold' : ''}`}
          value={p.meta!.instruments!.slice(2).some((i) => i.symbol === p.symbol) ? p.symbol : ''} onChange={(e) => e.target.value && p.onSymbol(e.target.value)}>
          <option value="">More…</option>
          {p.meta!.instruments!.slice(2).map((i) => <option key={i.symbol} value={i.symbol}>{i.symbol} · {i.market}</option>)}
        </select>
      )}

      <div className="flex max-w-full overflow-x-auto rounded-md border border-[#263042]" role="group" aria-label="Timeframe">
        {TFS.map((tf) => (
          <button key={tf} onClick={() => p.onTimeframe(tf)}
            className={`px-2 py-1 text-[12px] font-medium tabular-nums transition-colors ${tf === p.timeframe ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-[#1a2230]'}`}>
            {tf}
          </button>
        ))}
      </div>

      <label className="flex items-center gap-1.5 text-[11px] text-slate-400" title="Swing sensitivity: candles on each side a swing must exceed">
        <span className="hidden sm:inline">Swing</span>
        <select className="tb-select" value={p.swingLength} disabled={p.snapshot} onChange={(e) => p.onSwingLength(Number(e.target.value))}>
          {[2, 3, 5, 10].map((n) => <option key={n} value={n}>{n}</option>)}
          {![2, 3, 5, 10].includes(p.swingLength) && <option value={p.swingLength}>{p.swingLength}</option>}
        </select>
      </label>

      <label className="flex items-center gap-1.5 text-[11px] text-slate-400">
        <span className="hidden sm:inline">Time</span>
        <select className="tb-select" value={p.tz} onChange={(e) => p.onTz(e.target.value as DisplayTz)}>
          <option value="America/New_York">New York</option>
          <option value="UTC">UTC</option>
          <option value="local">Local</option>
        </select>
      </label>

      <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
        {providers.length > 0 && (
          <select aria-label="Data provider" className="tb-select max-w-[120px] sm:max-w-[170px]" value={p.provider} disabled={p.snapshot} onChange={(e) => p.onProvider(e.target.value)}>
            {providers.map((x) => (
              <option key={x.id} value={x.id} disabled={!x.configured} title={x.setup_hint ?? x.description}>
                {x.name}{x.configured ? '' : ' — not configured'}
              </option>
            ))}
          </select>
        )}
        {current?.is_synthetic && <span className="hidden rounded border sm:inline border-orange-500/50 bg-orange-500/10 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-orange-300" title={current.warning ?? ''}>SIMULATED DATA</span>}
        {p.snapshot && <span className="whitespace-nowrap rounded border border-sky-500/40 bg-sky-500/10 px-1.5 py-0.5 text-[10px] font-semibold text-sky-300" title="Pre-computed engine output; run the backend to recompute with new settings">STATIC DEMO</span>}
        {!p.snapshot && !p.live && (
          <button className="tb-btn" onClick={p.onRefresh} disabled={p.loading} title="Reload data and re-run the analysis">
            {p.loading ? '…' : '↻'}<span className="hidden sm:inline">{p.loading ? ' Analysing' : ' Refresh'}</span>
          </button>
        )}
        {!p.snapshot && p.onReplay && (
          <button className={`tb-btn ${p.replayActive ? '!border-violet-400/70 !bg-violet-500/20 text-violet-100' : ''}`} onClick={p.onReplay} title="Market replay">⏪<span className="hidden sm:inline"> Replay</span></button>
        )}
        {p.extra}
        <button className="tb-btn" onClick={p.onSettings} title="Detection & setup settings" aria-label="Settings">⚙<span className="hidden sm:inline"> Settings</span></button>
      </div>
    </header>
  );
}
