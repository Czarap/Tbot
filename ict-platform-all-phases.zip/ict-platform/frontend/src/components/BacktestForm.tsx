import type { ReactNode } from 'react';
import type { BacktestConfig, MetaResponse, Timeframe } from '../types';
import { Chips, Field, Num, Toggle } from './ui';

const TFS: Timeframe[] = ['1m', '5m', '15m', '30m', '1h', '4h', '1d'];
const SESSIONS = ['Asia', 'London', 'New York'] as const;

interface Props {
  meta: MetaResponse | null;
  value: BacktestConfig;
  onChange: (c: BacktestConfig) => void;
  compact?: boolean; // optimizer: risk/rr/sessions/timeframe come from the grid
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="space-y-2 border-b border-[#1e2533] pb-3">
      <legend className="panel-h">{title}</legend>
      {children}
    </fieldset>
  );
}

export function BacktestForm({ meta, value: c, onChange, compact }: Props) {
  const set = <K extends keyof BacktestConfig>(k: K, v: BacktestConfig[K]) => onChange({ ...c, [k]: v });
  const inst = meta?.instruments ?? [];
  const provs = (meta?.providers ?? []).filter((p) => p.configured && (inst.find((i) => i.symbol === c.symbol)?.providers ?? []).includes(p.id));
  return (
    <div className="space-y-3 text-[12px]">
      <Group title="Market & period">
        <Field label="Instrument">
          <select className="tb-select" value={c.symbol} onChange={(e) => onChange({ ...c, symbol: e.target.value, provider: null })}>
            {inst.map((i) => <option key={i.symbol} value={i.symbol}>{i.symbol} · {i.market}</option>)}
          </select>
        </Field>
        <Field label="Data provider" hint="Long backtests need long history — CSV import or a keyed provider.">
          <select className="tb-select max-w-[150px]" value={c.provider ?? ''} onChange={(e) => set('provider', e.target.value || null)}>
            <option value="">Default</option>
            {provs.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </Field>
        {!compact && (
          <Field label="Timeframe">
            <select className="tb-select" value={c.timeframe} onChange={(e) => set('timeframe', e.target.value as Timeframe)}>
              {TFS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
        )}
        <Field label="Start date (UTC)"><input type="date" className="lv-input w-36" value={c.start ?? ''} onChange={(e) => set('start', e.target.value || null)} /></Field>
        <Field label="End date (UTC)"><input type="date" className="lv-input w-36" value={c.end ?? ''} onChange={(e) => set('end', e.target.value || null)} /></Field>
      </Group>

      <Group title="Account & risk">
        <Field label="Starting balance ($)"><Num value={c.starting_balance} step={1000} min={100} onChange={(v) => set('starting_balance', v)} /></Field>
        <Field label="Position sizing">
          <select className="tb-select" value={c.risk.mode} onChange={(e) => set('risk', { ...c.risk, mode: e.target.value as BacktestConfig['risk']['mode'] })}>
            <option value="fixed_percent">Fixed % risk</option><option value="fixed_dollar">Fixed $ risk</option><option value="fixed_lots">Fixed lot size</option>
          </select>
        </Field>
        {c.risk.mode === 'fixed_percent' && !compact && <Field label="Risk per trade (%)"><Num value={c.risk.risk_percent} step={0.05} min={0.01} onChange={(v) => set('risk', { ...c.risk, risk_percent: v })} /></Field>}
        {c.risk.mode === 'fixed_dollar' && <Field label="Risk per trade ($)"><Num value={c.risk.risk_dollar} step={50} onChange={(v) => set('risk', { ...c.risk, risk_dollar: v })} /></Field>}
        {c.risk.mode === 'fixed_lots' && <Field label="Lots per trade"><Num value={c.risk.lots} step={0.01} onChange={(v) => set('risk', { ...c.risk, lots: v })} /></Field>}
        <Field label="Min / max lots" hint="Position = risk ÷ (stop distance × contract size), then clamped">
          <span className="flex gap-1"><Num width="w-16" value={c.risk.min_lots} step={0.01} onChange={(v) => set('risk', { ...c.risk, min_lots: v })} />
            <Num width="w-16" value={c.risk.max_lots} step={1} onChange={(v) => set('risk', { ...c.risk, max_lots: v })} /></span>
        </Field>
        {!compact && <Field label="Minimum R:R"><Num value={c.min_rr} step={0.25} min={0.1} onChange={(v) => set('min_rr', v)} /></Field>}
        <Field label="Max trades per day"><Num value={c.max_trades_per_day} min={1} onChange={(v) => set('max_trades_per_day', v)} /></Field>
      </Group>

      <Group title="Filters">
        {!compact && <Field label="Sessions" hint="Empty = trade any time"><Chips options={SESSIONS} value={c.sessions as (typeof SESSIONS[number])[]} onChange={(v) => set('sessions', v)} /></Field>}
        <Field label="Directions"><Chips options={['bullish', 'bearish'] as const} value={c.directions} onChange={(v) => set('directions', v)} /></Field>
        <Field label="News filter" hint="Skip entries around high-impact USD releases"><Toggle checked={c.news.enabled} onChange={(v) => set('news', { ...c.news, enabled: v })} /></Field>
        {c.news.enabled && (
          <Field label="Minutes before / after">
            <span className="flex gap-1"><Num width="w-16" value={c.news.minutes_before} onChange={(v) => set('news', { ...c.news, minutes_before: v })} />
              <Num width="w-16" value={c.news.minutes_after} onChange={(v) => set('news', { ...c.news, minutes_after: v })} /></span>
          </Field>
        )}
      </Group>

      <Group title="Execution costs">
        <Field label="Spread (price)"><Num value={c.costs.spread} step={0.01} min={0} onChange={(v) => set('costs', { ...c.costs, spread: v })} /></Field>
        <Field label="Slippage (price)"><Num value={c.costs.slippage} step={0.01} min={0} onChange={(v) => set('costs', { ...c.costs, slippage: v })} /></Field>
        <Field label="Commission / lot ($)"><Num value={c.costs.commission_per_lot} step={0.5} min={0} onChange={(v) => set('costs', { ...c.costs, commission_per_lot: v })} /></Field>
        <Field label="SL & TP in one candle" hint="Unknowable from OHLC; stop-first is conservative">
          <select className="tb-select" value={c.same_bar} onChange={(e) => set('same_bar', e.target.value as BacktestConfig['same_bar'])}>
            <option value="sl_first">Assume stop first</option><option value="tp_first">Assume target first</option>
          </select>
        </Field>
      </Group>

      {!compact && (
        <Group title="Prop-firm simulation">
          <Toggle checked={c.prop.enabled} onChange={(v) => set('prop', { ...c.prop, enabled: v })} label="Apply prop-firm rules" />
          {c.prop.enabled && (
            <>
              <Field label="Starting balance ($)"><Num value={c.prop.starting_balance} step={5000} onChange={(v) => set('prop', { ...c.prop, starting_balance: v })} /></Field>
              <Field label="Daily loss limit ($)"><Num value={c.prop.daily_loss_limit} step={100} onChange={(v) => set('prop', { ...c.prop, daily_loss_limit: v })} /></Field>
              <Field label="Max drawdown ($)"><Num value={c.prop.max_drawdown} step={100} onChange={(v) => set('prop', { ...c.prop, max_drawdown: v })} /></Field>
              <Field label="Drawdown type">
                <select className="tb-select" value={c.prop.drawdown_mode} onChange={(e) => set('prop', { ...c.prop, drawdown_mode: e.target.value as 'static' | 'trailing' })}>
                  <option value="static">Static (from start)</option><option value="trailing">Trailing (from peak)</option>
                </select>
              </Field>
              <Field label="Profit target ($)"><Num value={c.prop.profit_target} step={500} onChange={(v) => set('prop', { ...c.prop, profit_target: v })} /></Field>
              <Field label="Max trades / day"><Num value={c.prop.max_trades_per_day ?? 0} min={0} onChange={(v) => set('prop', { ...c.prop, max_trades_per_day: v > 0 ? v : null })} /></Field>
              <Field label="Min trading days"><Num value={c.prop.min_trading_days} min={0} onChange={(v) => set('prop', { ...c.prop, min_trading_days: v })} /></Field>
            </>
          )}
        </Group>
      )}
      <p className="text-[10.5px] leading-4 text-slate-500">Setups use the ICT detection rules from the chart's Settings (or the selected profile). Entries fill at the next candle's open.</p>
    </div>
  );
}
