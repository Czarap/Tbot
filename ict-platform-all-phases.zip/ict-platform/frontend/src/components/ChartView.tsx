import { useEffect, useMemo, useRef, useState } from 'react';
import { CandleChart, type Tool } from '../charts/CandleChart';
import { fmtDateTime, fmtPrice } from '../charts/format';
import type { AnalysisResponse, CalendarEvent, Candle, DisplayTz, EditedLevels, HoverInfo, OverlayFlags, Trade } from '../types';

interface Props {
  data: AnalysisResponse | null;
  flags: OverlayFlags;
  tz: DisplayTz;
  selectedSetup: string | null;
  edited: Record<string, EditedLevels>;
  tool: Tool;
  drawings: number[];
  focus: { time: number; nonce: number } | null;
  forming?: Candle | null;
  trades?: Trade[];
  selectedTrade?: string | null;
  onSelectTrade?: (id: string) => void;
  news?: CalendarEvent[];
  hideWatermarkWarning?: boolean;
  onSelectSetup: (id: string | null) => void;
  onDrawingsChange: (d: number[]) => void;
}

const TF_SECONDS: Record<string, number> = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400 };

export function ChartView(p: Props) {
  const host = useRef<HTMLDivElement>(null);
  const chart = useRef<CandleChart | null>(null);
  const [hover, setHover] = useState<HoverInfo | null>(null);
  const [cross, setCross] = useState<Candle | null>(null);
  const [atLatest, setAtLatest] = useState(true);
  const cbs = useRef({ onSelectSetup: p.onSelectSetup, onDrawingsChange: p.onDrawingsChange, onSelectTrade: p.onSelectTrade });
  cbs.current = { onSelectSetup: p.onSelectSetup, onDrawingsChange: p.onDrawingsChange, onSelectTrade: p.onSelectTrade };

  const candles = useMemo<Candle[]>(() => (p.data?.candles ?? []).map(([time, open, high, low, close, volume]) => ({ time, open, high, low, close, volume })), [p.data]);

  useEffect(() => {
    if (!host.current) return;
    const c = new CandleChart(host.current, p.flags, {
      onHover: setHover,
      onCrosshair: setCross,
      onSelectSetup: (id) => cbs.current.onSelectSetup(id),
      onDrawingsChange: (d) => cbs.current.onDrawingsChange(d),
      onViewChange: setAtLatest,
      onSelectTrade: (id) => cbs.current.onSelectTrade?.(id),
    });
    chart.current = c;
    return () => { c.destroy(); chart.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const d = p.data;
    if (!chart.current || !d) return;
    chart.current.setData(candles, d.analysis, `${d.provider.id}|${d.symbol}|${d.timeframe}`, d.symbol_info.price_precision, TF_SECONDS[d.timeframe],
      `${d.symbol} · ${d.timeframe.toUpperCase()}`, d.provider.is_synthetic ? 'SIMULATED DATA — NOT REAL PRICES' : '');
    if (p.forming) chart.current.upsertCandle(p.forming);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.data, candles]);
  useEffect(() => { if (p.forming) chart.current?.upsertCandle(p.forming); }, [p.forming]);
  useEffect(() => { chart.current?.setTrades(p.trades ?? [], p.selectedTrade ?? null); }, [p.trades, p.selectedTrade]);
  useEffect(() => { chart.current?.setNews(p.news ?? []); }, [p.news]);

  useEffect(() => { chart.current?.setFlags(p.flags); }, [p.flags]);
  useEffect(() => { chart.current?.setTimezone(p.tz); }, [p.tz]);
  useEffect(() => { chart.current?.setSelectedSetup(p.selectedSetup); }, [p.selectedSetup]);
  useEffect(() => { chart.current?.setEdited(p.edited); }, [p.edited]);
  useEffect(() => { chart.current?.setTool(p.tool); }, [p.tool]);
  useEffect(() => { chart.current?.setDrawings(p.drawings); }, [p.drawings]);
  useEffect(() => { if (p.focus) chart.current?.focusTime(p.focus.time); }, [p.focus]);

  const prec = p.data?.symbol_info.price_precision ?? 2;
  const lastClosed = candles[candles.length - 1];
  const last = p.forming && (!lastClosed || p.forming.time >= lastClosed.time) ? p.forming : lastClosed;
  const shown = cross ?? last;
  const idxShown = shown ? candles.findIndex((c) => c.time === shown.time) : -1;
  const prevClose = shown ? (idxShown >= 0 ? candles[idxShown - 1]?.close : lastClosed?.close) : undefined;
  const chg = shown && prevClose ? shown.close - prevClose : 0;
  const up = shown ? shown.close >= shown.open : true;

  return (
    <div className="relative h-full w-full select-none">
      <div ref={host} className="absolute inset-0" />
      {shown && (
        <div className="pointer-events-none absolute left-2 top-1.5 z-10 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] leading-4">
          <span className="font-semibold text-slate-200">{p.data?.symbol} · {p.data?.timeframe.toUpperCase()}</span>
          <span className="text-slate-500">{fmtDateTime(shown.time, p.tz)}{shown === p.forming ? ' · forming' : ''}</span>
          {(['open', 'high', 'low', 'close'] as const).map((k) => (
            <span key={k} className="tabular-nums text-slate-400">
              {k[0].toUpperCase()} <span className={up ? 'text-teal-400' : 'text-rose-400'}>{fmtPrice(shown[k], prec)}</span>
            </span>
          ))}
          <span className={`tabular-nums ${chg >= 0 ? 'text-teal-400' : 'text-rose-400'}`}>{chg >= 0 ? '+' : ''}{fmtPrice(chg, prec)}</span>
          {shown.volume > 0 && <span className="tabular-nums text-slate-500">Vol {Math.round(shown.volume).toLocaleString()}</span>}
        </div>
      )}
      {hover && (
        <div
          className="pointer-events-none absolute z-20 max-w-[320px] rounded-md border border-slate-700/80 bg-slate-900/95 px-2.5 py-2 text-[11px] leading-[15px] text-slate-300 shadow-xl"
          style={{
            left: Math.min(hover.x + 14, (host.current?.clientWidth ?? 600) - 330),
            top: hover.y + 16 > (host.current?.clientHeight ?? 400) - 160 ? Math.max(4, hover.y - 150) : hover.y + 16,
          }}
        >
          <div className="mb-1 font-semibold" style={{ color: hover.color ?? '#e2e8f0' }}>{hover.title}</div>
          {hover.lines.map((l, i) => <div key={i}>{l}</div>)}
        </div>
      )}
      <div className="absolute bottom-9 right-[84px] z-10 flex gap-1">
        <button className="chart-btn" title="Zoom out" onClick={() => chart.current?.zoom(0.8)}>−</button>
        <button className="chart-btn" title="Zoom in" onClick={() => chart.current?.zoom(1.25)}>+</button>
        {!atLatest && <button className="chart-btn px-2" title="Scroll to the latest candle" onClick={() => chart.current?.scrollToLatest()}>Latest ⇥</button>}
      </div>
    </div>
  );
}
