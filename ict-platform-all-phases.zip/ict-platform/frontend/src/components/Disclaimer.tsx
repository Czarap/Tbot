export function Disclaimer({ text }: { text?: string }) {
  return (
    <footer className="border-t border-[#1e2533] bg-[#0b0e14] px-3 py-1 text-[10.5px] leading-4 text-slate-500">
      <span className="font-semibold text-slate-400">No automatic trading.</span>{' '}
      {text ?? 'Backtested results do not guarantee future performance.'} Detected setups are possible setups with hypothetical levels, never guaranteed trades.
    </footer>
  );
}
