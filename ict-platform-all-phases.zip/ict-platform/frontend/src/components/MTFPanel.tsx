import type { MTFResponse } from '../types';

const ICON: Record<string, string> = { aligned: '✅', conflict: '⚠️', waiting: '⏳', setup: '🎯', error: '✖' };
const ROLE: Record<string, string> = { bias: 'Bias', structure: 'Structure', setup: 'Setup', entry: 'Entry' };

export function MTFPanel({ mtf, loading }: { mtf: MTFResponse | null; loading: boolean }) {
  return (
    <section className="card">
      <div className="flex items-center justify-between">
        <h3 className="panel-h">Multi-timeframe</h3>
        {mtf && <span className={`badge ${mtf.overall === 'aligned' ? 'bg-emerald-500/15 text-emerald-300' : mtf.overall === 'mixed' ? 'bg-amber-500/15 text-amber-300' : 'bg-slate-600/30 text-slate-400'}`}>{mtf.overall.toUpperCase()}</span>}
      </div>
      {!mtf && <p className="text-[11px] text-slate-500">{loading ? 'Loading…' : 'Not available.'}</p>}
      {mtf && (
        <table className="w-full text-[11.5px]">
          <thead className="text-left text-[10px] uppercase tracking-wide text-slate-500"><tr><th className="font-medium">Timeframe</th><th className="font-medium">Role</th><th className="font-medium">Bias</th><th /></tr></thead>
          <tbody>
            {mtf.rows.map((r) => (
              <tr key={r.role} className="border-t border-[#161c27]" title={r.last_event ? `Last: ${r.last_event.type} ${r.last_event.direction}` : r.detail ?? ''}>
                <td className="py-1 font-semibold text-slate-200">{r.timeframe.toUpperCase()}</td>
                <td className="text-slate-500">{ROLE[r.role]}</td>
                <td className={r.status === 'setup' ? 'text-amber-300' : r.trend === 'bullish' ? 'text-emerald-300' : r.trend === 'bearish' ? 'text-rose-300' : 'text-slate-500'}>
                  {r.status === 'setup' ? 'SETUP' : r.trend ? r.trend.toUpperCase() : 'WAITING'}
                </td>
                <td className="text-right">{ICON[r.status]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <p className="mt-1 text-[10px] text-slate-600">Roles are set in Settings → Multi-timeframe.</p>
    </section>
  );
}
