import type { ReactNode } from 'react';
import type { GroupStat } from '../types';

export const money = (v: number | null | undefined, digits = 2) =>
  v === null || v === undefined || !isFinite(v) ? '—' : `${v < 0 ? '−' : ''}$${Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
export const signed = (v: number, digits = 2, suffix = '') => `${v > 0 ? '+' : v < 0 ? '−' : ''}${Math.abs(v).toFixed(digits)}${suffix}`;
export const duration = (s: number) => {
  if (!s) return '—';
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
};
export const tone = (v: number) => (v > 0 ? 'text-emerald-300' : v < 0 ? 'text-rose-300' : 'text-slate-300');

export function Card({ title, children, right, className = '' }: { title?: string; children: ReactNode; right?: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-[#1c2331] bg-[#10151e] p-3 ${className}`}>
      {(title || right) && (
        <div className="mb-2 flex items-center justify-between gap-2">
          {title && <h3 className="panel-h !mb-0">{title}</h3>}
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, className = '', hint }: { label: string; value: ReactNode; className?: string; hint?: string }) {
  return (
    <div className="rounded-md border border-[#1c2331] bg-[#0d1219] px-2.5 py-2" title={hint}>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className={`mt-0.5 text-[15px] font-semibold tabular-nums ${className}`}>{value}</div>
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="grid grid-cols-[1fr_auto] items-center gap-2 text-[12px] text-slate-300" title={hint}>
      <span>{label}{hint && <span className="block text-[10.5px] leading-4 text-slate-500">{hint}</span>}</span>
      {children}
    </label>
  );
}

export function Num({ value, onChange, step = 1, min, max, width = 'w-24', disabled }: { value: number; onChange: (v: number) => void; step?: number; min?: number; max?: number; width?: string; disabled?: boolean }) {
  return <input type="number" className={`lv-input ${width}`} value={Number.isFinite(value) ? value : ''} step={step} min={min} max={max} disabled={disabled}
    onChange={(e) => { const v = Number(e.target.value); if (Number.isFinite(v)) onChange(v); }} />;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <label className="inline-flex cursor-pointer items-center gap-2 text-[12px] text-slate-300">
      <input type="checkbox" className="h-4 w-4 accent-amber-500" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

export function Chips<T extends string>({ options, value, onChange }: { options: readonly T[]; value: T[]; onChange: (v: T[]) => void }) {
  return (
    <div className="flex flex-wrap gap-1">
      {options.map((o) => {
        const on = value.includes(o);
        return (
          <button key={o} type="button" onClick={() => onChange(on ? value.filter((x) => x !== o) : [...value, o])}
            className={`rounded border px-1.5 py-0.5 text-[11px] ${on ? 'border-amber-500/60 bg-amber-500/15 text-amber-200' : 'border-[#263042] text-slate-500 hover:text-slate-300'}`}>
            {o}
          </button>
        );
      })}
    </div>
  );
}

export function Progress({ value, message }: { value: number; message?: string }) {
  return (
    <div>
      <div className="h-1.5 overflow-hidden rounded bg-[#1a2230]"><div className="h-full bg-amber-500 transition-all" style={{ width: `${Math.round(value * 100)}%` }} /></div>
      {message && <div className="mt-1 text-[11px] text-slate-500">{Math.round(value * 100)}% · {message}</div>}
    </div>
  );
}

export function GroupTable({ rows, keyLabel, money: showMoney = true }: { rows: GroupStat[]; keyLabel: string; money?: boolean }) {
  if (!rows.length) return <p className="text-[12px] text-slate-500">No trades.</p>;
  return (
    <table className="w-full text-[11.5px] tabular-nums">
      <thead className="text-left text-[10px] uppercase tracking-wide text-slate-500">
        <tr><th className="py-1 font-medium">{keyLabel}</th><th className="font-medium">Trades</th><th className="font-medium">Win %</th><th className="font-medium">Net R</th>{showMoney && <th className="font-medium">P/L</th>}</tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key} className="border-t border-[#161c27]">
            <td className="py-1 pr-2 text-slate-300">{r.key}</td><td>{r.trades}</td><td>{r.win_rate.toFixed(1)}%</td>
            <td className={tone(r.net_r)}>{signed(r.net_r, 2, 'R')}</td>{showMoney && <td className={tone(r.net_pnl)}>{money(r.net_pnl, 0)}</td>}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function Banner({ kind = 'warn', children }: { kind?: 'warn' | 'error' | 'info'; children: ReactNode }) {
  const cls = kind === 'error' ? 'border-rose-500/30 bg-rose-500/10 text-rose-200' : kind === 'info' ? 'border-sky-500/30 bg-sky-500/10 text-sky-200' : 'border-amber-500/30 bg-amber-500/10 text-amber-100';
  return <div className={`rounded-md border px-3 py-2 text-[12px] leading-5 ${cls}`}>{children}</div>;
}

/** Trigger a file download of text content (works on a local server; may be blocked in sandboxed previews). */
export function downloadText(name: string, text: string, type = 'text/csv') {
  try {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch { /* ignore */ }
}

export function loadLS<T>(key: string, fallback: T): T {
  try { const raw = window.localStorage.getItem(`ict.${key}`); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
}
export function saveLS(key: string, v: unknown) {
  try { window.localStorage.setItem(`ict.${key}`, JSON.stringify(v)); } catch { /* ignore */ }
}

/** Fill keys added in newer versions into an older stored object. */
export function deepMerge<T>(defaults: T, stored: unknown): T {
  if (stored === null || typeof stored !== 'object' || Array.isArray(stored) || defaults === null || typeof defaults !== 'object' || Array.isArray(defaults)) {
    return (stored === undefined ? defaults : stored) as T;
  }
  const out: Record<string, unknown> = { ...(defaults as Record<string, unknown>) };
  for (const [k, v] of Object.entries(stored as Record<string, unknown>)) if (k in out) out[k] = deepMerge(out[k], v);
  return out as T;
}
