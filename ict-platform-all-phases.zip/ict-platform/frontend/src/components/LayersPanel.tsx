import type { Tool } from '../charts/CandleChart';
import type { OverlayFlags } from '../types';

const ITEMS: { key: keyof OverlayFlags; label: string; color: string; indent?: boolean }[] = [
  { key: 'structure', label: 'Market Structure', color: '#22c55e' },
  { key: 'swings', label: 'Swing labels', color: '#94a3b8', indent: true },
  { key: 'liquidity', label: 'Liquidity', color: '#38bdf8' },
  { key: 'swingLiquidity', label: 'Swing BSL / SSL', color: '#38bdf8', indent: true },
  { key: 'sweeps', label: 'Sweeps', color: '#fb923c', indent: true },
  { key: 'fvg', label: 'FVG', color: '#22c55e' },
  { key: 'filledFvg', label: 'Show filled', color: '#64748b', indent: true },
  { key: 'orderBlocks', label: 'Order Blocks', color: '#3b82f6' },
  { key: 'displacement', label: 'Displacement', color: '#facc15' },
  { key: 'premiumDiscount', label: 'Premium / Discount', color: '#a78bfa' },
  { key: 'previousLevels', label: 'Previous Day / Week', color: '#e2e8f0' },
  { key: 'sessions', label: 'Sessions', color: '#f59e0b' },
  { key: 'setups', label: 'Possible setups', color: '#60a5fa' },
  { key: 'volume', label: 'Volume', color: '#64748b' },
  { key: 'highLow', label: 'High / low markers', color: '#cbd5e1' },
];

interface Props {
  flags: OverlayFlags;
  onFlags: (f: OverlayFlags) => void;
  tool: Tool;
  onTool: (t: Tool) => void;
  drawings: number;
  onClearDrawings: () => void;
}

export function LayersPanel({ flags, onFlags, tool, onTool, drawings, onClearDrawings }: Props) {
  return (
    <div className="flex flex-col gap-4 p-3 text-[12px]">
      <section>
        <h3 className="panel-h">Drawing tools</h3>
        <div className="grid grid-cols-2 gap-1.5">
          <button className={`tool-btn ${tool === 'cursor' ? 'tool-on' : ''}`} onClick={() => onTool('cursor')}>↖ Cursor</button>
          <button className={`tool-btn ${tool === 'hline' ? 'tool-on' : ''}`} onClick={() => onTool('hline')} title="Click the chart to place a horizontal level">― H-Line</button>
        </div>
        {drawings > 0 && (
          <button className="mt-1.5 w-full text-left text-[11px] text-slate-500 hover:text-slate-300" onClick={onClearDrawings}>Clear {drawings} line{drawings > 1 ? 's' : ''}</button>
        )}
        {tool === 'hline' && <p className="mt-1.5 text-[11px] leading-4 text-amber-300/80">Click the chart to place a line. Click a line (cursor mode) to delete it.</p>}
      </section>
      <section>
        <h3 className="panel-h">Overlays</h3>
        <ul className="space-y-1">
          {ITEMS.map((it) => (
            <li key={it.key}>
              <label className={`flex cursor-pointer items-center gap-2 rounded px-1 py-0.5 hover:bg-[#151b26] ${it.indent ? 'ml-4 text-slate-400' : 'text-slate-200'}`}>
                <input type="checkbox" className="accent-amber-500" checked={flags[it.key]} onChange={(e) => onFlags({ ...flags, [it.key]: e.target.checked })} />
                <span className="inline-block h-2 w-2 rounded-sm" style={{ background: it.color }} />
                {it.label}
              </label>
            </li>
          ))}
        </ul>
      </section>
      <p className="text-[10.5px] leading-4 text-slate-500">Hover any zone, line or label on the chart to see exactly why it was detected.</p>
    </div>
  );
}
