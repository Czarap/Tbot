import { useState } from 'react';
import { fmtDateTime } from '../charts/format';
import type { DisplayTz, ReplayInfo } from '../types';

export const SPEEDS = [0.5, 1, 2, 5, 10];

interface Props {
  info: ReplayInfo | null;
  playing: boolean;
  speed: number;
  busy: boolean;
  tz: DisplayTz;
  onStart: (isoUtc: string) => void;
  onPlay: (p: boolean) => void;
  onStep: () => void;
  onBack: () => void;
  onSpeed: (s: number) => void;
  onExit: () => void;
}

export function ReplayBar(p: Props) {
  const [when, setWhen] = useState(() => {
    const d = new Date(Date.now() - 7 * 86400000);
    return d.toISOString().slice(0, 16);
  });
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-violet-500/30 bg-violet-500/[0.07] px-3 py-1.5 text-[12px]">
      <span className="font-bold tracking-wide text-violet-200">⏪ REPLAY</span>
      <label className="flex items-center gap-1 text-slate-400">From (UTC)
        <input type="datetime-local" className="lv-input w-[170px] !text-left" value={when} onChange={(e) => setWhen(e.target.value)} />
      </label>
      <button className="tb-btn" onClick={() => p.onStart(`${when}:00Z`)} disabled={p.busy}>Start here</button>
      {p.info && (
        <>
          <span className="mx-1 h-4 w-px bg-slate-700" />
          <button className="tb-btn" title="Previous candle" onClick={p.onBack} disabled={p.busy || p.playing}>⏮</button>
          <button className="tb-btn min-w-[64px]" onClick={() => p.onPlay(!p.playing)} disabled={p.info.at_end}>{p.playing ? '⏸ Pause' : '▶ Play'}</button>
          <button className="tb-btn" title="Next candle" onClick={p.onStep} disabled={p.busy || p.playing || p.info.at_end}>⏭</button>
          <select className="tb-select" value={p.speed} onChange={(e) => p.onSpeed(Number(e.target.value))} title="Candles per second">
            {SPEEDS.map((s) => <option key={s} value={s}>{s}x</option>)}
          </select>
          <span className="tabular-nums text-slate-300">{fmtDateTime(p.info.time, p.tz)}</span>
          <span className="text-slate-500">{p.info.remaining.toLocaleString()} candles left</span>
          {p.info.new_setups.length > 0 && <span className="badge bg-amber-500/20 text-amber-200">{p.info.new_setups[0].label}</span>}
        </>
      )}
      <span className="ml-auto text-[11px] text-slate-500">Future candles are hidden; the ICT engine only knows data up to the replay candle.</span>
      <button className="tb-btn" onClick={p.onExit}>Exit replay</button>
    </div>
  );
}
