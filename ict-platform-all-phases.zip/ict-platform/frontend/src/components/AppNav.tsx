export type Page = 'chart' | 'backtest' | 'optimizer' | 'journal';

const PAGES: { id: Page; label: string }[] = [
  { id: 'chart', label: 'Chart' },
  { id: 'backtest', label: 'Backtest' },
  { id: 'optimizer', label: 'Optimizer' },
  { id: 'journal', label: 'Journal' },
];

export function AppNav({ page, onPage, staticDemo }: { page: Page; onPage: (p: Page) => void; staticDemo: boolean }) {
  return (
    <nav className="flex h-10 shrink-0 items-center gap-1 border-b border-[#1e2533] bg-[#090c12] px-3">
      <div className="mr-3 flex items-center gap-2">
        <div className="grid h-6 w-6 place-items-center rounded bg-gradient-to-br from-amber-400 to-amber-600 text-[10px] font-black text-slate-900">ICT</div>
        <span className="hidden text-[12.5px] font-semibold text-slate-100 sm:inline">ICT Lab</span>
        <span className="hidden text-[10px] text-slate-500 lg:inline">analysis only · no order execution</span>
      </div>
      {PAGES.filter((p) => !staticDemo || p.id === 'chart').map((p) => (
        <a key={p.id} href={`#${p.id}`} onClick={(e) => { e.preventDefault(); onPage(p.id); }}
          className={`rounded px-2.5 py-1 text-[12px] font-medium ${page === p.id ? 'bg-[#1d2636] text-slate-50' : 'text-slate-400 hover:text-slate-200'}`}>{p.label}</a>
      ))}
    </nav>
  );
}
