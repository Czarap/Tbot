import { useState } from 'react';
import { api } from '../services/api';
import type { MetaResponse, Timeframe } from '../types';

export function DataSources({ meta }: { meta: MetaResponse | null }) {
  const [file, setFile] = useState<File | null>(null);
  const [symbol, setSymbol] = useState('XAUUSD');
  const [tf, setTf] = useState<Timeframe>('1m');
  const [tz, setTz] = useState('UTC');
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const upload = async () => {
    if (!file) return;
    setBusy(true); setMsg(null);
    try {
      const r = await api.upload(file, symbol, tf, tz);
      setMsg(`✓ Saved ${r.rows.toLocaleString()} candles as ${r.saved}. Choose "CSV files" as the data provider (restart not needed).`);
    } catch (e) { setMsg(`✗ ${(e as Error).message}`); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-2 text-[12px]">
      <ul className="space-y-1">
        {(meta?.providers ?? []).map((p) => (
          <li key={p.id} className="flex items-start justify-between gap-2">
            <span><span className="text-slate-200">{p.name}</span> <span className="text-slate-500">· {p.symbols.join(', ') || '—'}</span>
              {!p.configured && p.setup_hint && <span className="block text-[10.5px] text-amber-300/80">{p.setup_hint}</span>}</span>
            <span className={`badge ${p.configured ? 'bg-emerald-500/15 text-emerald-300' : 'bg-slate-600/30 text-slate-400'}`}>{p.configured ? (p.is_synthetic ? 'SIM' : 'READY') : 'OFF'}</span>
          </li>
        ))}
      </ul>
      <div className="rounded border border-[#1c2331] p-2">
        <div className="mb-1 font-semibold text-slate-300">Import historical candles (CSV)</div>
        <p className="mb-2 text-[10.5px] leading-4 text-slate-500">For long backtests. Generic, MetaTrader, Dukascopy and HistData formats are recognised.</p>
        <input type="file" accept=".csv,.txt" className="mb-2 block w-full text-[11px] text-slate-400" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        <div className="flex flex-wrap gap-1.5">
          <select className="tb-select" value={symbol} onChange={(e) => setSymbol(e.target.value)}>
            {(meta?.instruments ?? [{ symbol: 'XAUUSD' }]).map((i) => <option key={i.symbol}>{i.symbol}</option>)}</select>
          <select className="tb-select" value={tf} onChange={(e) => setTf(e.target.value as Timeframe)}>
            {['1m', '5m', '15m', '30m', '1h', '4h', '1d'].map((t) => <option key={t}>{t}</option>)}</select>
          <input className="lv-input w-28 !text-left" value={tz} onChange={(e) => setTz(e.target.value)} title="Time zone of the timestamps in the file" />
          <button className="tb-btn" disabled={!file || busy} onClick={upload}>{busy ? 'Uploading…' : 'Upload'}</button>
        </div>
        {msg && <p className={`mt-2 text-[11px] ${msg.startsWith('✓') ? 'text-emerald-300' : 'text-rose-300'}`}>{msg}</p>}
      </div>
    </div>
  );
}
