import { useState } from 'react';
import { fmtDateTime } from '../charts/format';
import type { AlertItem, AlertSettings } from '../services/alerts';
import type { DisplayTz } from '../types';

interface Props {
  settings: AlertSettings;
  onSettings: (s: AlertSettings) => void;
  items: AlertItem[];
  onPermission: () => Promise<string>;
  tz: DisplayTz;
  onOpen: (id: string) => void;
}

export function AlertsButton(p: Props) {
  const [open, setOpen] = useState(false);
  const perm = typeof Notification === 'undefined' ? 'unsupported' : Notification.permission;
  return (
    <div className="relative">
      <button className="tb-btn relative" onClick={() => setOpen(!open)} title="Setup alerts" aria-label="Alerts">
        🔔{p.items.length > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[9px] font-bold text-slate-950">{p.items.length}</span>}
      </button>
      {open && (
        <div className="absolute right-0 top-9 z-40 w-[300px] rounded-lg border border-[#263042] bg-[#0f131b] p-3 text-[12px] shadow-2xl">
          <div className="mb-2 flex items-center justify-between"><b className="text-slate-100">Setup alerts</b>
            <button className="text-slate-500 hover:text-slate-200" onClick={() => setOpen(false)}>✕</button></div>
          <label className="flex items-center gap-2"><input type="checkbox" className="accent-amber-500" checked={p.settings.enabled}
            onChange={(e) => p.onSettings({ ...p.settings, enabled: e.target.checked })} /> Alert on new possible setups (live chart)</label>
          <label className="mt-1 flex items-center gap-2"><input type="checkbox" className="accent-amber-500" checked={p.settings.sound}
            onChange={(e) => p.onSettings({ ...p.settings, sound: e.target.checked })} /> Sound</label>
          <div className="mt-1 flex items-center gap-2">
            <input type="checkbox" className="accent-amber-500" checked={p.settings.browser && perm === 'granted'} disabled={perm !== 'granted'}
              onChange={(e) => p.onSettings({ ...p.settings, browser: e.target.checked })} /> Browser notifications
            {perm !== 'granted' && perm !== 'unsupported' && <button className="text-sky-300 hover:underline" onClick={() => p.onPermission()}>allow…</button>}
            {perm === 'unsupported' && <span className="text-slate-500">(not supported here)</span>}
          </div>
          <label className="mt-1 flex items-center justify-between">Minimum confluence
            <input type="number" className="lv-input w-16" min={0} max={10} value={p.settings.minScore} onChange={(e) => p.onSettings({ ...p.settings, minScore: Number(e.target.value) })} /></label>
          <p className="mt-2 text-[10.5px] text-slate-500">Alerts only inform you. Nothing is ever executed.</p>
          <div className="mt-2 max-h-56 space-y-1 overflow-y-auto border-t border-[#1e2533] pt-2">
            {p.items.length === 0 && <p className="text-slate-500">No alerts yet.</p>}
            {p.items.map((a) => (
              <button key={a.id + a.at} onClick={() => { p.onOpen(a.id); setOpen(false); }} className="block w-full rounded px-1 py-1 text-left hover:bg-[#151b26]">
                <span className={a.setup.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}>{a.setup.label}</span>
                <span className="text-amber-300"> {a.setup.score}/{a.setup.max_score}</span>
                <div className="text-[10.5px] text-slate-500">{a.symbol} {a.timeframe} · {fmtDateTime(a.setup.time, p.tz)}</div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function AlertToasts({ items, onDismiss, onOpen }: { items: AlertItem[]; onDismiss: (id: string) => void; onOpen: (id: string) => void }) {
  const recent = items.filter((a) => Date.now() - a.at < 20000).slice(0, 3);
  return (
    <div className="pointer-events-none fixed bottom-10 right-4 z-50 space-y-2">
      {recent.map((a) => (
        <div key={a.id + a.at} className="pointer-events-auto w-[290px] rounded-lg border border-amber-500/40 bg-[#111722] p-3 text-[12px] shadow-2xl">
          <div className="flex justify-between"><b className={a.setup.direction === 'bullish' ? 'text-emerald-300' : 'text-rose-300'}>{a.setup.label}</b>
            <button className="text-slate-500" onClick={() => onDismiss(a.id)}>✕</button></div>
          <div className="text-slate-300">{a.symbol} · {a.timeframe.toUpperCase()} · Confluence {a.setup.score}/{a.setup.max_score}</div>
          <div className="tabular-nums text-slate-400">Hypothetical entry {a.setup.entry} · SL {a.setup.stop_loss} · TP {a.setup.take_profit}</div>
          <button className="mt-1 text-sky-300 hover:underline" onClick={() => onOpen(a.id)}>Show reasoning</button>
        </div>
      ))}
    </div>
  );
}
