import { fmtPrice, fmtTime } from '../charts/format';
import type { TransportState } from '../services/live';
import type { DisplayTz, FeedStatus, LiveTick } from '../types';

interface Props {
  symbol: string;
  market: string;
  status: FeedStatus | null;
  transport: TransportState | null;
  transportInfo: { transport: string; retryIn?: number; attempt: number } | null;
  tick: LiveTick | null;
  price: number | null;
  precision: number;
  tz: DisplayTz;
  staticDemo: boolean;
  providerName: string;
}

const DOT: Record<string, string> = {
  live: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)] animate-pulse',
  delayed: 'bg-amber-400',
  connecting: 'bg-sky-400 animate-pulse',
  reconnecting: 'bg-rose-500 animate-pulse',
  disconnected: 'bg-rose-500',
  market_closed: 'bg-slate-500',
  simulated: 'bg-violet-400 animate-pulse',
  historical: 'bg-slate-500',
};
const TEXT: Record<string, string> = {
  live: 'text-emerald-300', delayed: 'text-amber-300', connecting: 'text-sky-300', reconnecting: 'text-rose-300',
  disconnected: 'text-rose-300', market_closed: 'text-slate-400', simulated: 'text-violet-300', historical: 'text-slate-400',
};

/** Effective state shown to the user: a dead browser connection always wins over the server's feed state. */
export function effectiveState(status: FeedStatus | null, transport: TransportState | null): { state: string; label: string } {
  if (transport === 'reconnecting') return { state: 'reconnecting', label: 'DISCONNECTED' };
  if (transport === 'connecting' && !status) return { state: 'connecting', label: 'CONNECTING' };
  if (!status) return { state: 'connecting', label: 'CONNECTING' };
  return { state: status.state, label: status.label };
}

export function MarketStatus(p: Props) {
  const eff = p.staticDemo ? { state: 'historical', label: 'STATIC DEMO' } : effectiveState(p.status, p.transport);
  const lost = eff.state === 'reconnecting' || eff.state === 'disconnected';
  const s = p.status;
  const src = s ? `${s.provider_name}${s.transport && s.transport !== 'none' ? ` (${s.transport === 'websocket' ? 'WebSocket' : s.transport})` : ''}` : p.providerName;
  return (
    <div className="border-b border-[#1e2533] bg-[#0b0f16]">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-3 py-1.5 text-[11.5px]">
        <div className="flex items-center gap-2">
          <span className="text-[14px] font-bold tracking-wide text-slate-100">{p.symbol}</span>
          <span className="text-slate-400">{p.market}</span>
          <span className={`inline-flex items-center gap-1.5 rounded px-1.5 py-0.5 text-[10.5px] font-bold tracking-wider ${TEXT[eff.state] ?? 'text-slate-300'} bg-white/[0.04]`}
            title={s?.message ?? ''}>
            <span className={`inline-block h-2 w-2 rounded-full ${DOT[eff.state] ?? 'bg-slate-500'}`} />
            {eff.label}
          </span>
        </div>
        {p.price !== null && (
          <span className="tabular-nums text-[13px] font-semibold text-slate-100">{fmtPrice(p.price, p.precision)}
            {p.tick?.bid != null && p.tick?.ask != null && (
              <span className="ml-2 text-[11px] font-normal text-slate-500">bid {fmtPrice(p.tick.bid, p.precision)} · ask {fmtPrice(p.tick.ask, p.precision)}</span>
            )}
          </span>
        )}
        <span className="text-slate-500">Data source: <span className="text-slate-300">{src}</span></span>
        {s && s.lag_seconds != null && eff.state !== 'reconnecting' && (
          <span className="tabular-nums text-slate-500">lag {s.lag_seconds < 10 ? s.lag_seconds.toFixed(1) : Math.round(s.lag_seconds)}s</span>
        )}
        {s?.last_update && <span className="tabular-nums text-slate-500">updated {fmtTime(s.last_update, p.tz)}:{String(Math.floor(s.last_update % 60)).padStart(2, '0')}</span>}
        {s?.message && !lost && <span className="text-slate-500">{s.message}</span>}
      </div>
      {lost && !p.staticDemo && (
        <div className="flex items-center gap-2 border-t border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-[12px] font-semibold text-rose-200">
          ⚠ Connection Lost — Reconnecting…
          <span className="font-normal text-rose-300/80">
            {p.transport === 'reconnecting' ? `browser ↔ server${p.transportInfo?.retryIn ? `, retry in ${Math.ceil(p.transportInfo.retryIn)}s` : ''}`
              : `${s?.message ?? 'data provider'}${s?.retry_in ? ` (retry in ${Math.ceil(s.retry_in)}s)` : ''}`}
          </span>
        </div>
      )}
    </div>
  );
}
