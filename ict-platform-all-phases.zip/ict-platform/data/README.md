Put real historical candles here as `<SYMBOL>_<TF>.csv`, e.g. `XAUUSD_1m.csv` or `XAUUSD_1h.csv`.
Supported formats: generic (time,open,high,low,close[,volume]), MetaTrader export, Dukascopy, HistData.
When a CSV is present the backend uses it automatically (ICT_DATA_PROVIDER=auto).
Set ICT_CSV_TZ if your timestamps are not UTC (e.g. ICT_CSV_TZ=Etc/GMT-2 for many MT5 brokers).
