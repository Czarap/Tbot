import json

import numpy as np
import pandas as pd

from backend.market_data.cleaning import clean_candles
from backend.market_data.csv_provider import parse_candle_csv
from backend.market_data.market_hours import is_market_closed
from backend.market_data.resample import bucket_start, resample


def utc(s: str) -> int:
    return int(pd.Timestamp(s, tz="UTC").timestamp())


def ny(s: str) -> int:
    return int(pd.Timestamp(s, tz="America/New_York").tz_convert("UTC").timestamp())


# ------------------------------------------------------------------ cleaning
def test_cleaning_duplicates_nans_sorting_and_ohlc():
    t0 = ny("2026-03-10 09:00")
    df = pd.DataFrame({
        "time": [t0 + 120, t0, t0 + 60, t0 + 60, t0 + 180],
        "open": [10, 10, 11, 11.5, None],
        "high": [11, 9, 12, 12, 13],      # row t0 has high < open -> fixed
        "low": [9, 8, 10, 10, 9],
        "close": [10.5, 9.5, 11.5, 11.8, 12],
        "volume": [1, 1, 1, 2, 1],
    })
    out, rep = clean_candles(df, 60)
    assert rep.was_unsorted and rep.duplicates_removed == 1 and rep.invalid_rows_removed == 1
    assert list(out["time"]) == [t0, t0 + 60, t0 + 120]
    assert out.loc[0, "high"] == 10  # max(o,h,l,c)
    assert out.loc[1, "close"] == 11.8  # duplicate keeps the last row
    assert rep.ohlc_fixed == 1


def test_gap_detection_ignores_weekend():
    fri = ny("2026-03-13 16:58")
    sun = ny("2026-03-15 18:00")
    times = [fri, fri + 60, sun, sun + 60, sun + 600]  # weekend gap (expected) + 8 missing minutes (unexpected)
    df = pd.DataFrame({"time": times, "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": 0})
    _, rep = clean_candles(df, 60)
    assert rep.gaps_total == 2 and rep.gaps_unexpected == 1
    assert rep.unexpected_gap_samples[0]["missing_seconds"] == 480


def test_market_hours():
    assert is_market_closed(np.array([ny("2026-03-14 12:00")]))[0]  # Saturday
    assert is_market_closed(np.array([ny("2026-03-10 17:30")]))[0]  # daily break
    assert not is_market_closed(np.array([ny("2026-03-10 09:30")]))[0]


# ---------------------------------------------------------------- resampling
def test_resample_5m_ohlc():
    t0 = utc("2026-03-10 14:00")
    df = pd.DataFrame({"time": [t0 + 60 * i for i in range(10)], "open": np.arange(10.0), "high": np.arange(10.0) + 1,
                       "low": np.arange(10.0) - 1, "close": np.arange(10.0) + 0.5, "volume": 1.0})
    r = resample(df, "5m")
    assert list(r["time"]) == [t0, t0 + 300]
    assert r.iloc[0][["open", "high", "low", "close", "volume"]].tolist() == [0, 5, -1, 4.5, 5]


def test_daily_rollover_at_17_new_york_in_winter_and_summer():
    for day, prev in (("2026-01-14", "2026-01-13"), ("2026-07-15", "2026-07-14")):
        t_before = ny(f"{prev} 16:59")
        t_after = ny(f"{prev} 17:00")
        b = bucket_start(np.array([t_before, t_after]), "1d")
        assert b[1] == ny(f"{prev} 17:00")
        assert b[0] == ny(f"{prev} 17:00") - 86400 or b[0] < b[1]
        assert b[0] != b[1]


def test_4h_buckets_anchor_on_rollover():
    b = bucket_start(np.array([ny("2026-03-10 10:30"), ny("2026-03-10 13:00"), ny("2026-03-10 22:00")]), "4h")
    assert list(b) == [ny("2026-03-10 09:00"), ny("2026-03-10 13:00"), ny("2026-03-10 21:00")]


def test_weekly_bucket_starts_sunday_17():
    b = bucket_start(np.array([ny("2026-03-11 10:00")]), "1w")
    assert b[0] == ny("2026-03-08 17:00")


# --------------------------------------------------------------- CSV formats
def test_csv_generic_epoch_and_iso():
    df = parse_candle_csv("time,open,high,low,close,volume\n1773122400,1,2,0.5,1.5,10\n")
    assert df["time"].iloc[0] == 1773122400
    df = parse_candle_csv("timestamp,open,high,low,close\n2026-03-10T06:00:00Z,1,2,0.5,1.5\n")
    assert df["time"].iloc[0] == 1773122400 and df["volume"].iloc[0] == 0


def test_csv_metatrader_format():
    text = "<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\n2026.03.10\t06:00:00\t1\t2\t0.5\t1.5\t42\n"
    df = parse_candle_csv(text, tz="UTC")
    assert df["time"].iloc[0] == 1773122400 and df["volume"].iloc[0] == 42


def test_csv_dukascopy_format():
    text = "Gmt time,Open,High,Low,Close,Volume\n10.03.2026 06:00:00.000,1,2,0.5,1.5,3.2\n"
    assert parse_candle_csv(text)["time"].iloc[0] == 1773122400


def test_csv_histdata_format_is_est():
    text = "20260310 010000;1;2;0.5;1.5;0\n"  # 01:00 EST == 06:00 UTC
    assert parse_candle_csv(text)["time"].iloc[0] == 1773122400
