import json

import pytest

from backend.ict_engine import ICTSettings
from backend.market_data.csv_provider import CSVProvider
from backend.market_data.service import MarketDataService
from backend.market_data.synthetic import SyntheticProvider, generate_xauusd_1m
from backend.services.analysis_service import AnalysisService

END = 1795000000


@pytest.fixture(scope="module")
def service():
    return AnalysisService(MarketDataService({"synthetic": SyntheticProvider(days=60, end_utc=END)}, "synthetic"))


@pytest.mark.parametrize("tf", ["1m", "5m", "15m", "30m", "1h", "4h", "1d"])
def test_analysis_payload_is_strict_json_for_every_timeframe(service, tf):
    out = service.analyze("XAUUSD", tf, limit=300)
    json.dumps(out, allow_nan=False)  # NaN/inf would break browsers
    assert len(out["candles"]) <= 300 and out["provider"]["is_synthetic"] is True
    first = out["candles"][0][0]
    a = out["analysis"]
    assert all(s["time"] >= first for s in a["setups"])
    assert all(e["time"] >= first for e in a["structure_events"])
    times = [c[0] for c in out["candles"]]
    assert times == sorted(times) and len(set(times)) == len(times)


def test_htf_is_always_higher_than_chart_tf(service):
    s = ICTSettings()
    s.setups.htf_timeframe = "5m"
    assert service.resolve_htf("15m", s) is None
    assert service.resolve_htf("1m", s) == "5m"


def test_settings_change_changes_result(service):
    a = service.analyze("XAUUSD", "15m", 500)
    s = ICTSettings()
    s.structure.swing_length = 10
    b = service.analyze("XAUUSD", "15m", 500, settings=s)
    assert len(b["analysis"]["swings"]) < len(a["analysis"]["swings"])


def test_csv_provider_end_to_end(tmp_path):
    df = generate_xauusd_1m(days=10, end_utc=END, seed=1)
    df.to_csv(tmp_path / "XAUUSD_1m.csv", index=False)
    svc = AnalysisService(MarketDataService({"csv": CSVProvider(tmp_path)}, "csv"))
    out = svc.analyze("XAUUSD", "5m", limit=400)
    assert out["provider"]["is_synthetic"] is False and out["source_timeframe"] == "1m"
    assert len(out["candles"]) == 400
