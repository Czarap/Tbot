from tests.helpers import LONG_ROWS, feed, long_settings, mirror


def test_bullish_order_block_is_last_down_close_candle_before_bos():
    e = feed(LONG_ROWS, long_settings())
    obs = e.order_blocks.blocks
    assert len(obs) == 1
    ob = obs[0]
    assert ob.direction == "bullish" and ob.index == 5 and ob.created_index == 6  # known at the BOS candle
    assert (ob.bottom, ob.top) == (97.5, 99.9)  # wick zone of candle 5
    assert any("BOS" in line for line in ob.explanation)


def test_body_zone_option():
    s = long_settings()
    s.order_blocks.zone = "body"
    ob = feed(LONG_ROWS, s).order_blocks.blocks[0]
    assert (ob.bottom, ob.top) == (98.6, 99.8)


def test_bearish_order_block_mirror():
    ob = feed(mirror(LONG_ROWS), long_settings()).order_blocks.blocks[0]
    assert ob.direction == "bearish" and ob.index == 5
    assert (round(ob.bottom, 6), round(ob.top, 6)) == (100.1, 102.5)


def test_mitigation_and_invalidation():
    rows = LONG_ROWS + [(102.6, 102.7, 99.5, 100.0)]   # trades into 97.5-99.9 -> mitigated
    ob = feed(rows, long_settings()).order_blocks.blocks[0]
    assert ob.status == "MITIGATED" and ob.mitigated_index == 11
    rows = rows + [(100.0, 100.2, 96.8, 97.0)]          # closes below 97.5 -> invalidated
    ob = feed(rows, long_settings()).order_blocks.blocks[0]
    assert ob.status == "INVALIDATED" and ob.invalidated_index == 12


def test_disabled():
    s = long_settings()
    s.order_blocks.enabled = False
    assert feed(LONG_ROWS, s).order_blocks.blocks == []
