import pandas as pd

from backend.market_data.calendar import CalendarService, NewsIndex, normalise_event
from tests.helpers import BASE_T, LONG_ROWS, feed, long_settings
from backend.ict_engine import EngineContext

EV = {"id": "mql5:900001", "eventId": "mql5:840", "time": "2026-08-07T12:30:00Z", "countryCode": "US", "currency": "USD",
      "name": "Nonfarm Payrolls", "importance": "high", "type": "indicator", "actual": 152000, "forecast": 145000,
      "previous": 147000, "timeMode": "exact", "source": "mql5"}


def test_normalise_event():
    e = normalise_event(EV, "biquote")
    assert e["time"] == int(pd.Timestamp("2026-08-07T12:30:00Z").timestamp())
    assert e["name"] == "Nonfarm Payrolls" and e["currency"] == "USD" and e["importance"] == "high" and e["exact_time"]


def test_calendar_filters_and_paginates():
    calls = []
    page1 = [dict(EV, id=str(i), time=pd.Timestamp(1786000000 + i * 60, unit="s", tz="UTC").isoformat()) for i in range(500)]
    page2 = [dict(EV, id="x", currency="EUR", name="ECB rate", time="2026-08-20T12:00:00Z"),
             dict(EV, id="y", importance="medium", name="Jobless claims", time="2026-08-21T12:30:00Z")]

    def fetch(url, h):
        calls.append(url)
        return page1 if len(calls) == 1 else page2

    cal = CalendarService(base_url="https://biquote.io", fetch=fetch, csv_path=None)
    res = cal.events(1785000000, 1788000000, ["USD"], "high")
    assert len(calls) == 2 and "%2Fapi%2Fcalendar" not in calls[0] and "/api/calendar?from=" in calls[0]
    assert len(res["events"]) == 500 and all(e["currency"] == "USD" for e in res["events"])
    assert res["coverage"] == [1785000000, 1788000000]
    assert len(cal.events(1785000000, 1788000000, ["USD"], "medium")["events"]) == 501


def test_calendar_offline_means_no_coverage(tmp_path):
    def boom(url, h):
        raise OSError("offline")
    res = CalendarService(fetch=boom, csv_path=str(tmp_path / "none.csv")).events(0, 100)
    assert res["coverage"] is None and "unavailable" in res["error"]
    (tmp_path / "cal.csv").write_text("time,currency,name,importance\n2026-08-07T12:30:00Z,USD,NFP,high\n")
    res = CalendarService(fetch=boom, csv_path=str(tmp_path / "cal.csv")).events(1786000000, 1787000000)
    assert len(res["events"]) == 1 and res["coverage"] is not None


def test_news_index_window():
    n = NewsIndex([{"time": 1000, "name": "CPI", "currency": "USD", "importance": "high"}], (0, 5000))
    assert n.blocking(1000 - 15 * 60, 15 * 60, 15 * 60) is not None   # 15 min before
    assert n.blocking(1000 + 15 * 60, 15 * 60, 15 * 60) is not None   # 15 min after
    assert n.blocking(1000 + 16 * 60, 15 * 60, 15 * 60) is None
    assert not n.covers(6000)


def test_news_factor_in_setups():
    t_setup = BASE_T + 10 * 900
    ev = {"time": t_setup + 300, "name": "CPI", "currency": "USD", "importance": "high"}
    ctx = EngineContext()
    ctx.extra["news"] = NewsIndex([ev], (BASE_T - 86400, BASE_T + 86400))
    s = feed(LONG_ROWS, long_settings(), context=ctx).setup_engine.setups[0]
    f = {x.key: x for x in s.factors}
    assert f["news"].passed is False and "CPI" in f["news"].detail and s.max_score == 10
    ctx.extra["news"] = NewsIndex([], (BASE_T - 86400, BASE_T + 86400))
    s = feed(LONG_ROWS, long_settings(), context=ctx).setup_engine.setups[0]
    assert {x.key: x for x in s.factors}["news"].passed is True and s.score == 8
    s = feed(LONG_ROWS, long_settings()).setup_engine.setups[0]  # no calendar -> pending, not scored
    assert {x.key: x for x in s.factors}["news"].mode == "pending" and s.max_score == 9
