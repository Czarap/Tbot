from backend.ict_engine import EngineContext, ICTSettings
from tests.helpers import BASE_T, LONG_ROWS, feed, long_settings


def _s():
    s = ICTSettings()
    s.atr_period = 3
    s.structure.swing_length = 1
    return s


def test_sell_side_sweep_wick_below_close_back_above():
    e = feed(LONG_ROWS, long_settings())
    sw = e.liquidity.sweeps
    assert len(sw) == 1
    s = sw[0]
    assert s.side == "sell" and s.implication == "bullish" and s.level_price == 98.0 and s.index == 5
    assert s.extreme == 97.5 and s.close == 98.6
    lv = next(lv for lv in e.liquidity.levels if lv.id == s.level_id)
    assert lv.status == "swept" and lv.end_index == 5


def test_close_beyond_level_is_a_break_not_a_sweep():
    rows = [(100, 101, 99, 100), (100, 102, 99.5, 101), (101, 101.5, 100, 100.5), (100.5, 103, 100.4, 102.8)]
    e = feed(rows, _s())
    assert e.liquidity.sweeps == []
    lv = next(lv for lv in e.liquidity.levels if lv.kind == "swing_high")
    assert lv.price == 102 and lv.status == "broken"


def test_level_cannot_be_swept_before_it_is_known():
    # swing high at idx1 is confirmed at idx2; idx2 itself may not sweep it
    rows = [(100, 101, 99, 100), (100, 102, 99.5, 101), (101, 101.9, 100, 100.5)]
    lv = next(lv for lv in feed(rows, _s()).liquidity.levels if lv.kind == "swing_high")
    assert lv.active_from_index == 3


def test_equal_highs_detected_within_tolerance():
    s = _s()
    s.liquidity.equal_tolerance_atr = 0.2
    rows = [(100, 101, 99, 100), (100, 105.0, 99.5, 101), (101, 102, 100, 100.5), (100.5, 105.1, 100.2, 101),
            (101, 102, 100.1, 100.6), (100.6, 101, 100, 100.5)]
    e = feed(rows, s)
    eq = [lv for lv in e.liquidity.levels if lv.kind == "equal_highs"]
    assert len(eq) == 1 and eq[0].price == 105.1 and eq[0].side == "buy"
    assert len(eq[0].meta["swing_ids"]) == 2


def test_previous_day_levels_from_closed_days_only():
    day0 = BASE_T - 86400  # a completed earlier day
    ctx = EngineContext(daily={"time": [day0 - 86400, day0, BASE_T - 3600], "high": [999.0, 110.0, 5000.0], "low": [1.0, 90.0, 1.0]})
    e = feed(LONG_ROWS, long_settings(), context=ctx)
    pdh = [lv for lv in e.liquidity.levels if lv.kind == "pdh"]
    pdl = [lv for lv in e.liquidity.levels if lv.kind == "pdl"]
    # current trading day began at BASE_T-3600 -> previous day is index 1 (110 / 90); the current day's 5000 is never used
    assert [lv.price for lv in pdh] == [110.0] and [lv.price for lv in pdl] == [90.0]
