from backend.ict_engine import ICTSettings
from tests.helpers import LONG_ROWS, feed, long_settings


def _s(min_atr=0.0, min_abs=0.0):
    s = ICTSettings()
    s.atr_period = 3
    s.fvg.min_size_atr = min_atr
    s.fvg.min_size = min_abs
    return s


BULL_GAP = [(100, 101, 99, 100.5), (100.5, 104, 100.4, 103.8), (103.8, 105, 102, 104.5)]  # gap 101 -> 102
BEAR_GAP = [(100, 101, 99, 99.5), (99.5, 99.6, 95.5, 95.8), (95.8, 97.0, 94, 94.5)]      # gap 97 -> 99


def test_bullish_fvg_detected_with_fields():
    e = feed(BULL_GAP, _s())
    assert len(e.fvg.fvgs) == 1
    g = e.fvg.fvgs[0]
    assert g.direction == "bullish" and g.bottom == 101 and g.top == 102 and g.size == 1
    assert g.index == 1 and g.created_index == 2 and g.status == "UNMITIGATED" and g.ce == 101.5


def test_bearish_fvg_detected():
    e = feed(BEAR_GAP, _s())
    g = e.fvg.fvgs[0]
    assert g.direction == "bearish" and g.bottom == 97 and g.top == 99 and g.size == 2


def test_min_size_filters_small_gaps():
    assert feed(BULL_GAP, _s(min_abs=1.5)).fvg.fvgs == []
    assert len(feed(BULL_GAP, _s(min_abs=0.5)).fvg.fvgs) == 1


def test_fvg_mitigation_then_fill():
    e = feed(BULL_GAP + [(104.5, 104.6, 101.6, 104)], _s())
    g = e.fvg.fvgs[0]
    assert g.status == "MITIGATED" and g.mitigated_index == 3 and g.filled_index is None
    assert abs(g.max_fill_pct - 0.4) < 1e-9
    e = feed(BULL_GAP + [(104.5, 104.6, 101.6, 104), (104, 104.2, 100.5, 101)], _s())
    g = e.fvg.fvgs[0]
    assert g.status == "FILLED" and g.filled_index == 4 and g.max_fill_pct == 1.0


def test_creation_candle_does_not_mitigate_its_own_gap():
    g = feed(BULL_GAP, _s()).fvg.fvgs[0]
    assert g.mitigated_index is None


def test_single_candle_displacement():
    e = feed(LONG_ROWS, long_settings())
    d = [x for x in e.displacement.items if x.kind == "single"]
    assert len(d) == 1 and d[0].index == 6 and d[0].direction == "bullish"
    assert d[0].broke_structure is True
    assert any("ATR" in line for line in d[0].explanation)


def test_displacement_requires_structure_break_when_configured():
    s = long_settings()
    s.displacement.require_structure_break = True
    rows = [(100, 100.5, 99.5, 100)] * 5
    rows = [(100 + i * 0.01, 100.5 + i * 0.01, 99.5 + i * 0.01, 100 + i * 0.01) for i in range(5)] + [(100, 104, 99.9, 103.9)]
    assert [d for d in feed(rows, s).displacement.items if d.kind == "single"] == []
    s.displacement.require_structure_break = False
    assert len([d for d in feed(rows, s).displacement.items if d.kind == "single"]) == 1


def test_premium_discount_zone():
    e = feed(LONG_ROWS, long_settings())
    dr = e.pd.current
    assert dr.high == 103.8 and dr.low == 97.5 and abs(dr.equilibrium - 100.65) < 1e-9
    assert dr.zone(102) == "premium" and dr.zone(99) == "discount"
