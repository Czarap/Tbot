from backend.ict_engine import ICTSettings
from tests.helpers import LONG_ROWS, feed, long_settings


def _settings(k=2, confirmation="close"):
    s = ICTSettings()
    s.structure.swing_length = k
    s.structure.break_confirmation = confirmation
    return s


def test_swing_high_is_confirmed_only_after_k_candles():
    rows = [(1, 2, 0.5, 1.5), (1.5, 3, 1, 2.5), (2.5, 5, 2, 4), (4, 4.5, 3, 3.5), (3.5, 4, 2.5, 3)]
    # swing high at index 2 (5.0) needs 2 candles on the right -> confirmed at index 4
    e = feed(rows[:4], _settings(2))
    assert [s for s in e.swings.swings if s.kind == "high"] == []
    e = feed(rows, _settings(2))
    highs = [s for s in e.swings.swings if s.kind == "high"]
    assert len(highs) == 1
    assert highs[0].index == 2 and highs[0].confirmed_index == 4 and highs[0].price == 5


def test_swing_labels_hh_lh_hl_ll():
    e = feed(LONG_ROWS, long_settings())
    labels = [(s.kind, s.label) for s in e.swings.swings]
    assert labels == [("high", "H"), ("low", "L"), ("low", "LL"), ("high", "HH")]


def test_equal_highs_first_one_is_the_swing():
    # strict on the left side: the second of two equal highs is not a swing high
    rows = [(1, 2, 0.5, 1), (1, 5, 0.8, 1), (1, 5, 0.9, 1), (1, 2, 0.7, 1), (1, 1.5, 0.6, 1)]
    e = feed(rows, _settings(1))
    highs = [s.index for s in e.swings.swings if s.kind == "high"]
    assert highs == [1]


def test_bos_explanation_and_close_confirmation():
    e = feed(LONG_ROWS, long_settings())
    ev = e.structure.events[0]
    assert ev.type == "BOS" and ev.direction == "bullish" and ev.index == 6
    assert ev.level == 101.2 and ev.break_price == 102.9
    text = "\n".join(ev.explanation)
    assert "101.20" in text and "102.90" in text and "Candle closed above" in text


def test_choch_when_break_is_against_trend():
    rows = LONG_ROWS + [
        (102.6, 102.7, 99.0, 99.2),   # 11
        (99.2, 99.5, 96.0, 96.5),     # 12 closes below swing low 97.5 -> bearish CHoCH
        (96.5, 97.0, 95.0, 95.5),     # 13
    ]
    e = feed(rows, long_settings())
    types = [(x.type, x.direction) for x in e.structure.events]
    assert ("CHoCH", "bearish") in types
    choch = next(x for x in e.structure.events if x.type == "CHoCH")
    assert choch.trend_before == "bullish" and choch.trend_after == "bearish"
    assert any("Change of Character" in line for line in choch.explanation)


def test_wick_mode_breaks_on_wick_only():
    rows = [(10, 11, 9, 10), (10, 12, 9.5, 11), (11, 11.5, 10, 10.5), (10.5, 12.5, 10.2, 11.8)]
    # swing high 12 at idx1 (k=1) confirmed at idx2; idx3 wicks to 12.5 but closes 11.8
    assert feed(rows, _settings(1, "close")).structure.events == []
    ev = feed(rows, _settings(1, "wick")).structure.events
    assert len(ev) == 1 and ev[0].direction == "bullish" and ev[0].break_price == 12.5


def test_swing_cannot_be_broken_twice():
    e = feed(LONG_ROWS + [(102.6, 104.5, 102.5, 104.4), (104.4, 105, 104, 104.8)], long_settings())
    swing_ids = [x.swing_id for x in e.structure.events]
    assert len(swing_ids) == len(set(swing_ids))
