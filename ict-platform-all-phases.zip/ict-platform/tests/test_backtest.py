import numpy as np
import pytest

from backend.backtesting.config import BacktestConfig, PropFirmRules
from backend.backtesting.prop import evaluate_prop
from backend.backtesting.runner import run_backtest
from backend.backtesting.simulator import NewsIndex, Trade, position_size, simulate
from backend.backtesting.stats import compute_stats
from backend.market_data.base import KNOWN_SYMBOLS
from backend.market_data.service import MarketDataService
from backend.market_data.synthetic import SyntheticProvider
from backend.services.analysis_service import AnalysisService

T0 = 1795000800  # Wed 2026-11-18 06:20 New York
XAU = KNOWN_SYMBOLS["XAUUSD"]


def cfg(**kw):
    c = BacktestConfig(sessions=[], max_trades_per_day=5)
    c.costs.spread = 0.0
    c.costs.slippage = 0.0
    c.costs.commission_per_lot = 0.0
    c.news.enabled = False
    for k, v in kw.items():
        setattr(c, k, v)
    return c


def candles(rows):
    a = np.array(rows, dtype=float)
    t = np.array([T0 + 900 * i for i in range(len(rows))])
    return t, a[:, 0], a[:, 1], a[:, 2], a[:, 3]


def setup(i, direction="bullish", sl=95.0, tp=110.0, session="London"):
    return {"_i": i, "id": f"s{i}", "symbol": "XAUUSD", "timeframe": "15m", "direction": direction, "time": T0 + 900 * i,
            "stop_loss": sl, "take_profit": tp, "score": 6, "max_score": 9, "session": session, "htf_bias": "bullish",
            "factors": [{"key": "liquidity_sweep", "label": "Liquidity Sweep", "mode": "required", "passed": True, "points": 1, "detail": "swept"},
                        {"key": "fvg", "label": "FVG", "mode": "required", "passed": True, "points": 1, "detail": "fvg"}]}


FLAT = [(100, 101, 99, 100)] * 3


def test_fill_next_open_and_take_profit():
    rows = FLAT + [(100, 104, 99.5, 103), (103, 111, 102, 110)]
    r = simulate(*candles(rows), [setup(1)], cfg(), XAU)
    (tr,) = r["trades"]
    assert tr.entry_time == T0 + 1800 and tr.entry == 100.0     # open of the candle AFTER the signal
    assert tr.exit_reason == "TP" and tr.result == "WIN" and tr.exit_price == 110.0
    assert tr.lots == pytest.approx(0.5)                          # 0.5% of 50k = 250 / (5 * 100)
    assert tr.pnl == pytest.approx(500.0) and tr.r_multiple == pytest.approx(2.0)
    assert r["final_balance"] == pytest.approx(50500.0)


def test_signal_candle_cannot_fill_itself():
    rows = [(100, 101, 99, 100), (100, 111, 99, 110)] + FLAT  # TP touched on the signal candle itself
    tr = simulate(*candles(rows), [setup(1)], cfg(), XAU)["trades"][0]
    assert tr.entry_time == T0 + 1800 and tr.exit_reason != "TP" or tr.entry_time == T0 + 1800


def test_same_candle_sl_and_tp_is_conservative_by_default():
    rows = FLAT + [(100, 111, 94, 100)]
    assert simulate(*candles(rows), [setup(1)], cfg(), XAU)["trades"][0].exit_reason == "SL"
    assert simulate(*candles(rows), [setup(1)], cfg(same_bar="tp_first"), XAU)["trades"][0].exit_reason == "TP"


def test_gap_through_stop_skips_entry_and_gap_exit_uses_open():
    rows = [(100, 101, 99, 100), (100, 101, 99, 100), (94, 95, 93, 94)]
    r = simulate(*candles(rows), [setup(1)], cfg(), XAU)
    assert r["trades"] == [] and r["skipped"]["gapped through stop before entry"] == 1
    rows = FLAT + [(92, 93, 91, 92)]  # entered at 100, next candle opens below the stop
    tr = simulate(*candles(rows), [setup(1)], cfg(), XAU)["trades"][0]
    assert tr.exit_reason == "SL" and tr.exit_price == 92.0 and tr.r_multiple < -1


def test_costs_are_applied():
    c = cfg()
    c.costs.spread, c.costs.slippage, c.costs.commission_per_lot = 0.2, 0.05, 7.0
    rows = FLAT + [(100, 112, 99.5, 111)]
    r = simulate(*candles(rows), [setup(1, tp=111.0)], c, XAU)
    tr = r["trades"][0]
    assert tr.entry == pytest.approx(100.15) and tr.exit_price == pytest.approx(110.9)
    # with tp=110 the costs push R:R below 2.0 -> skipped
    assert simulate(*candles(rows), [setup(1)], c, XAU)["skipped"] == {"R:R below minimum after costs": 1}
    assert tr.commission == pytest.approx(7.0 * tr.lots)


def test_filters_one_trade_at_a_time_max_per_day_session_direction_news():
    rows = FLAT * 3 + [(100, 101, 99, 100)]
    s = [setup(0), setup(1), setup(3, session="Asia"), setup(4, direction="bearish", sl=105, tp=90)]
    c = cfg(sessions=["London"], directions=["bullish"])
    r = simulate(*candles(rows), s, c, XAU)
    assert len(r["trades"]) == 1
    sk = r["skipped"]
    assert sk["already in a trade"] == 1 and sk["outside selected sessions"] == 1 and sk["direction filtered"] == 1
    c2 = cfg()
    c2.news.enabled = True
    news = NewsIndex([{"time": T0 + 900 + 600, "name": "CPI"}])
    r2 = simulate(*candles(rows), [setup(0)], c2, XAU, news)
    assert r2["trades"] == [] and r2["skipped"]["news filter"] == 1


def test_end_of_data_closes_trade():
    tr = simulate(*candles(FLAT), [setup(0)], cfg(), XAU)["trades"][0]
    assert tr.exit_reason == "END" and tr.result in ("BREAKEVEN", "WIN", "LOSS")


def test_position_sizing_modes():
    c = cfg()
    assert position_size(c, 50_000, 5.0, 100, 1.0)[:2] == (0.5, 250.0)
    c.risk.mode = "fixed_dollar"
    c.risk.risk_dollar = 333
    assert position_size(c, 50_000, 5.0, 100, 1.0)[0] == pytest.approx(0.66)  # floored to the 0.01 step
    c.risk.mode = "fixed_lots"
    c.risk.lots = 2.0
    assert position_size(c, 50_000, 5.0, 100, 1.0)[:2] == (2.0, 1000.0)
    c.risk.mode, c.risk.max_lots = "fixed_percent", 0.2
    lots, _, notes = position_size(c, 50_000, 5.0, 100, 1.0)
    assert lots == 0.2 and "capped" in notes[0]


def _tr(i, pnl, r, day_offset=0):
    t = T0 + day_offset * 86400 + i * 60
    return Trade(id=str(i), setup_id="s", symbol="XAUUSD", timeframe="15m", direction="bullish", signal_time=t, entry_time=t,
                 entry=1, stop_loss=0, take_profit=2, lots=1, risk_amount=100, planned_reward=200, rr=2, score=5, max_score=9,
                 session="London", htf_bias=None, liquidity_event=None, fvg=None, order_block=None, displacement=None,
                 setup_type="FVG", exit_time=t + 60, exit_price=1, exit_reason="TP", result="WIN" if pnl > 0 else "LOSS",
                 pnl=pnl, r_multiple=r)


def test_stats_streaks_profit_factor_drawdown():
    trades = [_tr(0, 200, 2), _tr(1, -100, -1), _tr(2, -100, -1), _tr(3, 300, 3)]
    eq = [{"time": 0, "balance": 1000}, {"time": 1, "balance": 1200}, {"time": 2, "balance": 1100}, {"time": 3, "balance": 1000}, {"time": 4, "balance": 1300}]
    s = compute_stats(trades, eq, 1000)["stats"]
    assert s["win_rate"] == 50.0 and s["net_r"] == 3 and s["profit_factor"] == pytest.approx(2.5)
    assert s["max_consecutive_losses"] == 2 and s["max_drawdown"] == -200 and s["expectancy_r"] == 0.75


def test_prop_daily_loss_trailing_and_pass():
    rules = PropFirmRules(enabled=True, starting_balance=50_000, daily_loss_limit=500, max_drawdown=1000, profit_target=1000)
    res = evaluate_prop([_tr(0, -300, -1), _tr(1, -250, -1)], rules)
    assert res["status"] == "BREACHED" and "Daily loss" in res["reason"]
    rules.drawdown_mode, rules.daily_loss_limit = "trailing", 5000
    res = evaluate_prop([_tr(0, 800, 2), _tr(1, -400, -1, 1), _tr(2, -700, -1, 2)], rules)
    assert res["status"] == "BREACHED" and "Max drawdown" in res["reason"]   # floor trailed up to 49,800
    rules.drawdown_mode, rules.daily_loss_limit = "static", 500
    res = evaluate_prop([_tr(0, 600, 2), _tr(1, 500, 2, 1)], rules)
    assert res["status"] == "PASSED" and res["trading_days"] == 2


@pytest.fixture(scope="module")
def svc():
    return AnalysisService(MarketDataService([SyntheticProvider(days=90, end_utc=1795000000, seed=11)]))


def test_backtest_has_no_lookahead(svc):
    """Trades that closed before a cut date are identical whether or not later data exists."""
    full = run_backtest(svc, BacktestConfig(timeframe="15m", start="2026-09-01", end="2026-11-10", sessions=[]))
    part = run_backtest(svc, BacktestConfig(timeframe="15m", start="2026-09-01", end="2026-10-15", sessions=[]))
    cut = part["period"]["end"]
    a = [t for t in full["trades"] if t["exit_time"] < cut and t["exit_reason"] != "END"]
    b = [t for t in part["trades"] if t["exit_time"] < cut and t["exit_reason"] != "END"]
    assert len(a) > 3 and a == b


def test_backtest_report_shape(svc):
    c = BacktestConfig(timeframe="15m", start="2026-09-01", end="2026-11-10")
    c.prop.enabled = True
    r = run_backtest(svc, c)
    for k in ("stats", "monthly", "by_session", "by_setup_type", "drawdown", "equity", "trades", "prop", "candles"):
        assert k in r
    assert r["prop"]["status"] in ("ACTIVE", "PASSED", "BREACHED")
    tr = r["trades"][0]
    assert tr["entry_time"] > tr["signal_time"] and tr["setup_type"]
