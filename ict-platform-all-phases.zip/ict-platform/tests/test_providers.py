"""Provider adapters, tested against recorded / documented message shapes (no network)."""
import asyncio
import json
from types import SimpleNamespace

import pandas as pd
import pytest

from backend.market_data.base import AuthError, ProviderError, RateLimitError
from backend.market_data.http import TokenBucket
from backend.market_data.providers.databento_gc import normalise_ohlcv, trade_to_tick
from backend.market_data.providers.pyth_pro import PythProProvider, parse_history, parse_stream_message
from backend.market_data.providers.twelve_data import TwelveDataProvider, parse_time_series, parse_ws_message


# ------------------------------------------------------------------------ Pyth
def test_pyth_history_parse():
    df = parse_history({"s": "ok", "t": [1795000800, 1795000860], "o": [4100.1, 4100.5], "h": [4101, 4101.2],
                        "l": [4099.8, 4100.2], "c": [4100.5, 4100.9], "v": [0, 0]})
    assert list(df["time"]) == [1795000800, 1795000860] and df["close"].iloc[-1] == 4100.9
    assert parse_history({"s": "no_data"}).empty
    with pytest.raises(ProviderError):
        parse_history({"s": "error", "t": [1], "errmsg": "bad symbol"})


def test_pyth_stream_message_scaling_and_ids():
    exps = {}
    msg = {"type": "streamUpdated", "subscriptionId": 1, "parsed": {"timestampUs": "1795000800200000", "priceFeeds": [
        {"priceFeedId": 346, "price": "410012345", "bestBidPrice": "410010000", "bestAskPrice": "410015000",
         "exponent": -5, "feedUpdateTimestamp": 1795000800150000},
        {"priceFeedId": 1, "price": "1", "exponent": -8}]}}
    ticks = parse_stream_message(msg, {346: "XAUUSD"}, exps)
    assert len(ticks) == 1
    t = ticks[0]
    assert t.symbol == "XAUUSD" and abs(t.price - 4100.12345) < 1e-9 and abs(t.bid - 4100.1) < 1e-9
    assert abs(t.ts - 1795000800.15) < 1e-6
    # later updates may omit the exponent: the cached one is reused
    msg2 = {"type": "streamUpdated", "parsed": {"timestampUs": "1795000801000000", "priceFeeds": [{"priceFeedId": 346, "price": "410020000"}]}}
    assert abs(parse_stream_message(msg2, {346: "XAUUSD"}, exps)[0].price - 4100.2) < 1e-9
    with pytest.raises(AuthError):
        parse_stream_message({"type": "subscriptionError", "error": "token not entitled to feed 346"}, {}, {})


def test_pyth_history_requests_are_authenticated_and_chunked():
    calls = []

    def fetch(url, headers):
        calls.append((url, headers))
        return {"s": "ok", "t": [1795000800], "o": [1], "h": [1], "l": [1], "c": [1], "v": [0]}

    p = PythProProvider(api_key="KEY", fetch=fetch)
    df = p.get_historical_data("XAUUSD", "1m")
    assert len(calls) >= 2 and all(h["Authorization"] == "Bearer KEY" for _, h in calls)
    assert "symbol=Metal.XAU%2FUSD" in calls[0][0] and "resolution=1" in calls[0][0] and "/history?" in calls[0][0]
    assert len(df) == len(calls)
    with pytest.raises(AuthError):
        PythProProvider(api_key="").get_historical_data("XAUUSD", "1m")


def test_pyth_stream_with_fake_socket():
    sent, ticks, events = [], [], []

    class FakeWS:
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def send(self, m): sent.append(json.loads(m))
        def __aiter__(self):
            async def gen():
                yield json.dumps({"type": "subscribed", "subscriptionId": 1})
                yield json.dumps({"type": "streamUpdated", "parsed": {"timestampUs": "1", "priceFeeds": [
                    {"priceFeedId": 346, "price": "400000000", "exponent": -5, "feedUpdateTimestamp": 1795000800000000}]}})
            return gen()

    p = PythProProvider(api_key="K", ws_connect=lambda url, headers: FakeWS())
    with pytest.raises(ProviderError):  # server closing the stream must surface as an error -> reconnect
        asyncio.run(p.subscribe_realtime("XAUUSD", ticks.append, lambda k, d: events.append(k)))
    assert sent[0]["type"] == "subscribe" and sent[0]["priceFeedIds"] == [346] and "exponent" in sent[0]["properties"]
    assert events == ["connected"] and ticks[0].price == 4000.0


# ------------------------------------------------------------------ Twelve Data
TS = {"meta": {"symbol": "XAU/USD", "interval": "1min"}, "status": "ok", "values": [
    {"datetime": "2026-11-18 11:21:00", "open": "4100.2", "high": "4101.0", "low": "4099.9", "close": "4100.8"},
    {"datetime": "2026-11-18 11:20:00", "open": "4099.5", "high": "4100.4", "low": "4099.1", "close": "4100.2"}]}


def test_twelvedata_time_series_parse_sorted_utc():
    df = parse_time_series(TS)
    assert list(df["time"]) == [1795000800, 1795000860] and df["volume"].tolist() == [0.0, 0.0]


def test_twelvedata_errors_map_to_types():
    with pytest.raises(RateLimitError):
        parse_time_series({"status": "error", "code": 429, "message": "You have run out of API credits for the current minute."})
    with pytest.raises(AuthError):
        parse_time_series({"status": "error", "code": 401, "message": "**apikey** parameter is incorrect"})
    with pytest.raises(AuthError):
        parse_time_series({"status": "error", "code": 400, "message": "This symbol is available starting with the Grow plan."})


def test_twelvedata_ws_messages():
    ticks = parse_ws_message({"event": "price", "symbol": "XAU/USD", "currency_base": "Gold Spot", "timestamp": 1795000800,
                              "price": 4100.5, "bid": 4100.3, "ask": 4100.7}, {"XAU/USD": "XAUUSD"})
    assert ticks[0].symbol == "XAUUSD" and ticks[0].ask == 4100.7
    with pytest.raises(AuthError):
        parse_ws_message({"event": "subscribe-status", "status": "error", "success": [], "fails": [{"symbol": "XAU/USD"}]}, {})


def test_twelvedata_polling_emits_bar_ticks():
    ticks = []

    async def fake_sleep(_):
        raise asyncio.CancelledError

    p = TwelveDataProvider(api_key="K", fetch=lambda url, h: TS, sleep=fake_sleep)
    with pytest.raises(asyncio.CancelledError):
        asyncio.run(p.subscribe_realtime("XAUUSD", ticks.append, lambda k, d: None))
    assert [t.bar["time"] for t in ticks] == [1795000800, 1795000860] and ticks[-1].price == 4100.8


def test_token_bucket_limits():
    tb = TokenBucket(2, period=60)
    tb.acquire()
    tb.acquire()
    with pytest.raises(RateLimitError):
        tb.acquire(timeout=0.05)


# --------------------------------------------------------------------- Databento
def test_databento_normalise_and_trades():
    idx = pd.DatetimeIndex(["2026-11-18 11:20:00", "2026-11-18 11:21:00"], tz="UTC", name="ts_event")
    df = pd.DataFrame({"open": [4120.1, 4120.5], "high": [4121.0, 4121.2], "low": [4119.8, 4120.2],
                       "close": [4120.5, 4120.9], "volume": [35, 12], "symbol": ["GC.v.0"] * 2}, index=idx)
    out = normalise_ohlcv(df)
    assert list(out["time"]) == [1795000800, 1795000860] and out["close"].iloc[0] == 4120.5
    raw = df.copy()
    for c in ("open", "high", "low", "close"):
        raw[c] = (raw[c] * 1e9).astype("int64")
    assert normalise_ohlcv(raw)["close"].iloc[1] == pytest.approx(4120.9)
    rec = SimpleNamespace(rtype=0, price=4120_500_000_000, ts_event=1795000800_123_000_000, size=3)
    t = trade_to_tick(rec, "GC")
    assert t.price == pytest.approx(4120.5) and t.ts == pytest.approx(1795000800.123) and t.size == 3
    assert trade_to_tick(SimpleNamespace(rtype=0, price=2**63 - 1, ts_event=1, size=1), "GC") is None  # undefined price
