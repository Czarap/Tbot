from __future__ import annotations

from backend.ict_engine import EngineContext, ICTEngine, ICTSettings

# 2026-03-10 06:00 UTC == 02:00 New York (EDT) -> start of the London kill zone
BASE_T = 1773122400


def feed(rows, settings: ICTSettings | None = None, tf: str = "15m", tf_seconds: int = 900,
         base_t: int = BASE_T, context: EngineContext | None = None) -> ICTEngine:
    """rows: list of (open, high, low, close)."""
    e = ICTEngine(settings or ICTSettings(), "XAUUSD", tf, tf_seconds, context)
    for i, (o, h, l, c) in enumerate(rows):
        e.update(base_t + i * tf_seconds, o, h, l, c)
    return e


def mirror(rows, axis: float = 200.0):
    """Flip a price series upside down: bullish patterns become bearish ones."""
    return [(axis - o, axis - l, axis - h, axis - c) for (o, h, l, c) in rows]


# A textbook bullish sequence (swing_length=1):
#   idx1 swing high 101.2 | idx2 swing low 98 (SSL) | idx5 sweeps 98 and closes back above
#   idx6 bullish displacement + BOS above 101.2 | idx7 completes a bullish FVG 99.9-101.5
#   idx9 retraces into the FVG without a bullish close | idx10 retraces + bullish close -> setup
LONG_ROWS = [
    (100.0, 101.0, 99.0, 100.0),
    (100.0, 101.2, 99.5, 100.5),
    (100.5, 101.0, 98.0, 99.0),
    (99.0, 100.0, 98.5, 99.5),
    (99.5, 100.0, 99.0, 99.8),
    (99.8, 99.9, 97.5, 98.6),
    (98.6, 103.0, 98.5, 102.9),
    (102.9, 103.8, 101.5, 103.6),
    (103.4, 103.4, 102.0, 102.5),
    (102.5, 102.6, 101.2, 102.2),
    (102.2, 102.8, 101.0, 102.6),
]


def long_settings(**setup_overrides) -> ICTSettings:
    s = ICTSettings()
    s.atr_period = 3
    s.structure.swing_length = 1
    s.fvg.min_size_atr = 0.1
    s.setups.min_score = 5
    for k, v in setup_overrides.items():
        setattr(s.setups, k, v)
    return s
