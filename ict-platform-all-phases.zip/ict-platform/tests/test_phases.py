"""Replay, MTF panel, jobs, SQLite store, optimizer, market hours by asset class."""
import time

import numpy as np
import pandas as pd
import pytest

from backend.backtesting.config import BacktestConfig
from backend.backtesting.runner import run_backtest
from backend.database.store import Store
from backend.ict_engine import ICTSettings
from backend.market_data.market_hours import is_market_closed
from backend.market_data.service import MarketDataService
from backend.market_data.synthetic import SyntheticProvider
from backend.optimization.optimizer import OptimizeGrid, OptimizeRequest, optimize, robust_score
from backend.services.analysis_service import AnalysisService
from backend.services.jobs import JobManager
from backend.services.mtf import mtf_overview
from backend.services.replay import ReplayManager


@pytest.fixture(scope="module")
def svc():
    return AnalysisService(MarketDataService([SyntheticProvider(days=120, end_utc=1795000000, seed=5)]))


# ------------------------------------------------------------------- replay
def test_replay_never_shows_future_candles_and_matches_fresh_engine(svc):
    rm = ReplayManager(svc)
    s = rm.start("XAUUSD", "15m", None, ICTSettings(), "2026-10-20T00:00:00Z", limit=300)
    st = s.state()
    t_cursor = st["replay"]["time"]
    assert st["candles"][-1][0] == t_cursor and all(c[0] <= t_cursor for c in st["candles"])
    assert all(x["time"] <= t_cursor for x in st["analysis"]["setups"] + st["analysis"]["structure_events"])
    s.step(40)
    after = s.state()
    s.back(40)
    again = s.state()
    assert again["replay"]["time"] == t_cursor
    assert again["analysis"]["structure_events"] == st["analysis"]["structure_events"]  # stepping back = rebuilt, identical
    assert after["replay"]["time"] > t_cursor


def test_replay_seek_and_end(svc):
    rm = ReplayManager(svc)
    s = rm.start("XAUUSD", "1h", None, ICTSettings(), "2026-11-01", limit=200)
    s.seek(1795000000 + 10 * 86400)
    st = s.state()
    assert st["replay"]["at_end"] and st["replay"]["remaining"] == 0


# ---------------------------------------------------------------------- MTF
def test_mtf_rows_and_statuses(svc):
    out = mtf_overview(svc, "XAUUSD", None, ICTSettings())
    assert [r["role"] for r in out["rows"]] == ["bias", "structure", "setup", "entry"]
    assert [r["timeframe"] for r in out["rows"]] == ["4h", "1h", "15m", "5m"]
    for r in out["rows"]:
        assert r["status"] in ("aligned", "conflict", "waiting", "setup")
        if r["role"] in ("structure", "setup") and r["trend"] and out["bias"]:
            assert r["status"] == ("aligned" if r["trend"] == out["bias"] else "conflict")


# --------------------------------------------------------------------- jobs
def test_job_manager_progress_result_and_errors():
    jm = JobManager(workers=1)
    j = jm.submit("x", lambda p: (p(0.5, "half"), 42)[1])
    for _ in range(100):
        if j.state == "done":
            break
        time.sleep(0.01)
    assert j.state == "done" and j.result == 42 and j.progress == 1.0
    bad = jm.submit("y", lambda p: 1 / 0)
    for _ in range(100):
        if bad.state == "error":
            break
        time.sleep(0.01)
    assert bad.state == "error" and "ZeroDivisionError" in bad.error


# -------------------------------------------------------------------- store
def test_store_runs_journal_notes_profiles(svc, tmp_path):
    st = Store(str(tmp_path / "t.db"))
    res = run_backtest(svc, BacktestConfig(timeframe="15m", start="2026-09-15", end="2026-11-10", sessions=[]))
    st.save_run("run1", res)
    assert st.list_runs()[0]["stats"]["total_trades"] == res["stats"]["total_trades"]
    tid = res["trades"][0]["id"]
    assert st.set_note("run1", tid, "Late entry; spread was wide")
    got = st.get_run("run1")
    assert got["trades"][0]["notes"] == "Late entry; spread was wide" and got["monthly"] == res["monthly"]
    p = st.save_profile("London Sweep Strategy", ICTSettings().model_dump(), {"timeframe": "15m"})
    assert st.save_profile("London Sweep Strategy", ICTSettings().model_dump())["id"] == p["id"]  # upsert by name
    st.delete_profile(p["id"])
    assert st.list_profiles() == []
    st.delete_run("run1")
    assert st.raw("SELECT COUNT(*) AS n FROM journal")[0]["n"] == 0  # cascade


# ---------------------------------------------------------------- optimizer
def test_robust_score_rules():
    good = {"total_trades": 50, "expectancy_r": 0.4, "max_drawdown_pct": -4.0}
    assert robust_score(good, good, 20) > 0
    assert robust_score(good, {**good, "total_trades": 5}, 20) is None
    decayed = {**good, "expectancy_r": 0.1}
    assert robust_score(good, decayed, 20) < robust_score(decayed, decayed, 20)


def test_optimizer_small_grid(svc):
    req = OptimizeRequest(grid=OptimizeGrid(risk_percent=[0.5, 1.0], min_rr=[2.0], timeframes=["15m"], sessions=[["London", "New York"]],
                                            liquidity_sweep=["required"], order_block=["scored"], displacement=["scored"]),
                          min_trades=1, walk_forward_folds=2)
    req.base.start, req.base.end = "2026-08-01", "2026-11-10"
    out = optimize(svc, req)
    assert out["combinations"] == 2 and out["signal_runs"] == 1
    sp = out["splits"]
    assert sp["train"]["end"] < sp["validation"]["start"] <= sp["validation"]["end"] < sp["test"]["start"]
    assert len(out["walk_forward"]["folds"]) == 2 and any("combinations" in w for w in out["warnings"])
    top = out["results"][0]
    assert "test" in top and top["params"]["timeframe"] == "15m"


def test_grid_size_limit():
    with pytest.raises(ValueError):
        OptimizeRequest(grid=OptimizeGrid(risk_percent=[0.1 * i for i in range(1, 11)], min_rr=[1, 1.5, 2, 2.5, 3],
                                          timeframes=["1m", "5m", "15m", "30m", "1h"], liquidity_sweep=["required", "scored"],
                                          order_block=["required", "scored"], displacement=["required", "scored"]))


# ------------------------------------------------------------- market hours
def test_market_hours_by_asset_class():
    sat = np.array([int(pd.Timestamp("2026-11-21 12:00", tz="America/New_York").timestamp())])
    brk = np.array([int(pd.Timestamp("2026-11-18 17:30", tz="America/New_York").timestamp())])
    assert is_market_closed(sat)[0] and is_market_closed(sat, asset_class="forex")[0]
    assert not is_market_closed(sat, asset_class="crypto")[0]
    assert is_market_closed(brk)[0] and not is_market_closed(brk, asset_class="forex")[0]
