"""Anti-repainting / look-ahead tests.

For several cut points N, the engine run on candles[0:N] must make exactly the
same decisions for candles < N as the engine run on the full history.
"""
import pandas as pd
import pytest

from backend.ict_engine import EngineContext, HTFBias, ICTEngine, ICTSettings
from backend.market_data.resample import WEEK, resample
from backend.market_data.synthetic import generate_xauusd_1m

END = 1795000000


@pytest.fixture(scope="module")
def data():
    m1 = generate_xauusd_1m(days=40, end_utc=END, seed=3)
    return {"1m": m1, "15m": resample(m1, "15m"), "4h": resample(m1, "4h"), "1d": resample(m1, "1d")}


def _ctx(d):
    daily = d["1d"]
    return EngineContext(EngineContext.frame_to_ref(daily), EngineContext.frame_to_ref(resample(daily, WEEK)),
                         HTFBias.from_candles(d["4h"], "4h", 14400, 3, "close"))


def _run(df, ctx):
    return ICTEngine(ICTSettings(), "XAUUSD", "15m", 900, ctx).run(df)


def _decisions(e: ICTEngine, upto_time: int):
    def keep(t):
        return t < upto_time
    return {
        "swings": [s.to_dict() for s in e.swings.swings if keep(s.confirmed_time)],
        "structure": [x.to_dict() for x in e.structure.events if keep(x.time)],
        "sweeps": [x.to_dict() for x in e.liquidity.sweeps if keep(x.time)],
        "displacement": [x.to_dict() for x in e.displacement.items if keep(x.time)],
        "fvg_created": [(g.id, g.top, g.bottom, g.created_time) for g in e.fvg.fvgs if keep(g.created_time)],
        "order_blocks": [(b.id, b.top, b.bottom, b.created_time) for b in e.order_blocks.blocks if keep(b.created_time)],
        "levels_created": [(lv.id, lv.price, lv.created_time) for lv in e.liquidity.levels if keep(lv.created_time)],
        "setups": [s.to_dict() for s in e.setup_engine.setups if keep(s.time)],
    }


@pytest.mark.parametrize("cut", [300, 900, 1500, 2100])
def test_prefix_run_matches_full_run(data, cut):
    df = data["15m"].tail(2500).reset_index(drop=True)
    ctx = _ctx(data)
    full = _run(df, ctx)
    part = _run(df.iloc[:cut], ctx)
    cut_time = int(df["time"].iloc[cut])
    a, b = _decisions(full, cut_time), _decisions(part, cut_time)
    for key in a:
        assert a[key] == b[key], f"{key} differs between prefix and full run at cut {cut}"
    assert len(a["setups"]) + len(a["structure"]) > 0  # the test actually exercised something


def test_engine_has_produced_setups_on_realistic_data(data):
    e = _run(data["15m"].tail(2500).reset_index(drop=True), _ctx(data))
    assert len(e.setup_engine.setups) > 0


def test_htf_bias_never_uses_unclosed_candle(data):
    h4 = data["4h"]
    bias = HTFBias.from_candles(h4, "4h", 14400, 3, "close")
    t0 = int(h4["time"].iloc[100])
    # one second before the 4h candle closes, its trend must not be visible yet
    _, src = bias.at(t0 + 14400 - 1)
    assert src == int(h4["time"].iloc[99])
    _, src = bias.at(t0 + 14400)
    assert src == t0


def test_engine_rejects_out_of_order_candles():
    e = ICTEngine()
    e.update(1000, 1, 2, 0.5, 1.5)
    with pytest.raises(ValueError):
        e.update(1000, 1, 2, 0.5, 1.5)


def test_setup_levels_only_reference_known_liquidity(data):
    e = _run(data["15m"].tail(2500).reset_index(drop=True), _ctx(data))
    levels = {lv.id: lv for lv in e.liquidity.levels}
    for s in e.setup_engine.setups:
        if s.target_level_id:
            assert levels[s.target_level_id].active_from_index <= s.index
        sweep = next((x for x in e.liquidity.sweeps if x.id == s.sweep_id), None)
        if sweep:
            assert sweep.index <= s.index
