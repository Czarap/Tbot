from tests.helpers import LONG_ROWS, feed, long_settings, mirror


def test_long_setup_detected_with_transparent_factors():
    e = feed(LONG_ROWS, long_settings())
    assert len(e.setup_engine.setups) == 1
    s = e.setup_engine.setups[0]
    assert s.direction == "bullish" and s.label == "POSSIBLE LONG SETUP"
    assert s.index == 10  # idx9 touched without a bullish close; idx10 confirmed
    assert s.entry == 102.6  # close of the confirmation candle
    assert s.stop_loss < 97.5  # below the sweep low
    assert abs(s.rr - 2.0) < 1e-6 and s.take_profit > s.entry
    f = {x.key: x for x in s.factors}
    assert f["liquidity_sweep"].passed and f["structure_shift"].passed and f["displacement"].passed
    assert f["fvg"].passed and f["htf_bias"].passed and f["session"].passed
    assert f["premium_discount"].passed is False  # entry is in premium of the 97.5-103.8 range
    assert f["liquidity_target"].passed is False  # no buy-side level >= 2R -> fixed 2R target
    assert f["order_block"].passed and f["order_block"].mode == "scored"  # down-close candle 5 before the BOS
    assert f["news"].mode == "pending"
    assert s.score == sum(x.points for x in s.factors) == 7 and s.max_score == 9
    assert "POSSIBLE LONG SETUP" in s.reasoning[0]


def test_short_setup_is_the_mirror_image():
    e = feed(mirror(LONG_ROWS), long_settings())
    assert len(e.setup_engine.setups) == 1
    s = e.setup_engine.setups[0]
    assert s.direction == "bearish" and s.label == "POSSIBLE SHORT SETUP"
    assert abs(s.entry - (200 - 102.6)) < 1e-9 and s.stop_loss > 102.5 and s.take_profit < s.entry
    assert s.score == 7


def test_required_rule_blocks_setup():
    rows = list(LONG_ROWS)
    rows[5] = (99.8, 99.9, 98.2, 98.6)  # no longer sweeps the 98.0 low
    e = feed(rows, long_settings())
    assert e.setup_engine.setups == []
    assert any("Liquidity Sweep" in k for k in e.setup_engine.rejections)


def test_rule_mode_off_and_scored():
    s = long_settings()
    s.setups.rules.premium_discount = "off"
    e = feed(LONG_ROWS, s)
    st = e.setup_engine.setups[0]
    assert st.max_score == 8 and st.score == 7


def test_min_score_threshold():
    e = feed(LONG_ROWS, long_settings(min_score=8))
    assert e.setup_engine.setups == []
    assert any("Score below" in k for k in e.setup_engine.rejections)


def test_hold_confirmation_triggers_one_candle_earlier():
    e = feed(LONG_ROWS, long_settings(confirmation="hold"))
    assert e.setup_engine.setups[0].index == 9


def test_close_through_fvg_invalidates():
    rows = list(LONG_ROWS[:9]) + [(102.5, 102.6, 99.0, 99.5)]  # closes below FVG bottom 99.9
    e = feed(rows + [LONG_ROWS[10]], long_settings())
    assert e.setup_engine.setups == []


def test_setup_language_never_guarantees():
    s = feed(LONG_ROWS, long_settings()).setup_engine.setups[0]
    blob = " ".join(s.reasoning + [f.detail for f in s.factors]).lower()
    for word in ("guarantee", "sure win", "will win"):
        assert word not in blob
