"""biquote adapter, tested against the response shapes in biquote.io/docs (no network)."""
import asyncio
import json

import pandas as pd
import pytest

from backend.market_data.base import ProviderError
from backend.market_data.live_store import LiveCandleStore
from backend.market_data.providers.biquote import RS, BiquoteProvider, parse_ohlc, parse_tick, split_frames
from backend.market_data.service import MarketDataService

OHLC = {"symbol": "XAUUSD", "interval": "1h", "bars": [
    {"openTime": "2026-11-18T11:00:00Z", "open": 4101.0, "high": 4103.2, "low": 4100.1, "close": 4102.5, "volume": 0, "tickVolume": 340, "isOpen": True},
    {"openTime": "2026-11-18T10:00:00Z", "open": 4098.0, "high": 4101.5, "low": 4097.2, "close": 4101.0, "volume": 0, "tickVolume": 412, "isOpen": False},
]}
TICK = {"symbol": "XAUUSD", "description": "Gold vs US Dollar", "bid": 4102.41, "ask": 4102.63, "mid": 4102.52, "spread": 0.22,
        "last": 0.0, "volume": 0, "direction": "UP", "dayDiffPercent": 0.31, "timestamp": "2026-11-18T11:20:05Z",
        "time": "2026.11.18 13:20:05", "source": "MetaTrader 5 (Broker 1)", "marketState": "open", "stale": False, "quoteAgeSeconds": 0}


def test_parse_ohlc_sorts_oldest_first_and_uses_tick_volume():
    df = parse_ohlc(OHLC)
    assert list(df["time"]) == [1794996000, 1794999600]
    assert df["close"].tolist() == [4101.0, 4102.5] and df["volume"].tolist() == [412.0, 340.0]
    assert parse_ohlc({"bars": []}).empty


def test_parse_tick_uses_mid_and_iso_utc_timestamp():
    t = parse_tick(TICK, {"XAUUSD": "XAUUSD"})
    assert t.price == 4102.52 and t.bid == 4102.41 and t.ask == 4102.63 and t.ts == 1795000805.0
    # epoch-milliseconds variant and slash symbols are accepted too
    t2 = parse_tick({"symbol": "XAU/USD", "price": 4100.0, "timestamp": 1795000805123}, {"XAUUSD": "XAUUSD"})
    assert t2.price == 4100.0 and t2.ts == pytest.approx(1795000805.123)
    assert parse_tick({"symbol": "EURUSD", "mid": 1.1}, {"XAUUSD": "XAUUSD"}) is None


def test_history_request():
    urls = []
    p = BiquoteProvider(base_url="https://biquote.io", fetch=lambda u, h: urls.append(u) or OHLC)
    df = p.get_historical_data("XAUUSD", "1h")
    assert urls == ["https://biquote.io/api/XAUUSD/ohlc?interval=1h&limit=1000"] and len(df) == 2
    assert p.info().configured and "XAUUSD" in p.info().symbols and "GC" not in p.info().symbols  # no key; no futures


def test_signalr_flow_with_fake_hub():
    sent, ticks, events = [], [], []
    frames = [
        "{}" + RS,  # handshake ok
        json.dumps({"type": 1, "target": "ReceiveTick", "arguments": [TICK]}) + RS + json.dumps({"type": 6}) + RS,
        json.dumps({"type": 7, "error": "Server is shutting down"}) + RS,
    ]

    class FakeWS:
        def __init__(self): self.url = None
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def send(self, m): sent.append(m)
        async def recv(self): return frames[0]
        def __aiter__(self):
            async def gen():
                for f in frames[1:]:
                    yield f
            return gen()

    urls = []

    def connect(url, headers):
        urls.append(url)
        return FakeWS()

    p = BiquoteProvider(base_url="https://biquote.io", post=lambda u, h: {"connectionToken": "abc", "negotiateVersion": 1}, ws_connect=connect)
    with pytest.raises(ProviderError, match="shutting down"):
        asyncio.run(p.subscribe_realtime("XAUUSD", ticks.append, lambda k, d: events.append(k)))
    assert urls == ["wss://biquote.io/hubs/tick?id=abc"]
    assert json.loads(sent[0].rstrip(RS)) == {"protocol": "json", "version": 1}
    assert json.loads(sent[1].rstrip(RS)) == {"type": 1, "target": "Subscribe", "arguments": [["XAUUSD"]]}
    assert events == ["connected"] and ticks[0].price == 4102.52


def test_split_frames_handles_multiple_records():
    assert split_frames('{"type":6}' + RS + '{"type":3,"invocationId":"0"}' + RS) == [{"type": 6}, {"type": 3, "invocationId": "0"}]


def test_polling_mode(monkeypatch):
    monkeypatch.setenv("BIQUOTE_STREAM", "polling")
    ticks = []

    async def stop(_):
        raise asyncio.CancelledError

    p = BiquoteProvider(fetch=lambda u, h: TICK, sleep=stop)
    assert p.info().transport == "polling"
    with pytest.raises(asyncio.CancelledError):
        asyncio.run(p.subscribe_realtime("XAUUSD", ticks.append, lambda k, d: None))
    assert ticks[0].price == 4102.52


def test_4h_bars_realigned_to_new_york_session_grid():
    # vendor 4h bars on a UTC grid (00,04,08 ...) are moved onto the 17:00 New York grid
    t0 = int(pd.Timestamp("2026-11-16 00:00", tz="UTC").timestamp())
    bars = [{"openTime": pd.Timestamp(t0 + i * 14400, unit="s", tz="UTC").isoformat(), "open": 1.0 + i, "high": 2.0 + i,
             "low": 0.5 + i, "close": 1.5 + i, "volume": 1, "tickVolume": 1} for i in range(12)]
    p = BiquoteProvider(fetch=lambda u, h: {"bars": bars})
    svc = MarketDataService([p])
    cs = svc.get_candles("XAUUSD", "4h", now=t0 + 100 * 86400)
    from backend.market_data.resample import bucket_start
    t = cs.df["time"].to_numpy()
    assert (bucket_start(t, "4h") == t).all() and cs.quality.realigned_bars > 0


def test_live_store_persists_and_reloads(tmp_path):
    store = LiveCandleStore(tmp_path)
    p = BiquoteProvider(fetch=lambda u, h: OHLC)
    svc = MarketDataService([p], live_store=store)
    c = {"time": 1795003200, "open": 4102.5, "high": 4104.0, "low": 4102.0, "close": 4103.7, "volume": 120.0}
    svc.append_live("biquote", "XAUUSD", "1h", c)
    assert (tmp_path / "biquote_XAUUSD_1h.csv").exists()
    fresh = MarketDataService([BiquoteProvider(fetch=lambda u, h: OHLC)], live_store=LiveCandleStore(tmp_path))
    cs = fresh.get_candles("XAUUSD", "1h", now=1795003200 + 7200)
    assert int(cs.df["time"].iloc[-1]) == 1795003200 and cs.df["close"].iloc[-1] == 4103.7
