"""Live layer: candle aggregation, status classification, hub reconnect/resync."""
import asyncio
import time

import numpy as np
import pandas as pd
import pytest

from backend.live.aggregator import CandleAggregator
from backend.live.hub import Client, LiveHub
from backend.live.status import classify
from backend.market_data.base import KNOWN_SYMBOLS, MarketDataProvider, ProviderError, ProviderInfo, Tick
from backend.market_data.service import MarketDataService, merge_live, split_forming
from backend.services.analysis_service import AnalysisService

T0 = 1795000800  # 2026-11-18 11:20 UTC, a Wednesday (gold market open), minute-aligned


# ------------------------------------------------------------------ aggregator
def test_aggregator_builds_ohlc_and_closes_on_next_bucket():
    a = CandleAggregator("XAUUSD", "1m")
    assert a.update(T0 + 1, 100.0, 1) == []
    a.update(T0 + 10, 101.5, 2)
    a.update(T0 + 20, 99.0, 1)
    a.update(T0 + 59, 100.5, 1)
    assert a.forming == {"time": T0, "open": 100.0, "high": 101.5, "low": 99.0, "close": 100.5, "volume": 5.0}
    closed = a.update(T0 + 61, 100.7, 1)
    assert closed == [{"time": T0, "open": 100.0, "high": 101.5, "low": 99.0, "close": 100.5, "volume": 5.0}]
    assert a.forming["time"] == T0 + 60 and a.forming["open"] == 100.7


def test_aggregator_duplicates_late_and_out_of_order():
    a = CandleAggregator("XAUUSD", "1m")
    a.update(T0 + 5, 100.0)
    a.update(T0 + 5, 100.0)  # exact duplicate
    assert a.stats.duplicates == 1
    a.update(T0 + 30, 101.0)
    a.update(T0 + 20, 102.0)  # out of order inside bucket: extends high, keeps the close
    assert a.forming["high"] == 102.0 and a.forming["close"] == 101.0 and a.stats.out_of_order == 1
    a.update(T0 + 65, 100.5)  # closes T0
    a.update(T0 + 50, 90.0)   # late tick for the CLOSED candle -> rejected, candle stays final
    assert a.stats.late_rejected == 1 and a.forming["low"] == 100.5


def test_aggregator_time_based_close_and_gap():
    a = CandleAggregator("XAUUSD", "5m", grace_seconds=2)
    a.update(T0 + 1, 100.0)
    assert a.close_due(T0 + 300) is None           # within grace
    c = a.close_due(T0 + 302)
    assert c["time"] == T0 and a.forming is None
    a.update(T0 + 1200, 101.0)                      # gap of several buckets: no empty candles invented
    assert a.forming["time"] == T0 + 1200
    assert a.update(T0 + 100, 99.0) == [] and a.stats.late_rejected == 1


def test_aggregator_bar_updates_do_not_double_count_volume():
    a = CandleAggregator("XAUUSD", "5m")
    a.update(T0 + 10, 100, bar={"time": T0, "open": 100, "high": 101, "low": 99.5, "close": 100.5, "volume": 10})
    a.update(T0 + 40, 100.8, bar={"time": T0, "open": 100, "high": 101.2, "low": 99.5, "close": 100.8, "volume": 14})
    a.update(T0 + 70, 100.9, bar={"time": T0 + 60, "open": 100.8, "high": 101.0, "low": 100.6, "close": 100.9, "volume": 3})
    f = a.forming
    assert f["time"] == T0 and f["high"] == 101.2 and f["low"] == 99.5 and f["close"] == 100.9 and f["volume"] == 17


def test_4h_bucket_matches_history_alignment():
    from backend.market_data.resample import bucket_start
    a = CandleAggregator("XAUUSD", "4h")
    t = T0 + 123
    assert a.bucket(t) == int(bucket_start(np.array([t]), "4h")[0])


# ---------------------------------------------------------------------- status
def _st(**kw):
    base = dict(symbol="XAUUSD", market="Spot Gold", provider_id="p", provider_name="P", transport="websocket", realtime=True,
                streaming=True, connected=True, last_source_ts=T0 - 1, last_receive=T0 - 0.5, error=None, retry_at=None,
                fatal=False, now=T0)
    base.update(kw)
    return classify(**base)


def test_status_live_only_when_fresh_and_realtime():
    assert _st().state == "live"
    assert _st(last_source_ts=T0 - 120).state == "delayed"              # lagging source
    assert _st(last_receive=T0 - 120, last_source_ts=T0 - 120).state == "delayed"  # stale
    assert _st(realtime=False).state == "delayed"                        # provider not real-time
    assert _st(connected=False, error="boom", retry_at=T0 + 4).state == "reconnecting"
    assert _st(connected=False, error="bad key", retry_at=T0 + 60, fatal=True).state == "disconnected"
    assert _st(streaming=False).state == "historical"
    assert _st(transport="simulated").state == "simulated"


def test_status_market_closed_on_weekend():
    saturday = int(pd.Timestamp("2026-11-21 12:00", tz="America/New_York").timestamp())
    s = _st(now=saturday, last_source_ts=saturday - 3600, last_receive=saturday - 3600)
    assert s.state == "market_closed" and s.label == "MARKET CLOSED"


def test_status_polling_tolerates_poll_interval():
    s = _st(transport="polling", poll_seconds=15, last_source_ts=T0 - 40, last_receive=T0 - 10)
    assert s.state == "live" and "Polling" in s.message
    assert _st(transport="polling", poll_seconds=15, last_source_ts=T0 - 400, last_receive=T0 - 10).state == "delayed"


# ---------------------------------------------------------- service helpers
def test_split_forming_and_merge_live():
    df = pd.DataFrame({"time": [T0 - 120, T0 - 60, T0], "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "volume": 1.0})
    closed, forming = split_forming(df, 60, now=T0 + 30)
    assert list(closed["time"]) == [T0 - 120, T0 - 60] and forming["time"] == T0
    live = pd.DataFrame({"time": [T0 - 60, T0 + 60], "open": 9.0, "high": 9.0, "low": 9.0, "close": 9.0, "volume": 9.0})
    m = merge_live(df, live)
    assert list(m["time"]) == [T0 - 120, T0 - 60, T0, T0 + 60] and m.loc[1, "close"] == 9.0


# ---------------------------------------------------------------------- hub
class ScriptedProvider(MarketDataProvider):
    """History + scripted ticks; the first connection drops after 3 ticks."""

    id = "scripted"

    def __init__(self):
        self.connects = 0
        self.history_loads = 0
        now = int(time.time()) // 60 * 60
        t = np.arange(now - 3000 * 60, now, 60)
        rng = np.random.default_rng(1)
        close = 4000 + np.cumsum(rng.normal(0, 0.5, len(t)))
        self.df = pd.DataFrame({"time": t, "open": close, "high": close + 0.3, "low": close - 0.3, "close": close, "volume": 1.0})

    def info(self):
        return ProviderInfo(self.id, "Scripted", "test", False, ["1m"], symbols=["XAUUSD"], realtime=True, transport="websocket")

    def symbols(self):
        return [KNOWN_SYMBOLS["XAUUSD"]]

    def native_timeframes(self, symbol):
        return ["1m"]

    def get_historical_data(self, symbol, timeframe):
        self.history_loads += 1
        return self.df.copy()

    @property
    def supports_streaming(self):
        return True

    async def subscribe_realtime(self, symbol, on_tick, on_event, attempt=0):
        self.connects += 1
        on_event("connected", {})
        base = time.time()
        for i in range(3):
            await asyncio.sleep(0.05)
            on_tick(Tick(symbol, base + i * 0.05, 4001.0 + i))
        if self.connects == 1:
            raise ProviderError("simulated drop")
        # second connection: jump into the next minute bucket to force a candle close
        nxt = (int(time.time()) // 60 + 1) * 60 + 1
        on_tick(Tick(symbol, nxt, 4010.0))
        await asyncio.sleep(3600)


def test_hub_streams_reconnects_resyncs_and_recomputes():
    async def main():
        prov = ScriptedProvider()
        data = MarketDataService([prov])
        hub = LiveHub(data, AnalysisService(data), backoff_cap=0.2, recompute_delay=0.05)
        msgs = []

        async def send(m):
            msgs.append(m)

        client = Client(send)
        writer = asyncio.create_task(client.writer())
        await hub.subscribe(client, "XAUUSD", "1m", limit=300)
        for _ in range(60):
            await asyncio.sleep(0.1)
            types = [m["type"] for m in msgs]
            if "candle_closed" in types and "analysis" in types[types.index("candle_closed"):]:
                break
        await hub.shutdown()
        writer.cancel()
        return prov, msgs

    prov, msgs = asyncio.run(main())
    types = [m["type"] for m in msgs]
    states = [m["status"]["state"] for m in msgs if m["type"] == "status"]
    assert "snapshot" in types and "candle" in types
    assert "reconnecting" in states and "live" in states        # dropped, then recovered
    assert prov.connects >= 2 and prov.history_loads >= 2        # history reloaded on reconnect (gap fill)
    closed = [m for m in msgs if m["type"] == "candle_closed"]
    assert closed and closed[0]["candle"]["symbol"] == "XAUUSD" and closed[0]["candle"]["timeframe"] == "1m"
    assert set(closed[0]["candle"]) == {"timestamp", "open", "high", "low", "close", "volume", "symbol", "timeframe"}
    after_close = types[types.index("candle_closed"):]
    assert "analysis" in after_close                              # ICT engine re-ran on the closed candle
    snap = next(m for m in msgs if m["type"] == "snapshot")
    assert "order_blocks" in snap["payload"]["analysis"]


def test_client_queue_drops_oldest_when_full():
    async def main():
        c = Client(lambda m: asyncio.sleep(0), maxsize=3)
        for i in range(5):
            c.put({"i": i})
        return [c.queue.get_nowait()["i"] for _ in range(3)], c.dropped
    items, dropped = asyncio.run(main())
    assert items == [2, 3, 4] and dropped == 2
