# ICT Lab — Live Gold Chart + ICT Analysis Platform

A TradingView-style charting app for **ICT (Inner Circle Trader) market analysis** on gold, with
**live data** for **XAUUSD (spot gold)** and **GC (COMEX gold futures)** as two separate instruments.
It detects market structure, liquidity, fair value gaps, order blocks, displacement and
premium/discount with deterministic, documented rules, draws them on an interactive chart that
updates without refreshing, and flags **possible** setups with a fully transparent confluence score.

> **Analysis only.** There is no broker connection anywhere in the code. The app cannot place,
> modify or manage orders, and it never copies trades. Setups are labelled "Possible Long / Possible
> Short" with *hypothetical* entry, stop and target.

---

## 1. Quick start

Requirements: Python 3.10+ (Node 18+ only if you want to modify the frontend).

```bash
pip install -r requirements.txt
python run.py                 # -> http://127.0.0.1:8000  (XAUUSD streams live from biquote, no key needed)
cp .env.example .env          # optional: keys for Pyth / Twelve Data / Databento (GC futures)
```

The repository ships with a pre-built UI in `frontend/dist`, so no Node install is needed to run it.
With no keys at all, **XAUUSD is live from biquote** and **GC falls back to a clearly labelled SIMULATED
feed** (biquote has no gold futures). Add a Databento key for real GC data.

### Live data providers (Yahoo is not used)

| Instrument | Provider | What you need | Live transport |
|---|---|---|---|
| **XAUUSD** spot gold | **biquote** (default) | nothing — free, no key. Broker CFD prices from a MetaTrader 5 feed (mid price, tick volume only). History is a short rolling window (1m ≈ 300 bars, 1h ≈ 1 week, 1d ≈ 500 bars); candles received live are saved to `data/live_cache/`, so history grows while the app runs. biquote publishes no terms of use — check they fit your use. | SignalR WebSocket (`/hubs/tick`), or `BIQUOTE_STREAM=polling` (REST every 1 s) |
| XAUUSD spot gold | **Pyth Pro** | `PYTH_API_KEY` – trial key from Pyth Terminal or a Starter/Pro plan. Since Aug 2026 Pyth requires a key for Hermes and the History API. | WebSocket (`pyth-lazer` stream, ~200 ms updates) |
| XAUUSD spot gold | **Twelve Data** | `TWELVEDATA_API_KEY`. WebSocket streaming of XAU/USD needs the **Pro plan or higher**; on Basic/Grow use `TWELVEDATA_STREAM=polling` (default, latest 1-minute bar every 15 s, rate-limited to your plan's credits). | WebSocket or polling |
| **GC** gold futures | **Databento** (CME Globex `GLBX.MDP3`) | `pip install databento` + `DATABENTO_API_KEY`. Live CME data carries exchange licence fees. Symbol `GC.v.0` = volume-lead front month (not back-adjusted, so rolls can show a gap). | Databento Live (trades) |
| either | CSV files | `data/XAUUSD_1m.csv`, `data/GC_1m.csv` … (MetaTrader / Dukascopy / HistData formats auto-detected) | none (shown as HISTORICAL) |
| either | Simulated | nothing | simulated ticks (shown as SIMULATED, never LIVE) |

`auto` picks, per instrument, the first configured provider (XAUUSD: biquote → Pyth → Twelve Data → CSV;
GC: Databento → Pyth → CSV), otherwise the simulator. Override with `ICT_PROVIDER_XAUUSD` /
`ICT_PROVIDER_GC`, or switch in the top bar. `python run.py` prints which provider each instrument uses.

### Market status shown in the app

| Badge | Meaning |
|---|---|
| ● **LIVE** | connected, provider is real-time, last update is fresh and close to the source timestamp |
| ● **DELAYED** | connected but data lags real time, updates stopped arriving, or the provider/plan isn't real-time |
| ● **DISCONNECTED** + "⚠ Connection Lost — Reconnecting…" | browser↔server or server↔provider link is down; retrying with back-off |
| ● **MARKET CLOSED** | weekend or the daily 17:00–18:00 New York break, no updates arriving |
| ● **SIMULATED** / **HISTORICAL** | not live data |

The status is computed from timestamps (`backend/live/status.py`), so delayed data is never labelled LIVE.

### Frontend development

```bash
cd frontend
npm install
npm run dev        # rebuilds frontend/dist on every change; refresh the browser
npm run build      # one-off production build
npm run typecheck
```

The build uses esbuild + the Tailwind v4 compiler directly (`frontend/build.mjs`).

### Static demo

`python scripts/build_demo.py` runs the engine for every timeframe and embeds the output in a
single file, `frontend/dist-demo/index.html`, that works without a server (no live data there).

### Tests

```bash
python -m pytest -q        # 91 tests
```

---

## Live data pipeline

```
Provider (WebSocket / polling)
   │  normalised Tick {symbol, ts, price, bid, ask, size}
   ▼
LiveHub (one upstream connection per provider+instrument, shared by all browser tabs)
   ├─ CandleAggregator for every timeframe (same bucket alignment as history)
   │     · duplicates ignored · out-of-order ticks never overwrite the close
   │     · late ticks for a closed candle rejected (closed candles are final)
   │     · candles close on the next tick or when their time is up
   ├─ forming candle  ──────────────► browser "candle" message (≤ 4/s)
   └─ candle CLOSED   ─► MarketDataService.append_live() ─► ICT engine re-run on closed candles
                                                        └─► browser "candle_closed" + "analysis"
Connection lost → back-off (1, 2, 4 … 30 s) → history reloaded to fill the gap → aggregators re-seeded
```

* Endpoints: **`/ws/live`** (WebSocket, primary) and **`/api/live/stream`** (Server-Sent Events fallback,
  used automatically if WebSockets are blocked). Diagnostics at `/api/live/status`.
* Candle messages use the common format `{timestamp, open, high, low, close, volume, symbol, timeframe}`.
* The browser reconnects automatically, re-subscribes, and treats 25 s of silence as a dead connection.
* Only **closed** candles reach the ICT engine; the forming candle is drawn but never analysed, so
  live detections cannot repaint.

## 2. What is implemented (all five phases)

| Phase | Feature | Where |
|---|---|---|
| 1 | Chart, 7 timeframes, swings, BOS/CHoCH, liquidity + sweeps, FVGs, possible setups with reasoning | Chart page |
| 1+ | Live XAUUSD / GC streaming (biquote, Pyth Pro, Twelve Data, Databento, CSV, simulated) with LIVE / DELAYED / DISCONNECTED status | Chart page top bar |
| 2 | Multi-timeframe panel (bias / structure / setup / entry roles), displacement, order blocks, premium/discount, transparent confluence score, hypothetical entry/SL/TP | Chart → Analysis panel, Settings |
| 3 | Backtesting engine (same streaming ICT engine), spread / slippage / commission, position sizing, equity & drawdown curves, statistics, monthly / session / setup / direction / score breakdowns, trade markers, trade journal with notes (SQLite), CSV export | Backtest + Journal pages |
| 4 | Candle-by-candle replay (step, back, play at 1–10 candles/s), optimizer with train / validation / test splits, robustness ranking, overfitting warning, walk-forward | Chart → ⏪ Replay, Optimizer page |
| 5 | Economic calendar (news markers + news filter), prop-firm simulator, browser alerts for new live setups, more instruments (EURUSD, GBPUSD, USDJPY, BTCUSD), saved strategy profiles, CSV data import | Chart, Backtest, Settings |

Every page carries the same rules: **no order execution, no broker connection, no automatic
trading**. Setups are "Possible Long / Possible Short" with *hypothetical* levels.

### Using the pages

* **Chart** — live chart + ICT overlays. The right panel shows the MTF table, bias, structure,
  premium/discount, liquidity and upcoming high-impact USD news. 🔔 enables browser notifications
  (and an optional sound) when a new possible setup appears on a closed candle; they are alerts
  only. **⏪ Replay** hides everything after a chosen UTC time and lets you step forward one
  candle at a time; the engine only ever knows the candles up to the replay cursor.
* **Backtest** — pick instrument, provider, timeframe and dates; set risk, filters, costs and
  optional prop-firm rules; press *Run backtest*. Results are saved to the Journal automatically.
  Click a trade to see it on the chart with its full setup reasoning.
* **Optimizer** — enter the values to try (risk %, minimum R:R, timeframes, sessions, and
  required/scored/off for sweep, order block, displacement). Read the overfitting banner first.
  *Backtest* on any row re-runs that combination on the full period.
* **Journal** — every saved run: statistics, equity curve, breakdowns, filterable trade list,
  editable notes, CSV export, delete.
* **Settings (⚙)** — all ICT rule parameters, MTF roles, news filter, order blocks, data
  providers, and **strategy profiles** (save / load / delete a named set of rules + backtest
  settings, e.g. "London Sweep Strategy"). CSV upload lives under *Data providers*.

### Chart

Zoom (mouse wheel / pinch), pan (drag / swipe), crosshair with OHLC readout, price and time axes,
current-price line, visible high/low markers, volume, timezone switch (New York / UTC / local),
"scroll to latest", double-click to reset. Hover any zone, line or label to see why it exists.
Click a setup on the chart or in the table to open its reasoning.

---

## 3. How the ICT rules work

All rules live in `backend/ict_engine/` and each module starts with a plain-English rule block.
Every threshold is a setting (`backend/ict_engine/settings.py`, editable in the UI).

**Swings** (`structure.py`). A swing high at candle *c* has a strictly higher high than the *k*
candles before it and a high ≥ the *k* candles after it (*k* = swing sensitivity). It is only
**confirmed at candle c + k**. Labels: HH/LH vs the previous swing high, HL/LL vs the previous swing low.

**BOS / CHoCH** (`structure.py`). A candle **closing** (or wicking, if configured) beyond the most
recent unbroken swing. With the trend → BOS; against the trend → CHoCH. A swing can be broken once.

**Liquidity** (`liquidity.py`). Levels: swing highs/lows, equal highs/lows (within
`equal_tolerance_atr` × ATR, older swing untouched in between), previous day/week high/low (17:00 New
York rollover), completed session highs/lows. A wick through a level **with a close back inside** =
**sweep**; a close beyond it = **break** (not a sweep). Levels can only be swept by candles after
they became known.

**FVG** (`fvg.py`). Three candles A-B-C: bullish if `low[C] > high[A]`, bearish if `high[C] < low[A]`.
Size must be ≥ max(`min_size`, `min_size_atr` × ATR). Status updates: MITIGATED (price re-entered),
FILLED (traded through), with max fill %.

**Order blocks** (`order_blocks.py`). When a BOS/CHoCH happens, the last opposite-colour candle
before the move that broke structure (searched back to the swing that started the move, at most
`lookback_bars`). Zone = full candle or body. MITIGATED when price returns, INVALIDATED on a close
through the far side. Known at the structure-break candle, never earlier.

**Displacement** (`displacement.py`). Range ≥ 1.5 × ATR(previous candle) and body ≥ 60% of range, or N
consecutive same-direction candles whose combined body ≥ 2.5 × ATR. Reports whether structure broke.

**Premium / discount** (`premium_discount.py`). Dealing range = latest confirmed swing high/low (or
previous day). Above 50% = premium, below = discount.

**HTF bias** (`mtf.py`). Same structure rules on the higher timeframe (auto: 1m→15m, 5m→1h,
15m/30m→4h, 1h/4h→1d). Only HTF candles that had **closed** by the time of the lower-TF candle are used.

**Possible setup** (`setups.py`), bullish (bearish is the mirror):
1. A bullish FVG forms (the entry zone).
2. Within `max_retrace_bars`, price trades back into it without closing through it.
3. Confirmation candle: closes back above the gap ("hold"), and by default also closes bullish ("rejection").
4. Entry = close of that candle (a decision can't be made before the close).
   Stop = lowest low since the sweep (or the FVG's first candle) − buffer.
   Target = nearest active buy-side liquidity giving ≥ `min_rr`, else a fixed `min_rr` target.
5. Confluence factors (each `required`, `scored` (+1) or `off`): HTF bias, liquidity sweep (default
   **required**), BOS/CHoCH since the sweep, displacement, FVG (always required), order block from
   the same move, discount, session (London / New York kill zones), liquidity target, and **news**
   (no high-impact USD event within ±15 min). If the calendar has no data for that time the news
   factor is shown as *pending* and scores 0 — missing data is never treated as "no news".
6. Emitted only if all required factors pass, score ≥ `min_score` (default 5) and R:R ≥ `min_rr` (default 2).

## 4. Anti-repainting / no look-ahead

`backend/ict_engine/engine.py` documents the contract. The engine is fed one candle at a time and
stores candles in append-only lists, so future candles do not exist inside it while a decision is
made. Lagging confirmations (e.g. swings) carry both the pivot index and the confirmation index.
`tests/test_no_lookahead.py` runs the engine on prefixes of real-looking data and asserts every
swing, BOS/CHoCH, sweep, displacement, FVG, order block and setup before the cut is **identical**
to the full run. Status fields (FVG filled, level swept) record what happened later and never change
the original decision. HTF bias only uses higher-timeframe candles that had closed. Replay uses the
same engine and simply stops feeding it at the cursor ("back" rebuilds from scratch).

## 4b. Backtesting rules

`backend/backtesting/simulator.py` (header documents the order of events):

1. A setup confirmed at the **close** of candle *i−1* is filled at the **open** of candle *i*
   (market order, + half spread + slippage against you). Skipped if that open already gapped
   through the stop or target.
2. Open trades are checked against each candle's high/low. If stop and target are both inside one
   candle the order is unknowable from OHLC, so the **stop is assumed first** by default
   (configurable). A candle that opens beyond a level exits at the open.
3. Filters: date range, direction, sessions, max trades per day, news window, **R:R after costs**
   ≥ minimum, one trade at a time.
4. Sizing: fixed % risk, fixed $ risk or fixed lots, rounded to the lot step and clamped to
   min/max lots. P&L = price move × lots × contract size − commission.

**Prop-firm simulator** (`prop.py`): daily loss limit (17:00 New York day), static or trailing max
drawdown, profit target with minimum trading days, optional max trades/day. Evaluated on closed
trades, so a real account could breach earlier on floating losses — the UI says so.

## 4c. Optimizer and overfitting

`backend/optimization/optimizer.py`:

* The period is split chronologically into **train / validation / test** (default 60/20/20).
* Ranking uses the **validation** period only, never profit alone:
  `score = expectancy_R × min(1, √(trades/50)) − 0.5 × max(0, train_expectancy − val_expectancy) − |max DD %| / 20`.
  Combinations under the minimum validation trade count are not ranked.
* The **test** period is untouched during ranking and reported only for the top 10.
* **Walk-forward**: optimise on one window, measure on the next, repeat; the combined
  out-of-sample result is the honest estimate.
* Setups depend only on the signal parameters, so they are generated once per signal combination and
  reused for every risk/session variant (limits: 2,000 combinations, 120 signal runs).

## 4d. Economic calendar

`backend/market_data/calendar.py` uses biquote's free calendar (`/api/calendar`) plus an optional
`data/calendar.csv` for older history (`time,currency,name,importance`). Each result carries a
**coverage window**; the news filter and the news factor only judge times inside it. Backtests
outside the coverage show a warning instead of pretending there was no news.

## 5. Project structure

```
ict-platform/
├── run.py                     # start the server
├── requirements.txt  .env.example
├── backend/
│   ├── main.py                # FastAPI app (API + static UI)
│   ├── api/                   # routes.py, live_routes.py, phase_routes.py, schemas.py
│   ├── market_data/           # provider abstraction + cleaning + resampling + calendar
│   │   ├── base.py            # MarketDataProvider: get_historical_data / get_realtime_data /
│   │   │                      #   subscribe_realtime / get_symbol_info; Tick; SymbolInfo
│   │   ├── providers/         # biquote.py  pyth_pro.py  twelve_data.py  databento_gc.py
│   │   ├── calendar.py        # economic calendar + NewsIndex
│   │   ├── live_store.py      # saves live-closed candles (data/live_cache/)
│   │   ├── synthetic.py  csv_provider.py  http.py (rate limiter)
│   │   ├── cleaning.py  resample.py  market_hours.py  timeframes.py  service.py
│   ├── ict_engine/            # engine.py (contract), structure, liquidity, fvg, order_blocks,
│   │                          # displacement, premium_discount, sessions, mtf, setups, settings, types
│   ├── live/                  # hub.py (streams, reconnect, fan-out), aggregator.py, status.py
│   ├── services/              # analysis_service.py, mtf.py, replay.py, jobs.py (background jobs)
│   ├── backtesting/           # config.py, simulator.py, stats.py, prop.py, runner.py
│   ├── optimization/          # optimizer.py (splits, robust score, walk-forward)
│   └── database/store.py      # SQLite: runs, journal notes, strategy profiles
├── frontend/
│   ├── build.mjs  package.json  tsconfig.json
│   ├── dist/                  # pre-built UI served by the backend
│   └── src/
│       ├── charts/            # CandleChart.ts (canvas renderer), LineChart.tsx, format.ts
│       ├── components/        # TopBar, AppNav, ReplayBar, MTFPanel, BacktestForm, AlertsPanel, DataImport, ui …
│       ├── panels/            # AnalysisPanel, SetupDetail, BottomPanel, SettingsDrawer
│       ├── pages/             # TradingPage, BacktestPage, OptimizerPage, JournalPage
│       ├── services/          # api.ts, live.ts (WebSocket/SSE), alerts.ts, chartData.ts
│       └── types.ts
├── scripts/build_demo.py
├── data/                      # CSVs, calendar.csv, ict.db (created on first run)
└── tests/                     # pytest: detectors, setups, no-look-ahead, live, providers, backtest, optimizer, calendar …
```

### API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | liveness |
| GET | `/api/meta` | symbols, timeframes, providers, default settings + JSON schema |
| GET | `/api/candles?symbol&timeframe&limit&provider` | cleaned candles |
| GET | `/api/analysis?symbol&timeframe&limit&provider` | candles + analysis with default rules |
| WS | `/ws/live` | live stream: send `{"action":"subscribe","symbol","timeframe","provider","limit","settings"}` |
| GET | `/api/live/stream?symbol&timeframe&provider&limit&settings` | same stream as Server-Sent Events |
| GET | `/api/live/status` | live feed diagnostics (connections, aggregator counters) |
| POST | `/api/analysis` | `{symbol, timeframe, limit, provider, settings}` → candles + analysis |
| POST | `/api/mtf` | multi-timeframe overview for the four roles |
| GET | `/api/calendar?start&end&currencies&importance` | economic events + coverage window |
| POST | `/api/backtest` | start a backtest job (config body) → job id; result saved to the journal |
| POST | `/api/optimize` | start an optimizer job `{base, grid, train, validation, min_trades, walk_forward_folds}` |
| GET / DELETE | `/api/jobs/{id}?result=true` | job progress / result; DELETE cancels |
| GET / DELETE | `/api/runs`, `/api/runs/{id}` | saved runs |
| PATCH | `/api/journal/{run_id}/{trade_id}` | `{notes}` |
| GET / POST / DELETE | `/api/profiles` | saved strategy profiles |
| POST | `/api/replay/start`, `/api/replay/{id}/step`, `/back`, `/seek`; DELETE `/api/replay/{id}` | replay sessions |
| POST | `/api/data/upload?symbol&timeframe&tz` | upload a candle CSV (raw body); GET `/api/data/files` |

All timestamps are UTC epoch seconds of the candle open. Interactive docs at `/docs`.

## 6. Notes and deviations

* **Chart library.** The chart is a custom canvas renderer (`frontend/src/charts/CandleChart.ts`)
  instead of Lightweight Charts: packages couldn't be installed in the environment this was built in,
  and ICT zones (FVG / order-block boxes, position boxes) need rectangle drawing anyway. It sits behind
  a small API (`setData`, `upsertCandle`, `setFlags`, `focusTime` …) so it can be swapped later.
* **What was verified where.** The ICT engine, data layer, live aggregation, status logic, hub
  reconnect/resync, provider message parsers, backtester, prop rules, optimizer, calendar, store and replay are covered by pytest. The full live
  pipeline and every page (chart, replay, backtest, optimizer, journal, settings/profiles) were run end-to-end in a browser against the simulated feed over the SSE transport,
  including a server crash and automatic recovery, and against a local stand-in for biquote's REST
  API (polling mode, documented response shapes), including candle closes and the local history cache.
  The build environment had no internet access and no WebSocket library, so **the real biquote /
  Pyth / Twelve Data / Databento connections, biquote's SignalR hub and the `/ws/live` WebSocket
  endpoint were not exercised live** — they were written against the providers' current documentation
  and tested with recorded message shapes. Run `python run.py` and check the status badge turns LIVE.
  If biquote's SignalR stream doesn't connect on your network, set `BIQUOTE_STREAM=polling`.
* **Provider caveats.** biquote's prices are one broker's CFD quotes and can differ slightly from other
  brokers or from Pyth's aggregated spot price; vendor 4h/1d bars are re-bucketed onto the 17:00 New
  York session grid so they match the live candles (the Data tab shows how many bars were moved). Pyth's free tier ended with the August 2026 Core upgrade (a key is now
  required). Twelve Data's free/Grow plans only stream trial symbols over WebSocket, hence the polling
  mode. GC via Databento is the front-month continuous contract without back-adjustment.
* **Intrabar ambiguity.** Detection is candle-based. Entries are taken at the close of the confirmation
  candle, which avoids look-ahead but is conservative compared with limit entries at the FVG edge.

## 7. Known limitations / what remains

* Live provider connections (biquote SignalR, Pyth, Twelve Data, Databento) and `/ws/live` were not
  exercised against the real services in the build environment (no internet) — see §6.
* biquote's free OHLC history is short. For multi-year backtests import a CSV (MT5, Dukascopy,
  HistData formats) via Settings → Data providers, or use a keyed provider.
* Entries are market orders at the next open; limit entries at the FVG edge are not modelled.
* Prop-firm rules are evaluated on closed trades only.
* Alerts are browser notifications while the page is open (no email/Telegram/server push).
* NAS100 / US30 are declared but not wired to a free provider.

---

*This platform is an educational and analytical tool. Backtested results do not guarantee future
performance. Historical simulations may differ from real-world execution due to spreads, slippage,
liquidity, commissions, and data quality.*
